HTTP lab v4 - saved reports and results window

1. Stop the old lab with poff CLEHttpLab.
2. Extract all 23 folders into dev_plugins, replacing the old CLH00-CLH21 and
   CLEHttpLab files. Leave CollectionLogExpanded and PrettyUI in place.
3. Run prf, then pon CLEHttpLab. PrettyUI must remain enabled.
4. Close the console. The results window opens and the tests run automatically
   for approximately two minutes. Wait for the finished status.
5. Click the summary input field and try Ctrl+A, Ctrl+C, then paste into Notepad
   to save a .txt file or into the conversation. If the game does not support
   copying here, screenshot the summary window. Choose a case in the dropdown
   to show its exact error/result in the second field.
6. Reports are saved under cle:http-lab:v4 in THIS diagnostic plugin's own
   PersistentDB. Re-enabling it opens the saved report; use Run all tests again
   when you explicitly want another run. This does not create an arbitrary text
   file, because no supported file-write API is available in the captured SDK.
7. poff CLEHttpLab stops the lab and disables CLH00-CLH21. Leave these diagnostic
   folders until the report has been collected, then remove only those folders.

A native HTTP 200 callback is evidence of a response. ENABLED alone is not.
Non-200 callbacks, constructor errors, Get errors, timeouts and missing reports
are kept distinct. Each case attempts at most one public-data GET per run via
normal native APIs. No permission check or client restriction is modified.

Only diagnostic metadata is saved. No character names, collections, gameplay
inputs, external messages or source-code uploads are involved. Production plugin
files and their PersistentDB remain unchanged. All host-side tests use substitutes
for native APIs; they do not prove native HTTP, rendering or clipboard behavior.
