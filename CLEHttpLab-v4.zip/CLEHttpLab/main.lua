local cases={{["id"]="00",["label"]="no permission baseline",["mode"]="none",["folder"]="CLH00",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="01",["label"]="optional canonical; folder equals manifest name",["mode"]="optional",["folder"]="CLH01",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="02",["label"]="optional; grant from own startup like published GEPL",["mode"]="optional",["selfGrant"]="startup",["folder"]="CLH02",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="03",["label"]="required canonical; grant before enable",["mode"]="required",["folder"]="CLH03",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="04",["label"]="required; omit empty optionalPermissions",["mode"]="required",["omitOptional"]=true,["folder"]="CLH04",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="05",["label"]="optional; lowercase command permission",["mode"]="optional",["commandPermission"]="httpaccess",["folder"]="CLH05",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="06",["label"]="optional; PascalCase command permission",["mode"]="optional",["commandPermission"]="HttpAccess",["folder"]="CLH06",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="07",["label"]="optional; HTTPAccess command permission",["mode"]="optional",["commandPermission"]="HTTPAccess",["folder"]="CLH07",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="08",["label"]="required; PascalCase declaration",["mode"]="required",["permission"]="HttpAccess",["commandPermission"]="HttpAccess",["folder"]="CLH08",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="09",["label"]="optional; PascalCase declaration",["mode"]="optional",["permission"]="HttpAccess",["commandPermission"]="HttpAccess",["folder"]="CLH09",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="10",["label"]="optional; lowercase declaration",["mode"]="optional",["permission"]="httpaccess",["commandPermission"]="httpaccess",["folder"]="CLH10",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="11",["label"]="optional; empty dependency arrays",["mode"]="optional",["dependencyArrays"]=true,["folder"]="CLH11",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="12",["label"]="optional; trailing slash in base URL",["mode"]="optional",["url"]="https://runescape.wiki/",["folder"]="CLH12",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="13",["label"]="optional; base URL spelling in HTTP documentation",["mode"]="optional",["url"]="http://www.runescape.wiki",["folder"]="CLH13",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="14",["label"]="required; GEPL manifest shape and prices domain",["mode"]="required",["url"]="https://prices.runescape.wiki",["omitOptional"]=true,["folder"]="CLH14",["commandPermission"]="httpAccess",["path"]="/api/v2/rs/latest?id=995"},{["id"]="15",["label"]="optional; prices domain",["mode"]="optional",["url"]="https://prices.runescape.wiki",["folder"]="CLH15",["commandPermission"]="httpAccess",["path"]="/api/v2/rs/latest?id=995"},{["id"]="16",["label"]="optional; grant targets differing simple display name",["mode"]="optional",["display"]="CLHShown16",["grantTarget"]="CLHShown16",["folder"]="CLH16",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="17",["label"]="optional; grant targets quoted display name with spaces",["mode"]="optional",["display"]="CLH Named Probe",["grantTarget"]="\"CLH Named Probe\"",["folder"]="CLH17",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="18",["label"]="optional; first-party Jagex domain",["mode"]="optional",["url"]="https://www.jagex.com",["folder"]="CLH18",["commandPermission"]="httpAccess",["path"]="/"},{["id"]="19",["label"]="optional; omit empty requiredPermissions",["mode"]="optional",["omitRequired"]=true,["folder"]="CLH19",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="20",["label"]="optional; full permission command instead of alias",["mode"]="optional",["longCommand"]=true,["folder"]="CLH20",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"},{["id"]="21",["label"]="optional; grant from own first Logic callback",["mode"]="optional",["selfGrant"]="logic",["folder"]="CLH21",["commandPermission"]="httpAccess",["path"]="/api.php?action=query&meta=siteinfo&siprop=general&format=json"}}
local steps={{["delay"]=5,["message"]="00 BEGIN no permission baseline",["command"]="poff CLH00"},{["delay"]=10,["command"]="pon CLH00"},{["delay"]=185,["message"]="00 NEXT"},{["delay"]=5,["message"]="01 BEGIN optional canonical; folder equals manifest name",["command"]="poff CLH01"},{["delay"]=10,["command"]="pon CLH01"},{["delay"]=25,["command"]="ppe CLH01 httpAccess"},{["delay"]=185,["message"]="01 NEXT"},{["delay"]=5,["message"]="02 BEGIN optional; grant from own startup like published GEPL",["command"]="poff CLH02"},{["delay"]=10,["command"]="pon CLH02"},{["delay"]=185,["message"]="02 NEXT"},{["delay"]=5,["message"]="03 BEGIN required canonical; grant before enable",["command"]="poff CLH03"},{["delay"]=5,["command"]="ppe CLH03 httpAccess"},{["delay"]=10,["command"]="pon CLH03"},{["delay"]=185,["message"]="03 NEXT"},{["delay"]=5,["message"]="04 BEGIN required; omit empty optionalPermissions",["command"]="poff CLH04"},{["delay"]=5,["command"]="ppe CLH04 httpAccess"},{["delay"]=10,["command"]="pon CLH04"},{["delay"]=185,["message"]="04 NEXT"},{["delay"]=5,["message"]="05 BEGIN optional; lowercase command permission",["command"]="poff CLH05"},{["delay"]=10,["command"]="pon CLH05"},{["delay"]=25,["command"]="ppe CLH05 httpaccess"},{["delay"]=185,["message"]="05 NEXT"},{["delay"]=5,["message"]="06 BEGIN optional; PascalCase command permission",["command"]="poff CLH06"},{["delay"]=10,["command"]="pon CLH06"},{["delay"]=25,["command"]="ppe CLH06 HttpAccess"},{["delay"]=185,["message"]="06 NEXT"},{["delay"]=5,["message"]="07 BEGIN optional; HTTPAccess command permission",["command"]="poff CLH07"},{["delay"]=10,["command"]="pon CLH07"},{["delay"]=25,["command"]="ppe CLH07 HTTPAccess"},{["delay"]=185,["message"]="07 NEXT"},{["delay"]=5,["message"]="08 BEGIN required; PascalCase declaration",["command"]="poff CLH08"},{["delay"]=5,["command"]="ppe CLH08 HttpAccess"},{["delay"]=10,["command"]="pon CLH08"},{["delay"]=185,["message"]="08 NEXT"},{["delay"]=5,["message"]="09 BEGIN optional; PascalCase declaration",["command"]="poff CLH09"},{["delay"]=10,["command"]="pon CLH09"},{["delay"]=25,["command"]="ppe CLH09 HttpAccess"},{["delay"]=185,["message"]="09 NEXT"},{["delay"]=5,["message"]="10 BEGIN optional; lowercase declaration",["command"]="poff CLH10"},{["delay"]=10,["command"]="pon CLH10"},{["delay"]=25,["command"]="ppe CLH10 httpaccess"},{["delay"]=185,["message"]="10 NEXT"},{["delay"]=5,["message"]="11 BEGIN optional; empty dependency arrays",["command"]="poff CLH11"},{["delay"]=10,["command"]="pon CLH11"},{["delay"]=25,["command"]="ppe CLH11 httpAccess"},{["delay"]=185,["message"]="11 NEXT"},{["delay"]=5,["message"]="12 BEGIN optional; trailing slash in base URL",["command"]="poff CLH12"},{["delay"]=10,["command"]="pon CLH12"},{["delay"]=25,["command"]="ppe CLH12 httpAccess"},{["delay"]=185,["message"]="12 NEXT"},{["delay"]=5,["message"]="13 BEGIN optional; base URL spelling in HTTP documentation",["command"]="poff CLH13"},{["delay"]=10,["command"]="pon CLH13"},{["delay"]=25,["command"]="ppe CLH13 httpAccess"},{["delay"]=185,["message"]="13 NEXT"},{["delay"]=5,["message"]="14 BEGIN required; GEPL manifest shape and prices domain",["command"]="poff CLH14"},{["delay"]=5,["command"]="ppe CLH14 httpAccess"},{["delay"]=10,["command"]="pon CLH14"},{["delay"]=185,["message"]="14 NEXT"},{["delay"]=5,["message"]="15 BEGIN optional; prices domain",["command"]="poff CLH15"},{["delay"]=10,["command"]="pon CLH15"},{["delay"]=25,["command"]="ppe CLH15 httpAccess"},{["delay"]=185,["message"]="15 NEXT"},{["delay"]=5,["message"]="16 BEGIN optional; grant targets differing simple display name",["command"]="poff CLH16"},{["delay"]=10,["command"]="pon CLH16"},{["delay"]=25,["command"]="ppe CLHShown16 httpAccess"},{["delay"]=185,["message"]="16 NEXT"},{["delay"]=5,["message"]="17 BEGIN optional; grant targets quoted display name with spaces",["command"]="poff CLH17"},{["delay"]=10,["command"]="pon CLH17"},{["delay"]=25,["command"]="ppe \"CLH Named Probe\" httpAccess"},{["delay"]=185,["message"]="17 NEXT"},{["delay"]=5,["message"]="18 BEGIN optional; first-party Jagex domain",["command"]="poff CLH18"},{["delay"]=10,["command"]="pon CLH18"},{["delay"]=25,["command"]="ppe CLH18 httpAccess"},{["delay"]=185,["message"]="18 NEXT"},{["delay"]=5,["message"]="19 BEGIN optional; omit empty requiredPermissions",["command"]="poff CLH19"},{["delay"]=10,["command"]="pon CLH19"},{["delay"]=25,["command"]="ppe CLH19 httpAccess"},{["delay"]=185,["message"]="19 NEXT"},{["delay"]=5,["message"]="20 BEGIN optional; full permission command instead of alias",["command"]="poff CLH20"},{["delay"]=10,["command"]="pon CLH20"},{["delay"]=25,["command"]="plugins_permissions_enable CLH20 httpAccess"},{["delay"]=185,["message"]="20 NEXT"},{["delay"]=5,["message"]="21 BEGIN optional; grant from own first Logic callback",["command"]="poff CLH21"},{["delay"]=10,["command"]="pon CLH21"},{["delay"]=185,["message"]="21 NEXT"},{["delay"]=650,["finish"]=true}}
local key="cle-http-lab-runner"
local state={version=4,rows={},running=false,complete=false}
local index,nextTick=0,nil
local window,summaryField,detailsField,heading,picker,selection=nil,nil,nil,nil,nil,"01"
local function say(value) print("CLE_HTTP_LAB RUNNER " .. tostring(value)) end
local function execute(value)
    local ok,err=pcall(function() ExecuteConsoleCommand(value) end)
    if not ok then say("COMMAND_ERROR " .. tostring(err)) end
end
local function providers() return {["00"]=probe00,["01"]=probe01,["02"]=probe02,["03"]=probe03,["04"]=probe04,["05"]=probe05,["06"]=probe06,["07"]=probe07,["08"]=probe08,["09"]=probe09,["10"]=probe10,["11"]=probe11,["12"]=probe12,["13"]=probe13,["14"]=probe14,["15"]=probe15,["16"]=probe16,["17"]=probe17,["18"]=probe18,["19"]=probe19,["20"]=probe20,["21"]=probe21} end
local function collect()
    local available=providers()
    for _,case in ipairs(cases) do
        local provider=available[case.id]
        if provider then
            local ok,report=pcall(function() return provider.GetReport() end)
            if ok and type(report)=="table" then state.rows[case.id]=report
            else state.rows[case.id]={id=case.id,label=case.label,stage="report-error",error=tostring(report),lines={}} end
        elseif not state.rows[case.id] then
            state.rows[case.id]={id=case.id,label=case.label,stage="not-enabled",lines={}}
        end
    end
end
local function describe(row)
    if row.stage=="response" then return "HTTP " .. tostring(row.code) .. (row.successful and " received" or " callback") end
    return ({["constructor-error"]="CONSTRUCTOR ERROR",["get-error"]="GET ERROR",baseline="CONTROL",waiting="WAITING",timeout="TIMEOUT",entered="STARTED",["not-enabled"]="NOT ENABLED",["report-error"]="REPORT ERROR"})[row.stage] or tostring(row.stage)
end
local function summary()
    local lines={"HTTP lab v4" .. (state.running and " - running" or state.complete and " - finished" or " - saved")}
    local wins={}
    for _,case in ipairs(cases) do
        local row=state.rows[case.id] or {stage="pending"}
        lines[#lines+1]=case.id .. " | check=" .. tostring(row.dot or "-") .. " | " .. describe(row)
        if row.stage=="response" and row.code==200 and row.successful then wins[#wins+1]=case.id end
    end
    table.insert(lines,2,"Successful HTTP 200 cases: " .. (#wins>0 and table.concat(wins,", ") or "none recorded"))
    return table.concat(lines,"\n")
end
local function details()
    local row=state.rows[selection]
    if not row then return selection .. " | no report yet" end
    local lines={selection .. " | " .. tostring(row.label),"Status: " .. describe(row),"Dot check: " .. tostring(row.dot),"Colon check: " .. tostring(row.colon),"URL type: " .. tostring(row.url)}
    for _,line in ipairs(row.lines or {}) do lines[#lines+1]=line end
    if row.error then lines[#lines+1]="Error: " .. tostring(row.error) end
    return table.concat(lines,"\n")
end
local function save()
    local ok,result=pcall(function() return PersistentDB:SetStructuredData("cle:http-lab:v4",state) end)
    state.saved=ok and result==true
    if not state.saved then say("SAVE_ERROR " .. tostring(result)) end
end
local function updateView()
    pcall(function()
        if summaryField then summaryField:SetText(summary(),false) end
        if detailsField then detailsField:SetText(details(),false) end
        if heading then heading.content=(state.running and "Tests running. Wait about two minutes." or state.saved and "Results saved in the lab's PersistentDB." or "Report visible; saving has not succeeded. Copy or screenshot before stopping.") end
    end)
end
local function startRun()
    state={version=4,rows={},running=true,complete=false}
    index,nextTick=0,nil
    say("START 22 variants; results are captured automatically")
    updateView()
end
local function open()
    if window then pcall(function() window:Destroy() end) end
    local parent=ui.Interfaces:GetComponent(id.Component.TOPLEVEL_V2__PLUGIN_BUILD_LAYER_TOP)
    if not parent then return end
    window=prettyui.Window.new(parent,{title="Collection Log HTTP lab results",width=820,height=700,minWidth=600,minHeight=420,scrollable=true,x=-410,y=-350,xAnchor=0.5,yAnchor=0.5})
    heading=window:AddText("")
    window:AddText("Select the summary field, then try Ctrl+A and Ctrl+C. Paste into Notepad to save a .txt file. If copying is unavailable, screenshot this window.")
    summaryField=window:AddTextField({text=summary(),maxLength=9999,height=290})
    window:AddSimpleButton("Run all tests again",startRun)
    window:AddSimpleButton("Refresh results",function() if state.running then collect() end;updateView() end,{inline=true})
    local entries={}
    for _,case in ipairs(cases) do entries[#entries+1]={label=case.id .. " - " .. case.label,id=tonumber(case.id)+1} end
    picker=window:AddComboBox({entries=entries,selectedID=tonumber(selection)+1,onChange=function(_,choice)
        selection=string.format("%02d",choice-1);updateView()
    end})
    detailsField=window:AddTextField({text=details(),maxLength=9999,height=180})
    window:AddText("The report contains only diagnostic statuses/errors. Collection data and player information are not read. Stopping this plugin disables only CLH00-CLH21.")
    updateView();window:Show()
end
local loaded,previous=pcall(function() return PersistentDB:GetStructuredData("cle:http-lab:v4") end)
if loaded and type(previous)=="table" and previous.version==4 and type(previous.rows)=="table" then
    state=previous;state.running=false;state.saved=true
end
Event.Logic.Subscribe(key,function(event)
    local ok,err=pcall(function()
        if state.running then
            if not nextTick then nextTick=event.logicTick end
            if event.logicTick>=nextTick then
                index=index+1
                local step=steps[index]
                if step then
                    if step.command then execute(step.command) end
                    if step.finish then
                        collect();state.running=false;state.complete=true;save();updateView()
                        say("END - open the results window; no console transcription needed")
                    end
                    local upcoming=steps[index+1]
                    nextTick=event.logicTick+(upcoming and upcoming.delay or 1)
                end
            end
            if event.logicTick%50==0 then collect();updateView() end
            if event.logicTick%500==0 then save() end
        end
    end)
    if not ok then state.running=false;say("ERROR " .. tostring(err));save();updateView() end
end)
Event.ContentLayerReady.Subscribe(key,function() pcall(open) end)
function PluginShutdown()
    if state.running then collect() end
    state.running=false;save()
    pcall(function() Event.Logic.Unsubscribe(key) end)
    pcall(function() Event.ContentLayerReady.Unsubscribe(key) end)
    for _,case in ipairs(cases) do execute("poff " .. case.folder) end
    if window then pcall(function() window:Destroy() end) end
end
local opened,err=pcall(open)
if not opened then say("WINDOW_ERROR " .. tostring(err)) end
if not state.complete then startRun() end
return {Open=open}
