local helper = require("lib/permission")
local key = "cle-permission-probe"
local previous
local function report(reason, force)
    local rootOK, rootAllowed, enumType, enumValue = pcall(function()
        local permission = PluginPermissions.httpAccess
        return Plugin.HasPermission(permission), type(permission), tostring(permission)
    end)
    local helperOK, helperAllowed = pcall(helper.hasHTTP)
    local state = "root=" .. tostring(rootOK and rootAllowed or false)
        .. " rootType=" .. type(rootAllowed)
        .. " helper=" .. tostring(helperOK and helperAllowed or false)
        .. " helperType=" .. type(helperAllowed)
        .. " enumType=" .. tostring(enumType) .. " enumValue=" .. tostring(enumValue)
    if not rootOK then state = state .. " rootFailure=" .. tostring(rootAllowed) end
    if not helperOK then state = state .. " helperFailure=" .. tostring(helperAllowed) end
    if force or state ~= previous then
        log("CLE_PERMISSION_PROBE " .. reason .. " " .. state)
        previous = state
    end
end
Event.Logic.Subscribe(key,function(event)
    if event.logicTick % 50 == 0 then report("poll",false) end
end)
Event.OptionalPermissionChanged.Subscribe(key,function(event)
    report("event:" .. tostring(event.permissionName) .. "=" .. tostring(event.enabled),true)
end)
function PluginShutdown()
    Event.Logic.Unsubscribe(key)
    Event.OptionalPermissionChanged.Unsubscribe(key)
end
report("startup",true)
