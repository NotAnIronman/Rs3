Developer-only permission startup comparison (v2).

Extract both top-level folders directly into dev_plugins:
  CLEPermissionControl/main.lua and plugin.json
  CLERequiredPermissionProbe/main.lua and plugin.json
Replace the old required probe main.lua and plugin.json if prompted.
An old lib folder left in the required probe is harmless: v2 never imports it.

The two main.lua files are identical. Neither subscribes to events, imports
libraries, makes network requests, or reads/writes collection data.
The control requests no permissions; the required probe requires httpAccess.
Each prints entered before calling any plugin API, then reports the result
or caught error and prints finished.

Run in the client console, preserving all output:
  prf
  pon CLEPermissionControl
  ppe CLERequiredPermissionProbe httpAccess
  pon CLERequiredPermissionProbe
  plist
Close the console and respond to any permission prompt the client presents.
If a prompt appears, repeat plist afterward and note whether it was approved.

After testing:
  poff CLEPermissionControl
  poff CLERequiredPermissionProbe

These probes are private diagnostics, excluded from the public plugin/release.
