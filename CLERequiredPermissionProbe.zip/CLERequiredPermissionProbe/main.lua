local helper = require("lib/permission")
local key = "cle-required-permission-probe"
local previous
local function report(reason, force)
    local rootOK, rootAllowed, enumType, enumValue = pcall(function()
        local permission = PluginPermissions.httpAccess
        return Plugin.HasPermission(permission), type(permission), tostring(permission)
    end)
    local helperOK, helperAllowed = pcall(helper.hasHTTP)
    local state = "root=" .. tostring(rootOK and rootAllowed or false)
        .. " rootType=" .. type(rootAllowed)
        .. " helper=" .. tostring(helperOK and helperAllowed or false)
        .. " helperType=" .. type(helperAllowed)
        .. " enumType=" .. tostring(enumType) .. " enumValue=" .. tostring(enumValue)
    if not rootOK then state = state .. " rootFailure=" .. tostring(rootAllowed) end
    if not helperOK then state = state .. " helperFailure=" .. tostring(helperAllowed) end
    if force or state ~= previous then
        log("CLE_REQUIRED_PERMISSION_PROBE " .. reason .. " " .. state)
        previous = state
    end
end
Event.Logic.Subscribe(key,function(event)
    if event.logicTick % 50 == 0 then report("poll",false) end
end)
Event.OptionalPermissionChanged.Subscribe(key,function(event)
    report("event:" .. tostring(event.permissionName) .. "=" .. tostring(event.enabled),true)
end)
Event.MiniMenuEntrySelected.Subscribe(key,function(event)
    if event.entry and event.entry.actionVerbType == MiniMenuActionVerbType.EXAMINE then
        report("after-examine",true)
    end
end)
function PluginShutdown()
    Event.MiniMenuEntrySelected.Unsubscribe(key)
    Event.Logic.Unsubscribe(key)
    Event.OptionalPermissionChanged.Unsubscribe(key)
end
report("startup",true)
