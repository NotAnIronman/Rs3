HTTP diagnostic v5 - single plugin, native results, no PrettyUI dependency

1. Run poff CLEHttpLab to stop the old batch.
2. Remove only the old diagnostic folders CLH00 through CLH21 from dev_plugins.
   Keep CollectionLogExpanded, PrettyUI and the CLEHttpLab folder.
3. Extract this ZIP into dev_plugins, replacing CLEHttpLab/main.lua and
   plugin.json. It contains one plugin folder, not 23.
4. Run prf then pon CLEHttpLab. Wait around 20 seconds. The console prints
   CLE_HTTP_V5 FIRST, then CLE_HTTP_V5 DONE and one CLE_HTTP_V5 ERROR line if
   native requests failed. Report those short lines; no batch transcript needed.
5. To see/copy the full report, open Settings -> Plugins -> Manage and choose
   the CLEHttpLab settings/gear icon. The plugin content/ribbon icon is another
   supported entry. These handlers use the component supplied by the client.
   Click the report field and try Ctrl+A, Ctrl+C. Screenshot it if clipboard is
   unavailable. The report is also saved as a String in THIS plugin's own
   PersistentDB under cle:http-lab:v5:text. No results folder or arbitrary .txt
   file is created. User can paste copied text into Notepad to create a file.

Four bounded public-data GET tests compare startup vs registered-plugin self
commands, full command names, and the Wiki vs Prices domain. Native HTTPRequest
validates permission; no permission function or native restriction is modified.
This uses only known canonical httpAccess, object dependency declarations and
native SDK UI. No PrettyUI or changing optional dependencies are needed. No
collection data, player data, gameplay actions or external messages are used.

Host-side checks cannot verify native permissions, rendering or clipboard. A
successful native HTTP 200 callback is required before claiming HTTP works.
