local key="cle-http-v5"
local folder="CLEHttpLab"
local storageKey="cle:http-lab:v5:text"
local entries,requests={},{}
local tick0,nextPhase,stopped,complete=nil,1,false,false
local saved,uiError,lastReport=false,nil,nil
local reportField
local function clean(value) return tostring(value):gsub("[\r\n]"," "):sub(1,600) end
local function permission()
    local ok,value=pcall(function() return Plugin.HasPermission(PluginPermissions.httpAccess) end)
    return ok and tostring(value) or "error:" .. clean(value)
end
local function command(value)
    local ok,err=pcall(function() ExecuteConsoleCommand(value) end)
    if not ok then return clean(err) end
end
local function textReport()
    local lines={"CLE HTTP diagnostic v5", "Native permission check: " .. permission(),
        "State: " .. (complete and "finished" or stopped and "stopped" or "running")}
    for i,entry in ipairs(entries) do
        lines[#lines+1]=i .. ". " .. entry.name .. " | " .. entry.status .. " | check=" .. entry.permission
        if entry.code then lines[#lines+1]="HTTP=" .. entry.code .. " success=" .. tostring(entry.successful) .. " bytes=" .. tostring(entry.bytes) end
        if entry.error then lines[#lines+1]="Error: " .. entry.error end
        if entry.commandError then lines[#lines+1]="Command: " .. entry.commandError end
    end
    if uiError then lines[#lines+1]="UI: " .. uiError end
    return table.concat(lines,"\n")
end
local function save()
    lastReport=textReport()
    local ok,result=pcall(function() return PersistentDB:SetString(storageKey,lastReport) end)
    saved=ok and result==true
    if reportField then pcall(function() reportField.content=lastReport end) end
end
local function finish(entry,status,errorValue)
    if entry.done or stopped then return end
    entry.done,entry.status,entry.error=true,status,errorValue and clean(errorValue) or nil
    save()
end
local function request(name,base,path,commands)
    local entry={name=name,status="starting",permission=permission(),done=false}
    entries[#entries+1]=entry
    for _,value in ipairs(commands or {}) do
        local err=command(value)
        if err then entry.commandError=err end
    end
    entry.permission=permission()
    local ok,object=pcall(function() return HTTPRequest.new(Plugin.urls[base],path) end)
    if not ok then finish(entry,"constructor-error",object);return entry end
    requests[#requests+1]={entry=entry,object=object}
    pcall(function() object:AddHeader("User-Agent","CollectionLogExpanded-HttpDiagnostic/0.0.5 (https://github.com/NotAnIronman/CollectionLogExpanded)") end)
    entry.status="waiting-for-callback"
    local sent,err=pcall(function()
        object:Get(function(response)
            if entry.done or stopped then return end
            local readOK,readError=pcall(function()
                entry.code=tonumber(response.responseCode) or 0
                entry.successful=response.successful==true
                entry.bytes=type(response.data)=="string" and #response.data or 0
                if response.failed then entry.errorCode=tostring(response.errorCode) end
            end)
            if readOK then finish(entry,"response") else finish(entry,"response-error",readError) end
        end)
    end)
    if not sent then finish(entry,"get-error",err) else save() end
    return entry
end
local function summarize()
    local successes,failed,pending,codes={},0,0,{}
    for i,entry in ipairs(entries) do
        if entry.code then codes[#codes+1]=i .. ":" .. entry.code end
        if entry.status=="response" and entry.code==200 and entry.successful then successes[#successes+1]=tostring(i)
        elseif entry.done then failed=failed+1 else pending=pending+1 end
    end
    return "ok=" .. (#successes>0 and table.concat(successes,",") or "none") .. " failed=" .. failed .. " pending=" .. pending .. " codes=" .. (#codes>0 and table.concat(codes,",") or "none") .. " saved=" .. tostring(saved)
end
local function show(parent)
    if not parent then print("CLE_HTTP_V5 UI_NO_PARENT");return end
    local ok,err=pcall(function()
        local title=ui.Text.new(parent)
        title:SetPos(8,8)
        title:SetSize(680,45)
        title.content="HTTP diagnostic: click the report field; try Ctrl+A, Ctrl+C to copy."
        title.font=id.Font.MUSEO_SANS_15PT_REGULAR
        title.rgba=0xFFFFFFFF
        local field=ui.InputField.new(parent)
        field:SetPos(8,58)
        field:SetSize(680,440)
        field.stylesheetID=id.StyleSheet.INPUT_DEFAULT
        field:Setup(ui.TextContentVisibilityMode.VISIBLE,ui.InputFieldFilterMode.NONE,16000)
        field.inputMode=ui.InputFieldKeyHandlingMode.DEFAULT
        field.text.font=id.Font.MUSEO_SANS_15PT_REGULAR
        field.text.rgba=0xFFFFFFFF
        field.content=lastReport or textReport()
        reportField=field
    end)
    if not ok then
        uiError=clean(err);print("CLE_HTTP_V5 UI_ERROR " .. uiError);save()
    end
end
print("CLE_HTTP_V5 START: one plugin, four request tests, no external dependencies")
local first=request("startup: native request after self grant","wiki","/api.php?action=query&meta=siteinfo&siprop=general&format=json",{
    "ppr " .. folder,"ppe " .. folder .. " httpAccess"})
print("CLE_HTTP_V5 FIRST check=" .. first.permission .. " " .. first.status .. (first.code and " HTTP=" .. first.code .. " success=" .. tostring(first.successful) or "") .. (first.error and ": " .. first.error or ""))
local function unsubscribe()
    pcall(function() Event.Logic.Unsubscribe(key) end)
end
Event.Logic.Subscribe(key,function(event)
    local ok,err=pcall(function()
        if not tick0 then tick0=event.logicTick end
        local elapsed=event.logicTick-tick0
        if nextPhase==1 and elapsed>=1 then
            nextPhase=2
            request("after registration: self grant","wiki","/api.php?action=query&meta=siteinfo&siprop=general&format=json",{
                "ppr " .. folder,"ppe " .. folder .. " httpAccess"})
        end
        if nextPhase==2 and elapsed>=100 then
            nextPhase=3
            request("full command names","wiki","/api.php?action=query&meta=siteinfo&siprop=general&format=json",{
                "plugins_permissions_request " .. folder,"plugins_permissions_enable " .. folder .. " httpAccess"})
        end
        if nextPhase==3 and elapsed>=200 then
            nextPhase=4
            request("prices domain comparison","prices","/api/v2/rs/latest?id=995")
        end
        if nextPhase==4 then
            local pending=false
            for _,entry in ipairs(entries) do if not entry.done then pending=true end end
            if elapsed>=850 then
                for _,active in ipairs(requests) do
                    if not active.entry.done then
                        finish(active.entry,"callback-timeout")
                        pcall(function() active.object:Cancel() end)
                    end
                end
                pending=false
            end
            if not pending then
                complete=true;save();unsubscribe()
                print("CLE_HTTP_V5 DONE " .. summarize())
                for _,entry in ipairs(entries) do
                    if entry.error then print("CLE_HTTP_V5 ERROR " .. entry.status .. ": " .. entry.error);break end
                end
            end
        end
    end)
    if not ok then
        print("CLE_HTTP_V5 RUN_ERROR " .. clean(err));uiError=clean(err);save();unsubscribe()
    end
end)
Event.SettingsLayerReady.Subscribe(key,function(event) show(event.component) end)
Event.ContentLayerReady.Subscribe(key,function(event) show(event.component) end)
function PluginShutdown()
    if not complete then save() end
    stopped=true;unsubscribe()
    pcall(function() Event.SettingsLayerReady.Unsubscribe(key) end)
    pcall(function() Event.ContentLayerReady.Unsubscribe(key) end)
    for _,active in ipairs(requests) do if not active.entry.done then pcall(function() active.object:Cancel() end) end end
    reportField=nil
end
return {GetReport=function() return lastReport or textReport() end}
