local util = require("lib/util")
local M = {}

function M.new(pretty, app)
    local self = { page=1, filter="", tab="drops", group=nil }
    local window, body, settingsView, dialog, rows = nil, nil, nil, nil, {}
    local summary, status

    local function objectFor(row)
        for _, itemID in ipairs(row.itemIDs or {}) do
            local object = util.try(function() return config.Obj.FromID(itemID) end)
            if object and util.normalise(object.name) == util.normalise(row.name) then return object end
        end
    end
    local function destroy(value) if value then pcall(function() value:Destroy() end) end end
    local function errorText(host, message)
        host:AddText({text=util.text(message),colour=0xEE9C73FF})
    end

    function self:refreshCounts()
        if status then status.content = util.text(app.status) end
        if summary and app.current then
            local obtained, total = app:completion(app.current,self.group)
            summary.content = string.format("%d / %d collected · %s",obtained,total,
                app.settings.unified and "Unified log · quantity matched" or "This creature")
        end
        for _, display in ipairs(rows) do
            local count = app:count(display.sourceKey,display.row)
            display.count.content = string.format("%s  ·  %d drops  ·  %d items",
                count.times > 0 and "Collected" or "Missing",count.times,count.units)
            display.count.rgba = count.times > 0 and 0x80CCA1FF or 0xB5AD9DFF
            display.icon:SetDisabled(count.times == 0)
            local object = objectFor(display.row)
            if object then display.icon:SetObject(object) end
        end
    end

    function self:record(catalog, row)
        destroy(dialog)
        local parent = ui.Interfaces:GetComponent(id.Component.TOPLEVEL_V2__PLUGIN_BUILD_LAYER_TOP)
        if not parent then return end
        dialog = pretty.Window.new(parent,{title="Log a received drop",width=400,height=280,x=80,y=80,scrollable=true})
        local active, receipt = true, app:receipt()
        dialog:AddText(util.text(catalog.title .. " · " .. row.name .. " ×" .. row.quantity.label))
        dialog:AddText(util.text("Rarity: " .. row.rarity .. (row.noted and " · noted" or "")))
        if row.notes~="" then dialog:AddText(util.text(row.notes)) end
        local field = dialog:AddTextField({text=row.quantity.min and row.quantity.min == row.quantity.max and tostring(row.quantity.min) or "",
            placeholder="Actual stack quantity",maxLength=12})
        local feedback = dialog:AddText("Record one occurrence of this drop.")
        dialog:AddFancyButton("Record drop",function()
            if not active then return end
            local quantity = tonumber(field:GetText())
            local ok, err = app:record(catalog.sourceKey,row,quantity,receipt)
            if ok then active=false; destroy(dialog); dialog=nil
            else feedback.content=util.text(err or "Could not save.") end
        end,{variant="positive"})
        dialog:AddSimpleButton("Cancel",function() active=false; destroy(dialog); dialog=nil end,{inline=true})
        dialog:Show()
    end

    local function renderReview(host)
        host:AddTitle("Review observed drops")
        host:AddText("Owned items near a recently attacked creature. Confirm the creature and quantity entry before adding them to your log.")
        if #app.pending == 0 then host:AddText("No drops waiting for review."); return end
        for index, pending in ipairs(app.pending) do
            local pendingIndex = index
            host:AddTitle(util.text(pending.name .. " ×" .. pending.quantity))
            for choiceIndex, choice in ipairs(pending.choices) do
                local selectedChoice = choiceIndex
                host:AddSimpleButton(util.text("Log for " .. choice.title .. " · " .. choice.rowKey:match("^(.-)|")
                    .. " · ×" .. tostring(choice.quantityLabel or pending.quantity)),function()
                    local ok, err = app:approve(pendingIndex,selectedChoice)
                    if not ok then app.status=err; self:render() end
                end)
            end
            host:AddSimpleButton("Dismiss",function() app:dismiss(pendingIndex) end)
        end
    end

    local function renderLibrary(host)
        host:AddTitle("Your creature library")
        local entries = app:library()
        if #entries == 0 then host:AddText("Examine a creature to add its verified Wiki table here.") end
        for _, entry in ipairs(entries) do
            local npc = entry
            host:AddSimpleButton(util.text(entry.name .. " · #" .. entry.id),function()
                self.tab,self.group,self.page="drops",nil,1
                app:select(npc)
            end)
        end
    end

    local function renderDrops(host)
        local catalog = app.current
        if app.pageChoices then
            host:AddTitle("Choose the matching Wiki page")
            host:AddText("These pages contain the same NPC ID.")
            for _, title in ipairs(app.pageChoices) do
                local pageTitle = title
                host:AddSimpleButton(util.text(title),function()
                    local npc = util.copy(app.selectedNPC); npc.pageTitle=pageTitle
                    app:select(npc,true)
                end)
            end
            return
        end
        if not catalog then
            if app.selectedNPC then
                host:AddTitle(util.text(app.selectedNPC.name .. " · NPC #" .. app.selectedNPC.id))
                host:AddText(app.busy and "Loading the Wiki drop table..." or "No drop table has loaded for this creature yet.")
                host:AddSimpleButton("Retry Wiki lookup",function() app:select(app.selectedNPC,true) end,{disabled=app.busy})
            else host:AddText("Examine an NPC in the game, or open a creature from your library.") end
            return
        end
        host:AddTitle(util.text(catalog.title .. " · NPC #" .. catalog.npcID))
        summary = host:AddText("")
        host:AddSimpleButton(app.settings.unified and "Unified: on" or "Unified: off",function()
            app:set("unified",not app.settings.unified)
        end)
        host:AddSimpleButton(app.settings.missingOnly and "Show all" or "Missing only",function()
            self.page=1; app:set("missingOnly",not app.settings.missingOnly)
        end,{inline=true})
        host:AddSimpleButton("Refresh Wiki",function() app:select(app.selectedNPC,true) end,{inline=true,disabled=app.busy})
        host:AddSimpleButton("Undo last",function() app:undo() end,{inline=true})
        local entries={{label="All Wiki tables",id=1}}
        local selectedID=1
        for index,group in ipairs(catalog.groups) do
            entries[#entries+1]={label=group,id=index+1}
            if group == self.group then selectedID=index+1 end
        end
        host:AddComboBox({entries=entries,selectedID=selectedID,onChange=function(_,choice)
            self.group=catalog.groups[choice-1]; self.page=1; self:render()
        end})
        host:AddTextField({text=self.filter,placeholder="Find a drop, then press Enter",maxLength=100,
            onSubmit=function(_,text) self.filter=util.normalise(text); self.page=1; self:render() end})
        host:AddText({text="Wiki variants and conditional drops are listed separately. Exact stacks and ranges keep separate progress.",colour=0xB5AD9DFF})
        local visible = {}
        for _, row in ipairs(catalog.rows) do
            if (not self.group or row.group==self.group) and util.normalise(row.name):find(self.filter,1,true)
                and (not app.settings.missingOnly or app:count(catalog.sourceKey,row).times==0) then visible[#visible+1]=row end
        end
        local pageSize=12
        local pages=math.max(1,math.ceil(#visible/pageSize))
        self.page=math.min(self.page,pages)
        host:AddSimpleButton("Previous",function() self.page=math.max(1,self.page-1); self:render() end,{disabled=self.page==1})
        host:AddText({text=self.page .. " / " .. pages .. " pages · " .. #visible .. " rows",inline=true})
        host:AddSimpleButton("Next",function() self.page=math.min(pages,self.page+1); self:render() end,{inline=true,disabled=self.page==pages})
        local shown={}
        for index=(self.page-1)*pageSize+1,math.min(#visible,self.page*pageSize) do
            local row=visible[index]
            shown[#shown+1]=row
            local panel=host:AddPanel({height=126,scrollable=false,backgroundAlpha=0.25})
            local icon=panel:AddItemSlot(objectFor(row),{size=36,tooltip=util.text(row.name .. " · " .. row.notes)})
            panel:AddText({text=util.text(row.name .. " ×" .. row.quantity.label),inline=true,width=360})
            panel:AddText({text=util.text(row.rarity .. " · " .. row.group .. " / " .. row.category),colour=0xC9B782FF})
            local count=panel:AddText("")
            panel:AddSimpleButton("Log drop",function() self:record(catalog,row) end,{inline=true})
            rows[#rows+1]={sourceKey=catalog.sourceKey,row=row,icon=icon,count=count}
        end
        host:AddText({text="Source: RuneScape Wiki · revision " .. tostring(catalog.revision or "unknown"),colour=0x9D9587FF})
        -- Only request icons for the current page, not every monster or every drop.
        app:icons(shown)
    end

    function self:render()
        if not window then return end
        destroy(body)
        rows, summary, status = {}, nil, nil
        local parent=window.content
        body=pretty.SimpleView.new(parent,{width=parent.width,height=parent.height})
        body:AddText({text="Character: " .. util.text(app.profileName or "Log in to track progress"),colour=0xB5AD9DFF})
        body:AddText({text=app.httpAllowed and "Wiki access: allowed" or "Wiki access: blocked",
            colour=app.httpAllowed and 0x80CCA1FF or 0xEE9C73FF})
        if not app.httpAllowed then
            body:AddText("Request access in the client console: ppr collection-log-expanded")
            body:AddText("Approve httpAccess to load new tables. Cached tables and saved progress remain available.")
        end
        status=body:AddText({text=util.text(app.status),height=42})
        body:AddSimpleButton("Drops",function() self.tab="drops";self:render() end)
        body:AddSimpleButton("Review (" .. #app.pending .. ")",function() self.tab="review";self:render() end,{inline=true})
        body:AddSimpleButton("Library",function() self.tab="library";self:render() end,{inline=true})
        if self.tab=="review" then renderReview(body)
        elseif self.tab=="library" then renderLibrary(body)
        else renderDrops(body) end
        self:refreshCounts()
    end

    function self:open(parent)
        if not window then
            parent=parent or ui.Interfaces:GetComponent(id.Component.TOPLEVEL_V2__PLUGIN_BUILD_LAYER_TOP)
            if not parent then app.status="Collection Log needs a loaded game interface.";return end
            window=pretty.Window.new(parent,{title="Collection Log Expanded",width=680,height=560,
                minWidth=480,minHeight=340,resizable=true,x=-340,y=-280,xAnchor=0.5,yAnchor=0.5,scrollable=false})
        end
        self:render();window:Show()
    end

    function self:settings(parent)
        destroy(settingsView)
        settingsView=pretty.SimpleView.new(parent,{width=parent.width,height=parent.height})
        settingsView:AddTitle("Collection Log Expanded")
        settingsView:AddText("Unified progress matches the same item and quantity definition across creatures. Local progress is kept in either mode.")
        settingsView:AddCheckboxButton({{text="Use unified collection log",value="unified",selected=app.settings.unified}},
            {onChange=function(_,_,_,selected) app:set("unified",selected) end})
        settingsView:AddText("Wiki access is optional. Previously cached drop tables remain available without it. No character data or loot history is uploaded.")
        settingsView:AddText("Request Wiki access in the client console: ppr collection-log-expanded")
        settingsView:AddText("Approve httpAccess. The collection window shows the current access status and retries the selected creature when access is granted.")
        settingsView:AddSimpleButton("Open collection log",function() self:open() end)
    end

    function self:resize()
        if body and window then
            local parent=window.content
            body:SetSize(parent.width,parent.height)
        end
    end

    function self:unmount()
        destroy(dialog);destroy(body);destroy(window);destroy(settingsView)
        dialog,body,window,settingsView=nil,nil,nil,nil
        rows,summary,status={},nil,nil
    end

    app.onChange=function(kind)
        if kind=="icons" or (kind=="counts" and not app.settings.missingOnly) then self:refreshCounts()
        else self:render() end
    end
    return self
end

return M
