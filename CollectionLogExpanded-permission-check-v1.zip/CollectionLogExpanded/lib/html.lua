local util = require("lib/util")
local M = {}

function M.text(html)
    local value = tostring(html or ""):gsub("<sup.-</sup>", "")
        :gsub("<[^>]*>", " ")
    value = value:gsub("&#[xX]([%x]+);", function(hex)
        return util.try(function() return utf8.char(tonumber(hex, 16)) end, "?")
    end):gsub("&#(%d+);", function(decimal)
        return util.try(function() return utf8.char(tonumber(decimal)) end, "?")
    end)
    local entities = { amp="&", lt="<", gt=">", quot='"', apos="'", nbsp=" ", ndash="–", mdash="—", times="×" }
    value = value:gsub("&(%a+);", function(name) return entities[name] or ("&" .. name .. ";") end)
    return util.trim(value:gsub("%s+", " "))
end

function M.attr(html, name)
    name = name:gsub("(%W)", "%%%1")
    return html:match(name .. '%s*=%s*"([^"]*)"') or html:match(name .. "%s*=%s*'([^']*)'")
end

function M.layout(html)
    assert(type(html) == "string" and #html <= 2097152, "Wiki page exceeds 2 MiB")
    local headings, rows = {}, {}
    for start, level, content in html:gmatch("()<h([2-6])[^>]*>(.-)</h[2-6]>") do
        headings[#headings + 1] = { pos=start, level=tonumber(level), label=M.text(content) }
    end
    local active, category, group, cursor = false, "Drops", "Drops", 1
    for start, attrs, body in html:gmatch("()<table([^>]*)>(.-)</table>") do
        while headings[cursor] and headings[cursor].pos < start do
            local h = headings[cursor]
            if h.level == 2 then
                active = h.label:lower():find("drops", 1, true) ~= nil
                group, category = h.label, h.label
            elseif active then
                if h.level == 3 and (h.label:lower():find("drop table", 1, true)
                    or h.label:lower():find("mode", 1, true)) then group = h.label end
                category = h.label
            end
            cursor = cursor + 1
        end
        if active and (attrs:find("item%-drops") or attrs:find("dropstable")) then
            for rowHTML in body:gmatch("<tr[^>]*>(.-)</tr>") do
                local cells = {}
                for cellAttrs, content in rowHTML:gmatch("<td([^>]*)>(.-)</td>") do
                    cells[#cells + 1] = { attrs=cellAttrs, html=content }
                end
                if #cells >= 4 then
                    local item = cells[2]
                    local itemLink = item.html:match("<a[^>]*>(.-)</a>")
                    rows[#rows + 1] = {
                        name=M.text(itemLink or item.html),
                        title=M.text(M.attr(item.html, "title") or (itemLink or item.html)),
                        quantity=M.text(cells[3].html),
                        rarity=M.attr(cells[4].html, "data-drop-fraction") or M.text(cells[4].html),
                        group=group, category=category,
                    }
                end
            end
        end
    end
    return rows
end

return M
