"""Reversible Blender sidebar pose checks; never creates an Action/keyframes."""


def rune_preview_poses():
    return [('neutral','Neutral',()),
            ('head_turn','Head turn',(('head','up',30),)),
            ('head_tilt','Head tilt',(('head','forward',20),)),
            ('shoulder_l','Left shoulder',(('clavicle.L','forward',30),)),
            ('shoulder_r','Right shoulder',(('clavicle.R','forward',-30),)),
            ('arm_l','Left arm',(('upper_arm.L','forward',45),)),
            ('arm_r','Right arm',(('upper_arm.R','forward',-45),)),
            ('elbow_l','Left elbow',(('forearm.L','left',60),)),
            ('elbow_r','Right elbow',(('forearm.R','left',60),)),
            ('wrist_l','Left wrist',(('hand.L','up',35),)),
            ('wrist_r','Right wrist',(('hand.R','up',35),)),
            ('hip_l','Left hip',(('thigh.L','left',35),)),
            ('hip_r','Right hip',(('thigh.R','left',35),)),
            ('knee_l','Left knee',(('shin.L','left',60),)),
            ('knee_r','Right knee',(('shin.R','left',60),))]


def register_rune_rig_preview(bpy):
    """Register once per Blender session. Also callable from a standalone Text."""
    if not hasattr(bpy,'types') or not hasattr(bpy,'props'):
        return {'status':'unavailable_in_offline_adapter'}
    if hasattr(bpy.types,'RUNERIG_PT_quick_check'):
        return {'status':'already_registered','location':'3D View > N sidebar > RuneRig'}
    from mathutils import Matrix,Vector
    import json,math,time
    backup_key='rune_rig_pose_preview_backup'

    def active_rig(context):
        obj=context.object
        if obj and obj.type=='MESH':
            obj=next((m.object for m in obj.modifiers if m.type=='ARMATURE' and m.object),None)
        return obj if obj and obj.type=='ARMATURE' and obj.get('source_rig_name') else None

    def restore(rig,clear=True):
        if rig is None or backup_key not in rig:return False
        saved=json.loads(rig[backup_key])
        for name,values in saved.items():
            bone=rig.pose.bones.get(name)
            if bone:bone.matrix_basis=Matrix(values)
        if clear:del rig[backup_key]
        return True

    def apply(rig,mode,sign):
        if rig.animation_data and (rig.animation_data.action or rig.animation_data.drivers or
                                  any(t.strips and not t.mute for t in rig.animation_data.nla_tracks)):
            raise RuntimeError('Use an unanimated conversion copy for pose checks; animation is left intact.')
        if any(b.constraints for b in rig.pose.bones):
            raise RuntimeError('Use an unconstrained conversion copy for pose checks.')
        moves=next((moves for key,label,moves in rune_preview_poses() if key==mode),None)
        if moves is None:raise RuntimeError('Unknown pose check.')
        if backup_key not in rig:
            rig[backup_key]=json.dumps({b.name:[list(row) for row in b.matrix_basis] for b in rig.pose.bones})
        restore(rig,False)
        pelvis=rig.data.bones.get('pelvis');head=rig.data.bones.get('head')
        if not pelvis or not head:raise RuntimeError('Pose checker requires pelvis and head controls.')
        up=(head.head_local-pelvis.head_local).normalized()
        forward=Vector((0,-1,0))
        if rig.get('fitted_landmarks_world_json'):
            m=json.loads(rig['fitted_landmarks_world_json'])
            forward=rig.matrix_world.to_3x3().inverted()@(Vector(m['forward'])-Vector(m['chest']))
        forward=(forward-up*forward.dot(up)).normalized()
        if forward.length<1e-8:forward=Vector((1,0,0))
        axes={'up':up,'forward':forward,'left':up.cross(forward).normalized()}
        for name,axis,degrees in moves:
            bone=rig.pose.bones.get(name)
            if bone is None:continue
            local_axis=(bone.bone.matrix_local.to_3x3().inverted()@axes[axis]).normalized()
            bone.matrix_basis=bone.matrix_basis@Matrix.Rotation(math.radians(degrees*sign),4,local_axis)

    class RUNERIG_OT_check_pose(bpy.types.Operator):
        bl_idname='runerig.check_pose';bl_label='Preview pose';bl_options={'REGISTER','UNDO'}
        mode:bpy.props.StringProperty(default='head_turn')
        sign:bpy.props.FloatProperty(default=1)
        def execute(self,context):
            if RUNERIG_OT_check_cycle.running:
                self.report({'WARNING'},'Stop the quick check before selecting a pose.');return {'CANCELLED'}
            rig=active_rig(context)
            if not rig:self.report({'ERROR'},'Select the converted RuneRig armature or body.');return {'CANCELLED'}
            try:apply(rig,self.mode,self.sign);context.view_layer.update()
            except Exception as error:
                restore(rig);self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'FINISHED'}

    class RUNERIG_OT_check_restore(bpy.types.Operator):
        bl_idname='runerig.check_restore';bl_label='Restore original pose';bl_options={'REGISTER','UNDO'}
        def execute(self,context):
            if RUNERIG_OT_check_cycle.running:
                RUNERIG_OT_check_cycle.running.cancel(context)
            rig=active_rig(context)
            if rig:restore(rig);context.view_layer.update()
            return {'FINISHED'}

    class RUNERIG_OT_check_cycle(bpy.types.Operator):
        bl_idname='runerig.check_cycle';bl_label='Run quick movement check'
        running=None
        def execute(self,context):
            if type(self).running:return {'CANCELLED'}
            self.rig=active_rig(context)
            if not self.rig:self.report({'ERROR'},'Select the converted RuneRig armature or body.');return {'CANCELLED'}
            self.steps=[('neutral',1)]+[(key,sign) for key,label,moves in rune_preview_poses() if moves for sign in (1,-1)]
            self.position=0;self.timer=None;self.next_step=time.monotonic()+1.2
            try:
                apply(self.rig,'neutral',1)
                self.timer=context.window_manager.event_timer_add(1.2,window=context.window)
                context.window_manager.modal_handler_add(self);type(self).running=self
            except Exception as error:
                self.cancel(context);self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'RUNNING_MODAL'}
        def modal(self,context,event):
            if type(self).running is not self:return {'CANCELLED'}
            if event.type in {'ESC','RIGHTMOUSE'}:self.cancel(context);return {'CANCELLED'}
            # Blender Event does not expose the originating timer. A monotonic
            # deadline ignores unrelated faster TIMER events in the same window.
            if event.type=='TIMER' and time.monotonic()>=self.next_step:
                try:
                    if self.position>=len(self.steps):self.cancel(context);return {'FINISHED'}
                    key,sign=self.steps[self.position];self.position+=1
                    self.next_step=time.monotonic()+1.2
                    apply(self.rig,key,sign);context.view_layer.update()
                except Exception as error:
                    self.cancel(context);self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'PASS_THROUGH'}
        def cancel(self,context):
            if self.timer:context.window_manager.event_timer_remove(self.timer);self.timer=None
            try:restore(self.rig);context.view_layer.update()
            except ReferenceError:pass
            type(self).running=None

    class RUNERIG_PT_quick_check(bpy.types.Panel):
        bl_label='RuneRig quick check';bl_idname='RUNERIG_PT_quick_check'
        bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='RuneRig'
        def draw(self,context):
            layout=self.layout;rig=active_rig(context)
            layout.label(text='Select the converted rig or body.')
            layout.operator('runerig.check_cycle',text='Run 35-second check',icon='PLAY')
            layout.operator('runerig.check_restore',text='Restore pose / stop')
            if not rig:return
            if backup_key in rig:layout.label(text='Preview active: restore before export.',icon='INFO')
            for key,label,moves in rune_preview_poses():
                if not moves:continue
                row=layout.row(align=True);row.label(text=label)
                for sign in (1,-1):
                    op=row.operator('runerig.check_pose',text='+' if sign==1 else '−');op.mode=key;op.sign=sign
            layout.label(text='No keyframes or Actions are created.')
    registered=[]
    try:
        for cls in (RUNERIG_OT_check_pose,RUNERIG_OT_check_restore,RUNERIG_OT_check_cycle,RUNERIG_PT_quick_check):
            bpy.utils.register_class(cls);registered.append(cls)
    except Exception:
        for cls in reversed(registered):bpy.utils.unregister_class(cls)
        raise
    return {'status':'registered','location':'3D View > N sidebar > RuneRig',
            'instructions':'Run quick check or choose an individual pose. Restore before export. Animation is not modified.'}


if __name__=='__main__':
    import bpy
    print(register_rune_rig_preview(bpy))
