local M = {}

function M.trim(value)
    return tostring(value or ""):match("^%s*(.-)%s*$")
end

function M.normalise(value)
    return M.trim(value):gsub("%s+", " "):lower()
end

function M.copy(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, child in pairs(value) do result[key] = M.copy(child) end
    return result
end

function M.integer(value, minimum)
    return type(value) == "number" and value == value and value < math.huge
        and value % 1 == 0 and value >= (minimum or 0)
end

function M.url(value)
    return (tostring(value):gsub("[^%w%-_%.~]", function(char)
        return string.format("%%%02X", string.byte(char))
    end))
end

function M.text(value)
    -- External labels must not become client markup or links.
    return tostring(value or ""):gsub("<", "("):gsub(">", ")")
end

function M.try(fn, fallback)
    local ok, result = pcall(fn)
    if ok then return result end
    return fallback
end

return M
