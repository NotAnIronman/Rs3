local util = require("lib/util")
local json = require("lib/json")
local M = {}

function M.new()
    local self, queue, active, nextTick, stopped = {}, {}, nil, 0, false
    self.store = {}
    function self.store:get(key)
        -- Read failures propagate: treating one as an empty log could overwrite data.
        return PersistentDB:GetStructuredData(key)
    end
    function self.store:set(key,value)
        local ok, result = pcall(function() return PersistentDB:SetStructuredData(key,value) end)
        if not ok then return false,tostring(result) end
        if result~=true then return false,"Client storage rejected the write" end
        return true
    end
    function self.store:delete(key)
        local ok,result=pcall(function() return PersistentDB:Delete(key) end)
        return ok and result==true
    end
    function self:hasHTTP()
        return Plugin.HasPermission(PluginPermissions.httpAccess)
    end
    local function finish(job, data, err)
        if job.done then return end
        job.done=true
        if active==job then active=nil end
        local ok, callbackError=pcall(job.callback,data,err)
        if not ok then log("Collection Log callback error:",tostring(callbackError)) end
    end
    function self:request(path, callback, lowPriority)
        if stopped then callback(nil,"Plugin is stopping.");return end
        if not self:hasHTTP() then callback(nil,"Wiki access is blocked. Run ppr collection-log-expanded in the client console and approve httpAccess, then retry the lookup.");return end
        if type(path)~="string" or not path:match("^/api%.php%?") or #path>14000 then
            callback(nil,"Invalid Wiki request.");return
        end
        if #queue>=200 then callback(nil,"Wiki request queue is full. Try again shortly.");return end
        local job={path=path,callback=callback,lowPriority=lowPriority==true}
        local index=#queue+1
        if not job.lowPriority then
            for i,queued in ipairs(queue) do if queued.lowPriority then index=i;break end end
        end
        table.insert(queue,index,job)
    end
    function self:cancel(reason)
        local previous=queue
        queue={}
        for _, job in ipairs(previous) do finish(job,nil,reason or "Wiki request cancelled.") end
        if active then
            local job=active
            -- Mark complete before Cancel, which may synchronously invoke callbacks.
            finish(job,nil,reason or "Wiki request cancelled.")
            pcall(function() job.request:Cancel() end)
        end
    end
    function self:step(tick)
        if stopped then return end
        if not self:hasHTTP() then self:cancel("Wiki access was revoked.");return end
        if active and tick-active.startedAt>1500 then
            local job=active
            finish(job,nil,"Wiki request timed out.")
            pcall(function() job.request:Cancel() end)
        end
        if active or #queue==0 or tick<nextTick then return end
        local job=table.remove(queue,1)
        active,job.startedAt,nextTick=job,tick,tick+50
        local ok, err=pcall(function()
            job.request=HTTPRequest.new(Plugin.urls.wiki,job.path)
            job.request:AddHeader("User-Agent","CollectionLogExpanded/0.1.1 (https://github.com/NotAnIronman/CollectionLogExpanded)")
            job.request:Get(function(response)
                if job.done then return end
                if not self:hasHTTP() then finish(job,nil,"Wiki access was revoked.");return end
                if not response.successful or response.responseCode~=200 then
                    finish(job,nil,"Wiki request failed (HTTP " .. tostring(response.responseCode) .. ").");return
                end
                local decoded, data=pcall(json.decode,response.data)
                if not decoded then finish(job,nil,"Wiki returned invalid or oversized JSON.");return end
                if type(data)=="table" and data.error then
                    local errorInfo=type(data.error)=="table" and (data.error.info or data.error.code) or data.error
                    finish(job,nil,"Wiki: " .. tostring(errorInfo));return
                end
                finish(job,data)
            end)
        end)
        if not ok then finish(job,nil,"Could not start Wiki request: " .. tostring(err)) end
    end
    function self:shutdown() stopped=true;self:cancel("Plugin disabled.") end
    return self
end

return M
