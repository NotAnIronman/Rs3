local util = require("lib/util")
local Ledger = require("lib/ledger")
local Catalog = require("lib/catalog")
local Wiki = require("lib/wiki")
local M = {}

function M.new(store, transport, clock)
    local wiki = Wiki.new(transport, clock)
    local self = { catalogs={}, pending={}, status="Examine a creature to open its drop table.",
        settings={unified=false, missingOnly=false}, sequence=0, busy=false }
    local ledger, profileKey, readOnly, selected, inflight, iconInflight = nil, nil, false, nil, {}, {}
    local selection = 0
    local library = store:get("cle:library:v1")
    if type(library) ~= "table" then library = {} end
    local cacheOrder=store:get("cle:cache-order:v1")
    if type(cacheOrder)~="table" then cacheOrder={} end
    local function retain(catalog)
        local id=catalog.npcID
        for i=#cacheOrder,1,-1 do if cacheOrder[i]==id then table.remove(cacheOrder,i) end end
        cacheOrder[#cacheOrder+1]=id
        while #cacheOrder>32 do
            local old=table.remove(cacheOrder,1)
            self.catalogs["npc:" .. tostring(old)]=nil
            store:delete("cle:catalog:v1:" .. tostring(old))
        end
        store:set("cle:cache-order:v1",cacheOrder)
    end
    self.onChange = function() end
    local savedSettings = store:get("cle:settings:v1")
    if type(savedSettings) == "table" then
        self.settings.unified = savedSettings.unified == true
        self.settings.missingOnly = savedSettings.missingOnly == true
    end
    local function change(kind) self.onChange(kind or "content") end
    local function save()
        if not ledger or readOnly or not profileKey then return false, "Collection storage is unavailable" end
        local ok, err = store:set(profileKey, { version=1, sequence=self.sequence,
            ledger=ledger:export(), pending=self.pending })
        if not ok then self.status = "Could not save progress: " .. tostring(err or "storage rejected the write") end
        return ok, err
    end

    function self:profile(name)
        if type(name) ~= "string" or util.trim(name) == "" then return end
        local key = "cle:character:v1:" .. util.normalise(name)
        if profileKey == key then return end
        profileKey, self.profileName, self.pending, self.sequence = key, name, {}, 0
        local saved = store:get(key)
        readOnly = false
        if saved ~= nil and (type(saved) ~= "table" or saved.version ~= 1 or not util.integer(saved.sequence)
            or type(saved.ledger)~="table" or type(saved.pending)~="table") then
            readOnly = true
            self.status = "Saved collection has an unsupported format. Original data has been preserved."
            ledger = Ledger.new()
        else
            local err
            ledger, err = Ledger.new(saved and saved.ledger)
            if not ledger then
                readOnly, self.status, ledger = true, tostring(err), Ledger.new()
            elseif saved then
                self.sequence = saved.sequence
                if type(saved.pending) == "table" and #saved.pending <= 50 then self.pending = saved.pending end
            end
        end
        change()
    end

    function self:leave()
        ledger, profileKey, self.profileName, self.pending = nil, nil, nil, {}
    end

    function self:set(name, value)
        if name ~= "unified" and name ~= "missingOnly" then return end
        local previous = self.settings[name]
        self.settings[name] = value == true
        local ok = store:set("cle:settings:v1", self.settings)
        if not ok then self.settings[name] = previous; self.status = "Could not save settings." end
        change()
    end

    function self:setHTTPAllowed(allowed)
        allowed = allowed == true
        if self.httpAllowed == allowed then return end
        self.httpAllowed = allowed
        if allowed and self.selectedNPC and not self.current and not self.busy then
            self:select(self.selectedNPC, true)
        else change("permissions") end
    end

    function self:select(npc, force)
        if not util.integer(npc.id) or type(npc.name) ~= "string" then return end
        selected, self.selectedNPC = util.copy(npc), util.copy(npc)
        selection = selection + 1
        local requestSelection = selection
        self.pageChoices = nil
        local sourceKey = "npc:" .. npc.id
        local cached = self.catalogs[sourceKey] or store:get("cle:catalog:v1:" .. npc.id)
        if Catalog.valid(cached) and cached.npcID == npc.id then
            self.catalogs[sourceKey], self.current = cached, cached
            retain(cached)
        else self.current = nil end
        if self.current and not force then self.busy=false; self.status = "Cached Wiki table. Refresh to check for updates."; change(); return end
        self.busy, self.status = true, "Finding Wiki page for " .. npc.name .. " (#" .. npc.id .. ")…"
        change()
        local requestKey = sourceKey .. "|" .. tostring(npc.pageTitle or "")
        -- Duplicate examination while loading keeps the existing request relevant.
        if inflight[requestKey] then inflight[requestKey].selection=requestSelection; return end
        local request = {selection=requestSelection}
        inflight[requestKey] = request
        wiki:load(npc, function(result, err, choices)
            inflight[requestKey] = nil
            if result then
                self.catalogs[sourceKey] = result
                store:set("cle:catalog:v1:" .. npc.id, result)
                retain(result)
                local found=false
                for _, entry in ipairs(library) do if entry.id == npc.id then entry.name=npc.name; found=true end end
                if not found then library[#library+1]={id=npc.id,name=npc.name} end
                store:set("cle:library:v1",library)
            end
            if selected and selection == request.selection then
                self.busy = false
                self.current = result or self.current
                self.pageChoices = choices
                self.status = result and ("Drop data from the RuneScape Wiki · " .. #result.rows .. " rows")
                    or (err or "Could not load Wiki drops")
                change()
            end
        end)
    end

    function self:count(sourceKey, row)
        return ledger and ledger:count(sourceKey, row, self.settings.unified) or {times=0, units=0}
    end

    function self:completion(catalog, group)
        if not ledger then return 0, 0 end
        return ledger:completion(catalog, self.settings.unified, group)
    end

    function self:receipt()
        self.sequence = self.sequence + 1
        return (profileKey or "unavailable") .. ":" .. self.sequence
    end

    function self:record(sourceKey, row, quantity, receipt, pendingIndex)
        if not ledger or readOnly then return false, "Log in to a character with available collection storage." end
        if not util.integer(quantity, 1) then return false, "Enter a positive whole quantity." end
        if row.quantity.min and (quantity < row.quantity.min or quantity > row.quantity.max) then
            return false, "Quantity does not match this drop entry."
        end
        local before, pendingBefore = ledger:export(), util.copy(self.pending)
        local ok, err = ledger:record(receipt, sourceKey, row, quantity)
        if not ok then return false, err end
        if pendingIndex then table.remove(self.pending, pendingIndex) end
        ok, err = save()
        if not ok then ledger = Ledger.new(before); self.pending = pendingBefore; change(); return false, err end
        self.status = "Logged " .. row.name .. " ×" .. quantity .. "."
        change(pendingIndex and "review" or "counts")
        return true
    end

    function self:propose(observation)
        if not ledger or readOnly then return end
        local choices, seen = {}, {}
        for _, source in ipairs(observation.sources) do
            local npcID=source.npcID or tonumber(source.sourceKey:match("^npc:(%d+)$"))
            local catalog = self.catalogs[source.sourceKey] or (npcID and store:get("cle:catalog:v1:" .. npcID))
            if Catalog.valid(catalog) then
                self.catalogs[source.sourceKey]=catalog
                for _, row in ipairs(catalog.rows) do
                    local key = catalog.sourceKey .. "|" .. row.rowKey
                    if Catalog.matches(row, observation.item, observation.quantity) and not seen[key] then
                        choices[#choices + 1] = { sourceKey=catalog.sourceKey,npcID=catalog.npcID,rowKey=row.rowKey,
                            title=catalog.title, quantityLabel=row.quantity.label .. (row.noted and " (noted)" or "") }
                        seen[key] = true
                    end
                end
            end
        end
        if #choices == 0 then return end
        local before = util.copy(self.pending)
        self.pending[#self.pending + 1] = { receipt=self:receipt(), name=observation.item.name,
            quantity=observation.quantity, choices=choices, reason=observation.reason }
        if #self.pending > 50 then table.remove(self.pending, 1) end
        local ok = save()
        if not ok then self.pending = before end
        change("review")
    end

    function self:undo()
        if not ledger or readOnly then return false,"Collection storage is unavailable." end
        local before=ledger:export()
        local ok,err=ledger:undo()
        if not ok then self.status=err;change("counts");return false,err end
        ok,err=save()
        if not ok then ledger=Ledger.new(before);change("counts");return false,err end
        self.status="Last recorded drop undone."
        change("counts")
        return true
    end

    function self:approve(index, choiceIndex)
        local entry = self.pending[index]
        local choice = entry and entry.choices[choiceIndex]
        local catalog = choice and choice.npcID and (self.catalogs["npc:" .. choice.npcID]
            or store:get("cle:catalog:v1:" .. choice.npcID))
        if not Catalog.valid(catalog) then return false, "Open this creature's table before confirming." end
        for _, row in ipairs(catalog.rows) do
            if row.rowKey == choice.rowKey then
                return self:record(choice.sourceKey, row, entry.quantity, entry.receipt, index)
            end
        end
        return false, "This drop entry changed after a Wiki refresh; log the correct entry manually."
    end

    function self:dismiss(index)
        local before = util.copy(self.pending)
        table.remove(self.pending, index)
        local ok = save()
        if not ok then self.pending = before end
        change("review")
    end

    function self:icons(rows)
        local requested = {}
        for _, row in ipairs(rows) do
            if not iconInflight[row.itemTitle] and not requested[row.itemTitle] and #(row.itemIDs or {}) == 0 then
                local title = row.itemTitle
                requested[title] = true
                local cachedIDs=store:get("cle:item-ids:v1:" .. title)
                if type(cachedIDs)=="table" then
                    local valid=true
                    for _,id in ipairs(cachedIDs) do if not util.integer(id) then valid=false end end
                    if valid and #cachedIDs>0 then
                        for _,sibling in ipairs(rows) do if sibling.itemTitle==title then sibling.itemIDs=cachedIDs end end
                    end
                end
                if #(row.itemIDs or {})>0 then
                    change("icons")
                else
                    iconInflight[title] = true
                    wiki:item(title, function(ids)
                        iconInflight[title] = nil
                        if not ids then return end
                        store:set("cle:item-ids:v1:" .. title,ids)
                        for _, catalog in pairs(self.catalogs) do
                            for _, sibling in ipairs(catalog.rows) do
                                if sibling.itemTitle == title then sibling.itemIDs = ids end
                            end
                        end
                        change("icons")
                    end)
                end
            end
        end
    end

    function self:library()
        local result = {}
        for _, entry in ipairs(library) do
            if util.integer(entry.id) and type(entry.name)=="string" then result[#result+1]=util.copy(entry) end
        end
        table.sort(result, function(a,b) return a.name < b.name end)
        return result
    end

    return self
end

return M
