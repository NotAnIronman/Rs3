local util = require("lib/util")
local M = {}

-- Ground-item ownership and NPC disappearance are evidence, not a kill receipt.
-- This module only proposes observations for review; it never changes counters.
function M.new(onProposal)
    local targets, drops, seen, warmUntil = {}, {}, {}, 150
    local self = {}

    function self:reset(tick)
        targets, drops, seen, warmUntil = {}, {}, {}, tick + 150
    end

    function self:attack(npc, tick)
        if not util.integer(npc.uid) or not util.integer(npc.id) or not npc.coord then return end
        targets[npc.uid] = { sourceKey="npc:" .. npc.id, npcID=npc.id, uid=npc.uid,
            name=npc.name, coord=util.copy(npc.coord), tick=tick }
    end

    function self:position(uid, coord, tick)
        if targets[uid] then targets[uid].coord = util.copy(coord); targets[uid].tick = tick end
    end

    function self:removed(uid, tick)
        if targets[uid] then targets[uid].removedAt = tick end
    end

    function self:owned(drop, tick)
        if tick < warmUntil or drop.isOwner ~= true or not drop.coord or not util.integer(drop.quantity, 1) then return end
        if type(drop.token) ~= "string" or seen[drop.token] then return end
        seen[drop.token] = tick
        drops[#drops + 1] = { token=drop.token, item=util.copy(drop.item), quantity=drop.quantity,
            coord=util.copy(drop.coord), tick=tick }
        if #drops > 64 then table.remove(drops, 1) end
    end

    function self:step(tick)
        for uid, target in pairs(targets) do
            if tick - target.tick > 1500 or (target.removedAt and tick - target.removedAt > 225) then targets[uid] = nil end
        end
        for token, at in pairs(seen) do if tick - at > 250 then seen[token] = nil end end
        for i = #drops, 1, -1 do
            local drop, sources, sourceSet = drops[i], {}, {}
            for _, target in pairs(targets) do
                local a, b = target.coord, drop.coord
                if target.removedAt and math.abs(drop.tick - target.removedAt) <= 100
                    and a.level == b.level and math.abs(a.x - b.x) <= 1 and math.abs(a.z - b.z) <= 1
                    and not sourceSet[target.sourceKey] then
                    sources[#sources + 1] = { sourceKey=target.sourceKey, name=target.name, npcID=target.npcID }
                    sourceSet[target.sourceKey] = true
                end
            end
            -- Wait two seconds so simultaneous candidates are considered together.
            if tick - drop.tick > 100 then
                table.remove(drops, i)
                if #sources > 0 then
                    onProposal({ item=drop.item, quantity=drop.quantity, sources=sources,
                        reason="Owned item near a recently attacked NPC that disappeared" })
                end
            end
        end
    end
    return self
end

return M
