local util = require("lib/util")
local M = {}
local MAX_COUNTER = 9007199254740991

function M.new(saved)
    if saved ~= nil and type(saved) ~= "table" then return nil, "Damaged collection data" end
    local state = saved and util.copy(saved) or { version=1, sources={}, unified={}, receipts={} }
    if state.version ~= 1 or type(state.sources) ~= "table" or type(state.unified) ~= "table"
        or type(state.receipts) ~= "table" then return nil, "Unsupported or damaged collection data; original storage was preserved" end
    for _, bucket in pairs(state.sources) do
        if type(bucket) ~= "table" then return nil, "Damaged source counters" end
        for _, count in pairs(bucket) do
            if type(count) ~= "table" or not util.integer(count.times) or not util.integer(count.units) then
                return nil, "Damaged collection counter"
            end
        end
    end
    for _, receipt in ipairs(state.receipts) do
        if type(receipt) ~= "string" then return nil, "Damaged receipt data" end
    end
    for _, count in pairs(state.unified) do
        if type(count) ~= "table" or not util.integer(count.times) or not util.integer(count.units) then
            return nil, "Damaged unified counter"
        end
    end
    local self = {}
    state.history = type(state.history)=="table" and state.history or {}

    function self:count(sourceKey, row, unified)
        local bucket = unified and state.unified or state.sources[sourceKey] or {}
        local counter = bucket[unified and row.dropKey or row.rowKey]
        return counter and util.copy(counter) or { times=0, units=0 }
    end

    function self:record(receipt, sourceKey, row, quantity)
        if type(receipt) ~= "string" or receipt == "" or type(sourceKey) ~= "string"
            or type(row.rowKey) ~= "string" or type(row.dropKey) ~= "string"
            or not util.integer(quantity, 1) then return false, "Invalid collection receipt" end
        for _, seen in ipairs(state.receipts) do if seen == receipt then return false, "Duplicate receipt" end end
        local current = self:count(sourceKey, row, false)
        local global = self:count(sourceKey, row, true)
        if math.max(current.times, global.times) >= MAX_COUNTER
            or math.max(current.units, global.units) > MAX_COUNTER - quantity then return false, "Counter limit reached" end
        state.sources[sourceKey] = state.sources[sourceKey] or {}
        state.sources[sourceKey][row.rowKey] = { times=current.times + 1, units=current.units + quantity }
        state.unified[row.dropKey] = { times=global.times + 1, units=global.units + quantity }
        state.receipts[#state.receipts + 1] = receipt
        -- De-duplicates retries; source counters, rather than an endless event history,
        -- carry long-term progress. The observation adapter also de-duplicates events.
        if #state.receipts > 256 then table.remove(state.receipts, 1) end
        state.history[#state.history+1]={sourceKey=sourceKey,rowKey=row.rowKey,dropKey=row.dropKey,quantity=quantity}
        if #state.history>64 then table.remove(state.history,1) end
        return true
    end

    function self:undo()
        local previous=state.history[#state.history]
        if not previous then return false,"No recent drop to undo." end
        local source=state.sources[previous.sourceKey]
        local localCount=source and source[previous.rowKey]
        local global=state.unified[previous.dropKey]
        if not localCount or not global or not util.integer(previous.quantity,1)
            or math.min(localCount.times,global.times)<1
            or math.min(localCount.units,global.units)<previous.quantity then return false,"Undo history is damaged." end
        localCount.times,localCount.units=localCount.times-1,localCount.units-previous.quantity
        global.times,global.units=global.times-1,global.units-previous.quantity
        if localCount.times==0 then source[previous.rowKey]=nil end
        if global.times==0 then state.unified[previous.dropKey]=nil end
        if next(source)==nil then state.sources[previous.sourceKey]=nil end
        table.remove(state.history)
        return true
    end

    function self:completion(catalog, unified, group)
        local seen, obtained, total = {}, 0, 0
        for _, row in ipairs(catalog.rows) do
            if (not group or row.group == group) and not seen[row.rowKey] then
                seen[row.rowKey], total = true, total + 1
                if self:count(catalog.sourceKey, row, unified).times > 0 then obtained = obtained + 1 end
            end
        end
        return obtained, total
    end

    function self:export() return util.copy(state) end
    return self
end

return M
