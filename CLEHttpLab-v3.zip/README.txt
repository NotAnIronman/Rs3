Collection Log Expanded HTTP diagnostic lab v3

Install and run
1. Extract all 23 folders directly into the same dev_plugins directory that
   contains CollectionLogExpanded. Do not move or replace that plugin.
2. In the beta client console run:
     prf
     pon CLEHttpLab
3. Wait approximately two minutes for CLE_HTTP_LAB RUNNER END, then copy
   CLE_HTTP_LAB output plus client errors. Close the console to respond to any
   permission prompt if shown. If an error prevents automatic commands, the
   individual commands are listed in Manual-commands.txt.
4. Stop and clean up when finished:
     poff CLEHttpLab
   This disables all CLH00-CLH21 test plugins. You may then remove ONLY the
   CLEHttpLab and CLH00-CLH21 folders you installed, and run prf.

What it does
The runner invokes documented plugin management commands. Each case logs its
entry, permission-check results, exposed URL type, and exact native constructor,
GET or response outcome. After grants, each HTTP case attempts at most one
public-data GET via the native HTTPRequest API, even if the permission query
still reports false. The native API remains responsible for access checks; no
permission function, client code, sandbox or restriction is modified. The
control performs no HTTP request. Results contain only status and byte counts,
not response bodies or account information. A response with a non-200 HTTP code
still establishes that a request reached the HTTP layer, not that Wiki lookup
works. A dispatched request without a callback is not success.

All code is original diagnostic code. No dependencies, PrettyUI, player data,
collections, PersistentDB, filesystem access, gameplay actions or external
messages are used. Existing collection-plugin files and saved data are untouched.
The lab and its host-side tools are kept in the ignored development directory.
The host-side Lua simulations validate logging/scheduling, not native access.

Variants are listed in Experiments.json. Speculative spellings are experiments,
not supported configuration recommendations. A successful case must be narrowed
and retested before changing the production manifest or request logic.

Primary references
https://developer.runescape.com/rs/core/http.html
https://developer.runescape.com/rs/core/plugin.html
https://developer.runescape.com/rs/managing.html
https://developer.runescape.com/rs/core/index.html#executeconsolecommand
https://github.com/CerenMD/ge-prices-library/blob/main/plugin.json
https://github.com/CerenMD/ge-prices-library/blob/main/main.lua
