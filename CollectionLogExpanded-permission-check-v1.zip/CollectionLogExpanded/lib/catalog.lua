local util = require("lib/util")
local json = require("lib/json")
local html = require("lib/html")
local M = {}

function M.quantity(text, low, high)
    text = util.trim(text):gsub(",", ""):gsub("–", "-"):gsub("—", "-")
    local a, b = text:match("^(%d+)%s*%-%s*(%d+)$")
    if not a then a = text:match("^(%d+)$"); b = a end
    if util.integer(low, 1) and util.integer(high, 1) then a, b = low, high end
    a, b = tonumber(a), tonumber(b)
    if a and b and a >= 1 and b >= a then
        return { key=tostring(a) .. ":" .. tostring(b), min=a, max=b,
            label=a == b and tostring(a) or (a .. "–" .. b) }
    end
    -- Unknown/conditional quantities remain distinct and require manual logging.
    return { key="text:" .. util.normalise(text), label=text ~= "" and text or "Unknown" }
end

function M.dropKey(item, quantity, noted)
    -- Quantity SPECIFICATION is part of identity. 5 != 5–10 != 5–15.
    return "wiki:" .. util.trim(item) .. "|q:" .. quantity.key .. "|" .. (noted and "noted" or "plain")
end

function M.resolveIdentity(rows, npcID, preferredTitle)
    assert(util.integer(npcID, 0), "Invalid NPC ID")
    local matches, identities = {}, {}
    for _, row in ipairs(rows) do
        if type(row) == "table" and type(row.page_name) == "string" and type(row.id) == "table"
            and (not preferredTitle or row.page_name == preferredTitle) then
            for _, id in ipairs(row.id) do
                if tonumber(id) == npcID then
                    local key = row.page_name .. "|" .. tostring(row.dropversion or "")
                    if not identities[key] then
                        matches[#matches + 1] = { title=row.page_name, variant=row.dropversion, npcID=npcID }
                        identities[key] = true
                    end
                end
            end
        end
    end
    local title, pages, seenPages = nil, {}, {}
    for _, match in ipairs(matches) do
        if not seenPages[match.title] then pages[#pages+1]=match.title; seenPages[match.title]=true end
        title = match.title
    end
    if #pages > 1 then return nil, "Multiple Wiki pages match NPC ID " .. npcID, pages end
    if not title then return nil, "The Wiki has no verified page for NPC ID " .. npcID end
    return { title=title, npcID=npcID, variants=matches }
end

-- Some pages omit infobox IDs but list them in their location templates.
function M.locationIDs(source, npcName)
    if type(source)~="string" then return {} end
    source=source:gsub("<!%-%-.-%-%->",""):gsub("<nowiki[^>]*>.-</nowiki%s*>","")
    local lines,inside,level={},false,nil
    for line in (source .. "\n"):gmatch("([^\n]*)\n") do
        local marks,title,ending=line:match("^%s*(==+)%s*(.-)%s*(==+)%s*$")
        if marks and #marks==#ending then
            if inside and #marks<=level then break end
            if util.normalise(title)=="locations" or util.normalise(title)=="location" then
                inside,level=true,#marks
            end
        elseif inside then lines[#lines+1]=line end
    end
    local section=table.concat(lines,"\n")
    local ids,seen,cursor={},{},1
    while true do
        local first=section:find("{{",cursor,true)
        if not first then break end
        local depth,position,last=1,first+2,nil
        while depth>0 do
            local opening=section:find("{{",position,true)
            local closing=section:find("}}",position,true)
            if not closing then break end
            if opening and opening<closing then depth=depth+1;position=opening+2
            else depth=depth-1;position=closing+2;last=position-1 end
        end
        if depth>0 then break end
        local block=section:sub(first,last)
        local name=util.normalise(block:match("^{{%s*([^|}\r\n]+)") or "")
        if name=="locline" or name=="monster map" or name=="npc map" then
            local ownName=block:match("|%s*name%s*=%s*([^|}\r\n]+)")
                or block:match("|%s*npcname%s*=%s*([^|}\r\n]+)")
            if not ownName or util.normalise(ownName)==util.normalise(npcName) then
                for value in block:gmatch("[|,]%s*npcid%s*:%s*(%d+)%s*[,|}]") do
                    local id=tonumber(value)
                    if util.integer(id,0) and not seen[id] then ids[#ids+1]=id;seen[id]=true end
                end
            end
        end
        cursor=last+1
    end
    return ids
end

local function fingerprint(name, quantity, rarity)
    local q = type(quantity) == "table" and quantity or M.quantity(quantity)
    return util.normalise(name) .. "|" .. q.key .. "|" .. util.normalise(rarity):gsub(",", "")
end

local function notes(values)
    local out = {}
    if type(values) == "table" then
        for _, value in ipairs(values) do
            if type(value) == "table" and type(value.content) == "string" then
                out[#out + 1] = html.text(value.content)
            elseif type(value) == "string" then out[#out + 1] = html.text(value) end
        end
    end
    return (table.concat(out, " "):gsub("%[%[[^|%]]+|([^%]]+)%]%]","%1")
        :gsub("%[%[([^%]]+)%]%]","%1"):gsub("''+",""))
end

function M.build(identity, bucketRows, rendered, fetchedAt)
    assert(type(bucketRows) == "table", "Invalid Wiki drop rows")
    local appearances, renderedRows = {}, html.layout(rendered or "")
    for _, row in ipairs(renderedRows) do
        local key = fingerprint(row.name, row.quantity, row.rarity)
        appearances[key] = appearances[key] or {}
        table.insert(appearances[key], row)
    end
    -- Numeric IDs resolve the page. Cosmetic IDs sharing that page share progress;
    -- table groups within the page remain separate through each row's rowKey.
    local result = { version=1, npcID=identity.npcID, sourceKey="wiki:" .. identity.title,
        title=identity.title, variants=identity.variants, fetchedAt=fetchedAt,
        url="https://runescape.wiki/w/" .. util.url(identity.title:gsub(" ", "_")),
        rows={}, groups={}, unclassified=0 }
    local groups = {}
    for _, source in ipairs(bucketRows) do
        if type(source) == "table" and type(source.item_name) == "string" and type(source.drop_json) == "string" then
            local raw = json.decode(source.drop_json)
            if type(raw) ~= "table" or raw == json.null then error("Invalid drop metadata") end
            local name = source.item_name
            if util.normalise(name) ~= "nothing" and name ~= "" then
                local rarity = tostring(raw.Rarity or "Unknown")
                local quantity = M.quantity(raw["Drop Quantity"], raw["Quantity Low"], raw["Quantity High"])
                local layoutKey = fingerprint(name, quantity, rarity)
                local slots = appearances[layoutKey]
                local appearance = slots and table.remove(slots, 1)
                local group = appearance and appearance.group or "Unclassified Wiki rows"
                local category = appearance and appearance.category or "Drops"
                if not appearance then result.unclassified = result.unclassified + 1 end
                local quantityNotes = notes(raw["Quantity Notes"])
                local noted = (quantityNotes .. " " .. tostring(raw["Drop Quantity"])):lower():find("noted", 1, true) ~= nil
                local itemTitle = appearance and appearance.title or name
                local dropKey = M.dropKey(itemTitle, quantity, noted)
                local row = { name=name, itemTitle=itemTitle,
                    quantity=quantity, rarity=rarity, group=group, category=category,
                    noted=noted, dropKey=dropKey, rowKey=group .. "|" .. dropKey,
                    notes=util.trim(notes(raw["Rarity Notes"]) .. " " .. quantityNotes .. " " .. html.text(raw["Name Notes"])),
                    itemIDs={} }
                local alternatives={}
                if type(raw["Alt Rarities"])=="table" then
                    for _, rate in ipairs(raw["Alt Rarities"]) do
                        if type(rate)=="string" or type(rate)=="number" then alternatives[#alternatives+1]=tostring(rate) end
                    end
                end
                if #alternatives>0 then row.notes=util.trim(row.notes .. " Alternate rates: " .. table.concat(alternatives,", ")) end
                if util.integer(raw.Rolls,2) then row.notes=util.trim(row.notes .. " Rolls: " .. raw.Rolls) end
                result.rows[#result.rows + 1] = row
                if not groups[group] then result.groups[#result.groups + 1] = group; groups[group] = true end
            end
        end
    end
    if #result.rows > 1500 then error("Wiki table exceeds 1,500 rows") end
    if #result.rows == 0 then error("The verified Wiki page has no supported drop rows") end
    return result
end

function M.matches(row, item, quantity)
    if not util.integer(quantity, 1) then return false end
    local exactID = false
    for _, id in ipairs(row.itemIDs or {}) do if id == item.id then exactID = true end end
    if not exactID and util.normalise(row.name) ~= util.normalise(item.name) then return false end
    if item.noted ~= nil and row.noted ~= item.noted then return false end
    local q = row.quantity
    return q.min ~= nil and quantity >= q.min and quantity <= q.max
end

function M.valid(value)
    if type(value)~="table" or value.version~=1 or not util.integer(value.npcID)
        or type(value.title)~="string" or value.sourceKey~="wiki:" .. value.title
        or type(value.rows)~="table" or #value.rows==0 or #value.rows>1500
        or type(value.groups)~="table" then return false end
    for _,group in ipairs(value.groups) do if type(group)~="string" then return false end end
    for _,row in ipairs(value.rows) do
        if type(row)~="table" or type(row.name)~="string" or type(row.itemTitle)~="string"
            or type(row.group)~="string" or type(row.category)~="string" or type(row.rarity)~="string"
            or type(row.notes)~="string" or type(row.noted)~="boolean" or type(row.quantity)~="table"
            or type(row.quantity.key)~="string" or type(row.quantity.label)~="string" then return false end
        if row.quantity.min~=nil and (not util.integer(row.quantity.min,1)
            or not util.integer(row.quantity.max,row.quantity.min)) then return false end
        if row.dropKey~=M.dropKey(row.itemTitle,row.quantity,row.noted)
            or row.rowKey~=row.group .. "|" .. row.dropKey or type(row.itemIDs)~="table" then return false end
        for _,id in ipairs(row.itemIDs) do if not util.integer(id) then return false end end
    end
    return true
end

return M
