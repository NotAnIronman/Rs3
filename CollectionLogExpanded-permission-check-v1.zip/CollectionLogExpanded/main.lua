local function clePermissionCheck()
    local ok,value=pcall(function() return Plugin.HasPermission(PluginPermissions.httpAccess) end)
    return ok and tostring(value) or "error:" .. tostring(value)
end
local function clePermissionGrant()
    local ok,err=pcall(function()
        ExecuteConsoleCommand("ppr CollectionLogExpanded")
        ExecuteConsoleCommand("ppe CollectionLogExpanded httpAccess")
    end)
    if not ok then print("CLE_MAIN_PERMISSION COMMAND_ERROR " .. tostring(err)) end
end
print("CLE_MAIN_PERMISSION v1 START before=" .. clePermissionCheck())
clePermissionGrant()
print("CLE_MAIN_PERMISSION AFTER_SELF_GRANT root=" .. clePermissionCheck())
-- Collection Log Expanded: native RS3 client plugin.
local util = require("lib/util")
local Client = require("lib/client")
local App = require("lib/app")
local Observer = require("lib/observer")
local View = require("lib/view")

if not prettyui then error("Collection Log Expanded requires PrettyUI (mod.io 6398181).") end
local client=Client.new()
print("CLE_MAIN_PERMISSION MODULE root=" .. clePermissionCheck() .. " helper=" .. tostring(client:hasHTTP()))
local app=App.new(client.store,function(path,callback,lowPriority)
    client:request(path,callback,lowPriority)
end,function() return os and os.time and os.time() or 0 end)
local view=View.new(prettyui,app)
app:setHTTPAllowed(client:hasHTTP())
local function syncHTTPAccess()
    local allowed=client:hasHTTP()
    if allowed==app.httpAllowed then return end
    if not allowed then client:cancel("Wiki access was revoked.") end
    app:setHTTPAllowed(allowed)
    log("Collection Log Expanded Wiki access:",allowed and "allowed" or "blocked")
end
local observer=Observer.new(function(proposal) app:propose(proposal) end)
local tick,stackSequence=0,0
local stacks=setmetatable({},{__mode="k"})
local watched,subscriptions={},{}
local function subscribe(name, callback)
    Event[name].Subscribe("collection-log-expanded",function(payload)
        local ok,err=pcall(callback,payload)
        if not ok then log("Collection Log event error (" .. name .. "):",tostring(err)) end
    end)
    subscriptions[#subscriptions+1]=name
end
local function coord(entity)
    local c=entity.coordGrid
    return c and {x=c.x,z=c.z,level=c.level}
end
local function npcSnapshot(entity)
    if not entity or not entity.isValid then return nil end
    return {id=entity.configID,name=entity.config and entity.config.name or entity.displayName,
        uid=entity.uid,coord=coord(entity)}
end
local function profile()
    if not Player.IsAvailable() then return end
    local entity=Player.GetEntity()
    if entity and entity.isValid then app:profile(entity.displayName) end
end
local function reset()
    observer:reset(tick)
    watched,stacks={},setmetatable({},{__mode="k"})
end

subscribe("Logic",function(event)
    tick=event.logicTick
    if tick%50==0 then syncHTTPAccess() end
    client:step(tick)
    observer:step(tick)
    if tick%50==0 then view:resize() end
end)
subscribe("ServerLogic",function()
    profile()
    for uid,at in pairs(watched) do
        if tick-at>1500 then watched[uid]=nil
        else
            local found=false
            for _, entity in ipairs(NPCList.ByUID(uid)) do
                if entity.isValid then observer:position(uid,coord(entity),tick);found=true end
            end
            if not found then observer:removed(uid,tick);watched[uid]=nil end
        end
    end
end)
subscribe("MiniMenuEntrySelected",function(event)
    local entry=event.entry
    if not entry or not entry.npcData then return end
    local npc=npcSnapshot(entry.npcData.entity)
    if not npc then return end
    if entry.actionVerbType==MiniMenuActionVerbType.EXAMINE then
        profile()
        view.page,view.group,view.filter,view.tab=1,nil,"","drops"
        app:select(npc)
        view:open()
    elseif entry.actionVerbType==MiniMenuActionVerbType.ATTACK then
        observer:attack(npc,tick);watched[npc.uid]=tick
    end
end)
subscribe("NPCEntityRemoved",function(event)
    local uid=util.try(function() return event.npcEntity.uid end)
    if uid then observer:removed(uid,tick);watched[uid]=nil end
end)

local function ground(event,changed)
    local entity=event.objStackEntity
    if not entity or not entity.isValid or not event.objType then return end
    local id=event.objType.id
    local state=stacks[entity]
    if not state then stackSequence=stackSequence+1;state={serial=stackSequence,items={}};stacks[entity]=state end
    local amount=changed and event.newCount or event.count
    if not util.integer(amount) then return end
    local before=changed and event.oldCount or 0
    local previous=state.items[id]
    state.items[id]={amount=amount,tick=tick}
    if previous and previous.amount==amount and previous.tick==tick then return end
    local delta=amount-(before or 0)
    if delta<=0 then return end
    observer:owned({token=state.serial .. ":" .. id .. ":" .. tick .. ":" .. amount,
        item={id=id,name=event.objType.name},quantity=delta,coord=coord(entity),isOwner=event.isOwner},tick)
end
subscribe("ObjStackEntityAdded",function(event) ground(event,false) end)
subscribe("ObjStackEntityChanged",function(event) ground(event,true) end)
subscribe("GameStateChanged",function(event)
    reset()
    if event.newState~=GameState.GAME then view:unmount();app:leave() else profile() end
end)
subscribe("WorldCreated",reset)
subscribe("RegionCreated",reset)
subscribe("SettingsLayerReady",function(event) view:settings(event.component) end)
subscribe("ContentLayerReady",function() view:open() end)
subscribe("WindowSizeChanged",function() view:resize() end)
subscribe("OptionalPermissionChanged",function(event)
    if event.permissionName=="httpAccess" then syncHTTPAccess() end
end)

function PluginShutdown()
    for _,name in ipairs(subscriptions) do Event[name].Unsubscribe("collection-log-expanded") end
    client:shutdown()
    view:unmount()
end

Event.Logic.Subscribe("cle-main-permission-check",function()
    Event.Logic.Unsubscribe("cle-main-permission-check")
    if clePermissionCheck()~="true" then clePermissionGrant() end
    syncHTTPAccess()
    print("CLE_MAIN_PERMISSION REGISTERED root=" .. clePermissionCheck() .. " helper=" .. tostring(client:hasHTTP()))
end)
local cleOriginalShutdown=PluginShutdown
function PluginShutdown()
    Event.Logic.Unsubscribe("cle-main-permission-check")
    cleOriginalShutdown()
end
profile()
log("Collection Log Expanded 0.1.1 enabled. Wiki access:",app.httpAllowed and "allowed" or "blocked")
return { Open=function() view:open() end }
