local M = {}
function M.hasHTTP()
    return Plugin.HasPermission(PluginPermissions.httpAccess)
end
return M
