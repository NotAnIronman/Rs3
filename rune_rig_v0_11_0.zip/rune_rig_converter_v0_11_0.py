"""Rune Rig converter: reviewed Moia profile, named humanoid rigs, guided reconstruction.

Run this in Blender's Text Editor with the ORIGINAL imported armature selected.
Creates independent mesh/armature copies and validates them. On success,
source objects are deleted by default when no external dependencies need them.
The result is a named FK authoring rig; it does not include IK or retarget clips.
"""

import json
import math
import hashlib
import struct

# True: 70 bones, including three joints per finger. False: 40 bones, rigid hands.
KEEP_FINGERS = True
# Shift the new character beside the source for comparison, in Blender units.
# Zero leaves it in the source location; source cleanup follows validation.
OUTPUT_OFFSET = (0.0, 0.0, 0.0)
HIDE_SOURCE_AFTER_SUCCESS = True
CREATE_JAW_OPEN_SHAPE = True
JAW_OPEN_DEGREES = 20.0
# Configure a detected Saturday06 VRM add-on using its VRM 0.x property API.
# Metadata/license fields still need your own choices before exporting.
CONFIGURE_VRM0 = True
PRESET_VERSION = "moia-1.2"
# Mesh cleanup is allowed by default. Skeleton and current weights are checked
# separately; an ordered mesh fingerprint is diagnostic, not character identity.
STRICT_MESH_REFERENCE = False
NORMALIZE_SOURCE_WEIGHTS = True


# AUTO: Moia layout, recognized humanoid names/VRM roles, then guided workflow.
# GUIDED: force the landmark workflow, including for a recognized skeleton.
CONVERSION_MODE = "AUTO"
# Optional role overrides for a chained source rig; keys use VRM0 role names.
# Example: {"hips": "bone_1", "head": "bone_112", ...}
HUMANOID_ROLE_BONES = {}
# For guided fitting, run once to create markers, position them, then set True.
# This explicit switch prevents treating an unreviewed template as fitted joints.
GUIDED_LANDMARKS_READY = False
# Approximate template orientation in WORLD space; set for unfamiliar imports.
# Bill's inspected import uses up +Z and forward -Y. Templates are only seeds.
GUIDED_UP = (0, 0, 1)
GUIDED_FORWARD = (0, -1, 0)
# Rotate mesh and joints together to Blender +Y forward/+Z up for VRM 0.x.
# Off by default: keep the imported orientation that you intend to export.
CANONICALIZE_FOR_VRM0 = False
# Guided labels are checked against RR_forward, never against fixed world X.
# If ALL tested pairs are reversed, repair the complete L/R landmark labelling.
AUTO_REPAIR_GUIDED_SIDES = True
GUIDED_WEIGHT_METHOD = 'REGION_SOLVE'  # REGION_SOLVE, SURFACE (0.8.1), or DISTANCE
# CPU, NumPy only: original skin regions provide soft evidence, not rigid labels.
REGION_SOLVE_MAX_ITERATIONS = 180
REGION_SOLVE_TOLERANCE = 0.00001
REGION_SOLVE_SMOOTHNESS = 0.65
MERGE_NEARBY_VERTICES = True
MERGE_DISTANCE_RELATIVE = 0.00001  # fraction of largest mesh dimension; output only
JOIN_BODY_MESHES = True  # compatible output copies; sources stay intact until validation
JOIN_NORMAL_ANGLE_TOLERANCE_DEGREES = 0.1  # allows custom-normal encoding roundoff
GUIDED_HEAD_POLICY = 'FITTED_HEAD'  # FITTED_HEAD, RIGID_UPPER_HEAD, or SURFACE
# Retain these objects, outside body conversion and source deletion. A simple
# imported Armature modifier is frozen in its current pose after success.
# RuneApps body pieces retain Mesh_<number>. Any renamed bound mesh is a
# user-declared accessory, regardless of the chosen name.
BODY_MESH_POLICY = 'RUNEAPPS_NAMES'  # or EXPLICIT for other import naming schemes
EXCLUDED_OBJECT_NAMES = ()  # optional explicit exclusions under either policy
# Exact object names, ignoring Blender's .001 suffix. Keep props out of body seams.
SEPARATE_ACCESSORY_MESHES = ('Staff', 'Crown', 'Sword', 'Shield', 'Bow', 'Weapon')
# Optional rigid attachment in the GUIDED route, after inspecting its hand/side.
# Example: {'Staff':'hand.R'}. No attachment side is guessed automatically.
GUIDED_OBJECT_TARGETS = {}
BAKE_GUIDED_VERTEX_COLORS = True  # export-safe texture, only color-dependent materials
COLOR_BAKE_TILE_PIXELS = 16
DELETE_SOURCE_AFTER_SUCCESS = True  # validated conversion only; dependency check
# AUTO can reuse a successfully fitted profile from this .blend's Text blocks.
# For another .blend, paste the profile Text's JSON between these triple quotes.
GUIDED_PROFILE_JSON = """"""
REUSE_GUIDED_PROFILES = True
# Exact reviewed assets replay captured manual corrections. GUIDED mode always
# refits normally; turn this off to compare AUTO against generic fitting too.
USE_REVIEWED_CORRECTIONS = False  # exact asset replay is optional, not generic learning
# Optional whole-source-region assignments for guided reconstruction only.
# Example AFTER checking the region: {"bone_180": "head"} for a beard.
# RR:<target> vertex groups take precedence. Unmapped skin uses geometry.
GUIDED_SOURCE_REGION_TARGETS = {}
GENERIC_PLAN = None
UNIVERSAL_VERSION = "rune-rig-0.11.0"



EXPECTED_SOURCE = json.loads(r'''{"parents":{"bone_0":null,"bone_1":"bone_0","bone_2":"bone_1","bone_3":"bone_2","bone_4":"bone_3","bone_5":"bone_4","bone_6":"bone_5","bone_7":"bone_6","bone_8":"bone_7","bone_9":"bone_1","bone_10":"bone_1","bone_11":"bone_10","bone_12":"bone_11","bone_13":"bone_12","bone_14":"bone_13","bone_15":"bone_1","bone_16":"bone_15","bone_17":"bone_15","bone_18":"bone_17","bone_19":"bone_18","bone_20":"bone_19","bone_21":"bone_20","bone_22":"bone_21","bone_23":"bone_15","bone_24":"bone_23","bone_25":"bone_24","bone_26":"bone_25","bone_27":"bone_26","bone_28":"bone_27","bone_29":"bone_1","bone_30":"bone_1","bone_31":"bone_30","bone_32":"bone_31","bone_33":"bone_32","bone_34":"bone_33","bone_35":"bone_1","bone_36":"bone_35","bone_37":"bone_35","bone_38":"bone_37","bone_39":"bone_38","bone_40":"bone_39","bone_41":"bone_40","bone_42":"bone_41","bone_43":"bone_35","bone_44":"bone_43","bone_45":"bone_44","bone_46":"bone_45","bone_47":"bone_46","bone_48":"bone_47","bone_49":"bone_1","bone_50":"bone_49","bone_51":"bone_50","bone_52":"bone_51","bone_53":"bone_52","bone_54":"bone_53","bone_55":"bone_54","bone_56":"bone_1","bone_57":"bone_56","bone_58":"bone_57","bone_59":"bone_58","bone_60":"bone_59","bone_61":"bone_59","bone_62":"bone_61","bone_63":"bone_62","bone_64":"bone_63","bone_65":"bone_64","bone_66":"bone_65","bone_67":"bone_66","bone_68":"bone_67","bone_69":"bone_68","bone_70":"bone_69","bone_71":"bone_70","bone_72":"bone_71","bone_73":"bone_72","bone_74":"bone_73","bone_75":"bone_74","bone_76":"bone_61","bone_77":"bone_61","bone_78":"bone_59","bone_79":"bone_59","bone_80":"bone_79","bone_81":"bone_80","bone_82":"bone_81","bone_83":"bone_81","bone_84":"bone_83","bone_85":"bone_84","bone_86":"bone_85","bone_87":"bone_86","bone_88":"bone_87","bone_89":"bone_83","bone_90":"bone_89","bone_91":"bone_90","bone_92":"bone_91","bone_93":"bone_92","bone_94":"bone_83","bone_95":"bone_94","bone_96":"bone_95","bone_97":"bone_96","bone_98":"bone_97","bone_99":"bone_83","bone_100":"bone_99","bone_101":"bone_100","bone_102":"bone_101","bone_103":"bone_102","bone_104":"bone_83","bone_105":"bone_83","bone_106":"bone_105","bone_107":"bone_106","bone_108":"bone_107","bone_109":"bone_59","bone_110":"bone_59","bone_111":"bone_59","bone_112":"bone_111","bone_113":"bone_112","bone_114":"bone_113","bone_115":"bone_114","bone_116":"bone_114","bone_117":"bone_114","bone_118":"bone_114","bone_119":"bone_114","bone_120":"bone_119","bone_121":"bone_120","bone_122":"bone_121","bone_123":"bone_112","bone_124":"bone_123","bone_125":"bone_123","bone_126":"bone_125","bone_127":"bone_126","bone_128":"bone_127","bone_129":"bone_128","bone_130":"bone_129","bone_131":"bone_130","bone_132":"bone_123","bone_133":"bone_123","bone_134":"bone_123","bone_135":"bone_123","bone_136":"bone_123","bone_137":"bone_136","bone_138":"bone_136","bone_139":"bone_136","bone_140":"bone_123","bone_141":"bone_123","bone_142":"bone_123","bone_143":"bone_123","bone_144":"bone_143","bone_145":"bone_143","bone_146":"bone_143","bone_147":"bone_123","bone_148":"bone_147","bone_149":"bone_147","bone_150":"bone_123","bone_151":"bone_123","bone_152":"bone_123","bone_153":"bone_123","bone_154":"bone_153","bone_155":"bone_153","bone_156":"bone_153","bone_157":"bone_123","bone_158":"bone_123","bone_159":"bone_123","bone_160":"bone_123","bone_161":"bone_59","bone_162":"bone_161","bone_163":"bone_162","bone_164":"bone_163","bone_165":"bone_163","bone_166":"bone_165","bone_167":"bone_166","bone_168":"bone_167","bone_169":"bone_168","bone_170":"bone_169","bone_171":"bone_165","bone_172":"bone_171","bone_173":"bone_172","bone_174":"bone_173","bone_175":"bone_174","bone_176":"bone_165","bone_177":"bone_176","bone_178":"bone_177","bone_179":"bone_178","bone_180":"bone_179","bone_181":"bone_165","bone_182":"bone_181","bone_183":"bone_182","bone_184":"bone_183","bone_185":"bone_184","bone_186":"bone_165","bone_187":"bone_165","bone_188":"bone_187","bone_189":"bone_188","bone_190":"bone_189","bone_191":"bone_59","bone_192":"bone_59"},"heads":{"bone_0":[0.0,0.0,0.0],"bone_1":[0.0,1.5182268725766335e-05,-443.5557861328125],"bone_2":[-2.501372136975988e-06,-54.87547302246094,-464.538818359375],"bone_3":[3.269074795753113e-06,-57.810611724853516,-416.1328125],"bone_4":[1.0254811968479771e-05,-61.3639030456543,-357.5321960449219],"bone_5":[1.7240548913832754e-05,-64.91720581054688,-298.93157958984375],"bone_6":[2.4226290406659245e-05,-68.47050476074219,-240.3309326171875],"bone_7":[3.121203189948574e-05,-72.0238037109375,-181.7303009033203],"bone_8":[3.819777339231223e-05,-75.57710266113281,-123.12964630126953],"bone_9":[-93.10807037353516,17.16948890686035,-380.0304260253906],"bone_10":[-43.79799270629883,-1.605612874031067,-421.0797119140625],"bone_11":[-45.30362319946289,-2.411945104598999,-214.51145935058594],"bone_12":[-46.42033004760742,12.386560440063477,-53.28578186035156],"bone_13":[-48.226654052734375,-53.994449615478516,-0.0001439598563592881],"bone_14":[-49.83229064941406,-87.55609130859375,-0.10414476692676544],"bone_15":[-62.31117248535156,-5.38596773147583,-470.41473388671875],"bone_16":[-94.1673355102539,-8.061291694641113,-419.3635559082031],"bone_17":[-53.136138916015625,-44.203948974609375,-466.9844055175781],"bone_18":[-65.65288543701172,-43.00067901611328,-402.6705017089844],"bone_19":[-78.34293365478516,-41.68798828125,-338.39300537109375],"bone_20":[-90.68641662597656,-40.594146728515625,-274.0426025390625],"bone_21":[-103.20317840576172,-39.3908805847168,-209.72865295410156],"bone_22":[-115.7199478149414,-38.187618255615234,-145.41470336914062],"bone_23":[-42.9389533996582,30.523969650268555,-468.46075439453125],"bone_24":[-46.391395568847656,39.71121597290039,-403.8553466796875],"bone_25":[-49.68181610107422,48.8314094543457,-339.06158447265625],"bone_26":[-52.81023025512695,57.88456726074219,-274.079345703125],"bone_27":[-57.056758880615234,67.4003677368164,-210.39768981933594],"bone_28":[-60.586212158203125,76.61946868896484,-145.88189697265625],"bone_29":[93.10808563232422,17.169466018676758,-380.0304260253906],"bone_30":[43.79800033569336,-1.6056214570999146,-421.0797119140625],"bone_31":[45.30367660522461,-2.411952018737793,-214.5113983154297],"bone_32":[46.4204216003418,12.386550903320312,-53.285675048828125],"bone_33":[48.22675704956055,-53.99446105957031,-2.237970329588279e-05],"bone_34":[49.832393646240234,-87.55610656738281,-0.10402346402406693],"bone_35":[62.31116485595703,-5.385982513427734,-470.41473388671875],"bone_36":[94.16734313964844,-8.061308860778809,-419.3635559082031],"bone_37":[53.13613510131836,-44.20396423339844,-466.98443603515625],"bone_38":[65.65290832519531,-43.00068664550781,-402.6705322265625],"bone_39":[78.34297943115234,-41.68799591064453,-338.39306640625],"bone_40":[90.68649291992188,-40.594154357910156,-274.0426940917969],"bone_41":[103.20327758789062,-39.3908805847168,-209.72872924804688],"bone_42":[115.7200698852539,-38.1876106262207,-145.41477966308594],"bone_43":[42.93893814086914,30.523950576782227,-468.46075439453125],"bone_44":[46.39139175415039,39.71119689941406,-403.8553466796875],"bone_45":[49.681827545166016,48.83140182495117,-339.06158447265625],"bone_46":[52.81025314331055,57.88456726074219,-274.079345703125],"bone_47":[57.056793212890625,67.40037536621094,-210.39768981933594],"bone_48":[60.58626174926758,76.61947631835938,-145.88189697265625],"bone_49":[-2.7616440547717502e-06,36.47016906738281,-466.7221374511719],"bone_50":[2.113202299369732e-06,44.59954833984375,-425.8289794921875],"bone_51":[7.378079772024648e-06,53.37934112548828,-381.66400146484375],"bone_52":[1.2466420230339281e-05,61.86473846435547,-338.97991943359375],"bone_53":[1.7134612789959647e-05,69.64948272705078,-299.8202819824219],"bone_54":[2.185360608564224e-05,77.51895141601562,-260.2344970703125],"bone_55":[3.0226017770473845e-05,91.48091888427734,-190.0016326904297],"bone_56":[-4.820437879970996e-06,-1.350165843963623,-483.9925537109375],"bone_57":[-9.622009201848414e-06,-1.939820647239685,-524.2710571289062],"bone_58":[-1.436357524653431e-05,-1.439146876335144,-564.0462036132812],"bone_59":[-2.3845637770136818e-05,13.80161190032959,-643.5875244140625],"bone_60":[29.789304733276367,125.03724670410156,-604.8320922851562],"bone_61":[-2.4761775421211496e-05,39.29813766479492,-651.2726440429688],"bone_62":[-1.913445521495305e-05,47.252967834472656,-604.0672607421875],"bone_63":[-1.3507131370715797e-05,55.20781326293945,-556.8618774414062],"bone_64":[-7.879812983446755e-06,63.16264724731445,-509.6565246582031],"bone_65":[-2.252490503451554e-06,71.11748504638672,-462.4511413574219],"bone_66":[3.37482879331219e-06,79.07231903076172,-415.24578857421875],"bone_67":[9.002148544823285e-06,87.02715301513672,-368.0404357910156],"bone_68":[1.4629469660576433e-05,94.98198699951172,-320.8350830078125],"bone_69":[2.0256788047845475e-05,102.93681335449219,-273.6297302246094],"bone_70":[2.5884110073093325e-05,110.89164733886719,-226.42434692382812],"bone_71":[3.151143027935177e-05,118.84648895263672,-179.21897888183594],"bone_72":[3.713875048561022e-05,126.80131530761719,-132.01361083984375],"bone_73":[4.276607069186866e-05,134.75613403320312,-84.80823516845703],"bone_74":[4.839339089812711e-05,142.71095275878906,-37.60285949707031],"bone_75":[5.3081108490005136e-05,149.33755493164062,1.720538854598999],"bone_76":[-45.039581298828125,43.167823791503906,-643.8722534179688],"bone_77":[45.03953552246094,43.16781234741211,-643.8722534179688],"bone_78":[-0.006689746398478746,-45.61602783203125,-625.2288208007812],"bone_79":[-10.4638671875,-5.544132232666016,-636.4673461914062],"bone_80":[-71.11299896240234,15.874857902526855,-625.2371826171875],"bone_81":[-153.84950256347656,21.14433479309082,-518.7423095703125],"bone_82":[-175.92971801757812,10.923545837402344,-475.4154052734375],"bone_83":[-198.00997924804688,0.7027506232261658,-432.0884704589844],"bone_84":[-206.22601318359375,-15.466583251953125,-423.44097900390625],"bone_85":[-220.27757263183594,-23.971820831298828,-383.7637939453125],"bone_86":[-220.43545532226562,-25.731956481933594,-364.07501220703125],"bone_87":[-217.98306274414062,-26.356836318969727,-350.05352783203125],"bone_88":[-213.9944305419922,-26.621990203857422,-335.1905212402344],"bone_89":[-208.12513732910156,-8.41978645324707,-422.4184265136719],"bone_90":[-225.70574951171875,-11.369257926940918,-381.1474609375],"bone_91":[-224.3411102294922,-12.398053169250488,-360.47515869140625],"bone_92":[-220.14976501464844,-12.254742622375488,-345.0857849121094],"bone_93":[-215.5662384033203,-11.913222312927246,-330.9476318359375],"bone_94":[-210.21490478515625,1.5745059251785278,-421.7481689453125],"bone_95":[-224.19390869140625,3.446390151977539,-380.72344970703125],"bone_96":[-223.84742736816406,3.14516019821167,-358.4616394042969],"bone_97":[-221.20204162597656,3.1072564125061035,-345.9339599609375],"bone_98":[-216.3881072998047,3.1648430824279785,-331.9456481933594],"bone_99":[-209.48280334472656,10.102882385253906,-422.0162658691406],"bone_100":[-220.0808563232422,14.265153884887695,-381.97027587890625],"bone_101":[-221.6213836669922,15.358072280883789,-365.513427734375],"bone_102":[-220.05104064941406,15.839735984802246,-355.0195617675781],"bone_103":[-216.42515563964844,16.326780319213867,-341.47198486328125],"bone_104":[-202.24977111816406,1.9426028728485107,-361.6901550292969],"bone_105":[-199.2376708984375,-12.932516098022461,-422.6506042480469],"bone_106":[-197.150634765625,-24.25432014465332,-400.4126281738281],"bone_107":[-195.63865661621094,-33.31686782836914,-381.19049072265625],"bone_108":[-194.50823974609375,-40.09235763549805,-366.8193054199219],"bone_109":[-35.15047073364258,-50.745262145996094,-588.469970703125],"bone_110":[-81.57562255859375,12.279952049255371,-682.8953247070312],"bone_111":[-2.8847873181803152e-05,10.765096664428711,-685.54931640625],"bone_112":[-3.335722431074828e-05,-1.7314345836639404,-723.3765258789062],"bone_113":[-3.240925434511155e-05,-8.238381385803223,-715.4243774414062],"bone_114":[-2.9154836738598533e-05,-49.58829879760742,-688.1243286132812],"bone_115":[-7.3591508865356445,-49.02236557006836,-699.8035888671875],"bone_116":[-3.05715439026244e-05,-52.38423156738281,-700.008544921875],"bone_117":[7.3590898513793945,-49.022369384765625,-699.8035888671875],"bone_118":[-3.05552821373567e-05,-46.00051498413086,-699.8721313476562],"bone_119":[-3.072531399084255e-05,-20.300079345703125,-701.2984619140625],"bone_120":[-3.074027699767612e-05,-27.837797164916992,-701.4240112304688],"bone_121":[-3.075523636653088e-05,-35.499393463134766,-701.5494995117188],"bone_122":[-3.077019573538564e-05,-43.9455451965332,-701.6749877929688],"bone_123":[-4.080632788827643e-05,-8.453734397888184,-785.8641357421875],"bone_124":[-3.5833611036650836e-05,-49.415138244628906,-744.1499633789062],"bone_125":[-3.3336466003675014e-05,29.63498878479004,-723.202392578125],"bone_126":[-3.208452108083293e-05,38.185264587402344,-712.7003173828125],"bone_127":[-3.0104978577583097e-05,44.65812683105469,-696.0947265625],"bone_128":[-2.8187385396449827e-05,50.928401947021484,-680.0087890625],"bone_129":[-2.6231906304019503e-05,57.32258605957031,-663.6050415039062],"bone_130":[-2.419103475403972e-05,63.99597930908203,-646.4849853515625],"bone_131":[-2.204142583650537e-05,71.02494049072266,-628.4527587890625],"bone_132":[-4.080632788827643e-05,-8.453734397888184,-785.8641357421875],"bone_133":[-16.356781005859375,-43.19793701171875,-722.8917236328125],"bone_134":[-31.01974868774414,-4.799102306365967,-718.3546752929688],"bone_135":[-14.667980194091797,-36.197303771972656,-736.5130004882812],"bone_136":[-13.1355562210083,-47.14341735839844,-753.3206176757812],"bone_137":[-7.633046627044678,-51.08755111694336,-745.2764892578125],"bone_138":[-16.10024642944336,-47.41942596435547,-746.359130859375],"bone_139":[-23.902339935302734,-42.736976623535156,-743.0189819335938],"bone_140":[-14.511991500854492,-37.42650604248047,-736.5130004882812],"bone_141":[-14.742015838623047,-37.4265022277832,-736.5130004882812],"bone_142":[-12.417306900024414,-44.8124885559082,-704.0133666992188],"bone_143":[-3.2034353353083134e-05,-53.09859085083008,-712.2794799804688],"bone_144":[-7.942964553833008,-50.34788131713867,-709.3104858398438],"bone_145":[-3.16721125273034e-05,-53.32746887207031,-709.4696655273438],"bone_146":[7.942900657653809,-50.34788513183594,-709.3104858398438],"bone_147":[-3.3095679100370035e-05,-57.23234176635742,-721.1824951171875],"bone_148":[-3.3534445762634277,-56.09368896484375,-718.6277465820312],"bone_149":[3.3533787727355957,-56.09368896484375,-718.6277465820312],"bone_150":[16.35671615600586,-43.197940826416016,-722.8917236328125],"bone_151":[31.019683837890625,-4.799109935760498,-718.3546752929688],"bone_152":[14.667909622192383,-36.19730758666992,-736.5130004882812],"bone_153":[13.135481834411621,-47.14341735839844,-753.3206176757812],"bone_154":[7.632974147796631,-51.087547302246094,-745.2764892578125],"bone_155":[16.10017204284668,-47.41942596435547,-746.359130859375],"bone_156":[23.902267456054688,-42.736976623535156,-743.0189819335938],"bone_157":[14.511920928955078,-37.426509857177734,-736.5130004882812],"bone_158":[14.741945266723633,-37.42650604248047,-736.5130004882812],"bone_159":[12.417243957519531,-44.81249237060547,-704.0133666992188],"bone_160":[-3.15295037580654e-05,-49.23347473144531,-708.0444946289062],"bone_161":[10.463821411132812,-5.544134616851807,-636.4673461914062],"bone_162":[71.11295318603516,15.87484073638916,-625.2371826171875],"bone_163":[153.8494873046875,21.144296646118164,-518.7423706054688],"bone_164":[175.92971801757812,10.923502922058105,-475.41546630859375],"bone_165":[198.00997924804688,0.7027029395103455,-432.0885314941406],"bone_166":[206.22601318359375,-15.466632843017578,-423.4410400390625],"bone_167":[220.27757263183594,-23.971874237060547,-383.76385498046875],"bone_168":[220.43545532226562,-25.732009887695312,-364.0750732421875],"bone_169":[217.98306274414062,-26.356889724731445,-350.0535888671875],"bone_170":[213.9944305419922,-26.622041702270508,-335.1905822753906],"bone_171":[208.12513732910156,-8.419836044311523,-422.4184875488281],"bone_172":[225.70574951171875,-11.369311332702637,-381.14752197265625],"bone_173":[224.3411102294922,-12.398106575012207,-360.4752197265625],"bone_174":[220.14976501464844,-12.25479507446289,-345.0858459472656],"bone_175":[215.5662384033203,-11.913273811340332,-330.94769287109375],"bone_176":[210.21490478515625,1.5744553804397583,-421.74822998046875],"bone_177":[224.19390869140625,3.446336507797241,-380.7235107421875],"bone_178":[223.84742736816406,3.145106554031372,-358.4617004394531],"bone_179":[221.20204162597656,3.107203483581543,-345.93402099609375],"bone_180":[216.3881072998047,3.1647913455963135,-331.9457092285156],"bone_181":[209.48280334472656,10.102832794189453,-422.0163269042969],"bone_182":[220.08087158203125,14.26510238647461,-381.9703369140625],"bone_183":[221.62139892578125,15.358020782470703,-365.51348876953125],"bone_184":[220.0510711669922,15.839685440063477,-355.0196228027344],"bone_185":[216.42518615722656,16.326730728149414,-341.4720458984375],"bone_186":[202.24978637695312,1.9425544738769531,-361.6902160644531],"bone_187":[199.2376708984375,-12.932563781738281,-422.6506652832031],"bone_188":[196.78541564941406,-26.36873435974121,-396.039794921875],"bone_189":[195.27342224121094,-35.43128967285156,-376.817626953125],"bone_190":[194.1430206298828,-42.206787109375,-362.4464416503906],"bone_191":[35.15043258666992,-50.745269775390625,-588.469970703125],"bone_192":[81.5755615234375,12.279932022094727,-682.8953247070312]},"mesh_counts":[6585,18943,12384],"mesh_signature":"954594caf59251a16e324ed4f0d00553091559e199bb79d57e503c3330ff38bc"}''')


def build_profile(parent_by_name, keep_fingers=True):
    # (source index, readable name, tail landmark index, bone collection)
    specs = [
        (0, "root", None, "Body"), (1, "pelvis", 56, "Body"),
        (56, "spine_low", 57, "Body"), (57, "spine_mid", 58, "Body"),
        (58, "chest", 111, "Body"), (111, "neck", 112, "Body"),
        (112, "head", 123, "Body"), (113, "jaw", 114, "Face"),
        (79, "clavicle.L", 80, "Body"), (80, "upper_arm.L", 81, "Body"),
        (81, "forearm.L", 83, "Body"), (83, "hand.L", 95, "Body"),
        (161, "clavicle.R", 162, "Body"), (162, "upper_arm.R", 163, "Body"),
        (163, "forearm.R", 165, "Body"), (165, "hand.R", 177, "Body"),
        (10, "thigh.L", 11, "Body"), (11, "shin.L", 12, "Body"),
        (12, "foot.L", 13, "Body"), (13, "toe.L", 14, "Body"),
        (30, "thigh.R", 31, "Body"), (31, "shin.R", 32, "Body"),
        (32, "foot.R", 33, "Body"), (33, "toe.R", 34, "Body"),
        (125, "hair.01", 128, "Hair"), (128, "hair.02", 131, "Hair"),
        (2, "cloth_back.01", 5, "Cloth"), (5, "cloth_back.02", 8, "Cloth"),
        (49, "cloth_front.01", 52, "Cloth"), (52, "cloth_front.02", 55, "Cloth"),
        (16, "hip_panel.L", None, "Cloth"), (36, "hip_panel.R", None, "Cloth"),
        (17, "cloth_side_back.01.L", 20, "Cloth"),
        (20, "cloth_side_back.02.L", 22, "Cloth"),
        (23, "cloth_side_front.01.L", 25, "Cloth"),
        (25, "cloth_side_front.02.L", 27, "Cloth"),
        (37, "cloth_side_back.01.R", 40, "Cloth"),
        (40, "cloth_side_back.02.R", 42, "Cloth"),
        (43, "cloth_side_front.01.R", 45, "Cloth"),
        (45, "cloth_side_front.02.R", 47, "Cloth"),
    ]
    if keep_fingers:
        for side, roots in (("L", (85, 90, 95, 100, 105)),
                            ("R", (167, 172, 177, 182, 187))):
            for finger, root in zip(("index", "middle", "ring", "pinky", "thumb"), roots):
                for joint in range(3):
                    specs.append((root + joint, f"{finger}.{joint + 1:02d}.{side}",
                                  root + joint + 1, "Fingers"))
    # Moia faces world +Y in the supplied import, so world +X is HER RIGHT.
    # v1.0 assigned those limbs .L. Correct every paired name and weight target.
    def corrected_side(name):
        if name.endswith(".L"):
            return name[:-2] + ".R"
        if name.endswith(".R"):
            return name[:-2] + ".L"
        return name

    specs = [{"source": f"bone_{index}", "name": corrected_side(name),
              "tail_landmark": f"bone_{tail}" if tail is not None else None,
              "collection": collection} for index, name, tail, collection in specs]
    retained = {s["source"]: s for s in specs}
    if len(retained) != len(specs):
        raise ValueError("Duplicate source bones in preset.")

    def nearest_retained(name):
        visited = set()
        while name not in retained:
            if name is None or name in visited or name not in parent_by_name:
                raise ValueError(f"No retained ancestor for {name!r}.")
            visited.add(name)
            name = parent_by_name[name]
        return name

    mapping = {name: retained[nearest_retained(name)]["name"] for name in parent_by_name}
    for spec in specs:
        parent = parent_by_name[spec["source"]]
        spec["parent"] = retained[nearest_retained(parent)]["name"] if parent else None
    # Lower jaw is a head articulation; do not preserve the export's strange
    # siblings under neck/head_base when simplifying the head and face.
    next(s for s in specs if s["name"] == "jaw")["parent"] = "head"
    return specs, mapping


def vsub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def cross(a, b):
    return (a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0])


def unit(vector):
    length = math.sqrt(sum(x*x for x in vector))
    if not math.isfinite(length) or length < 1e-10:
        raise ValueError("Degenerate anatomical direction; cannot choose safe bone axes.")
    return tuple(x/length for x in vector)


def palm_normal(heads, side):
    # In this source, bone_83 is the anatomical right wrist, bone_165 the left.
    wrist, index, pinky = (83, 85, 100) if side == "R" else (165, 167, 182)
    normal = cross(vsub(heads[f"bone_{index}"], heads[f"bone_{wrist}"]),
                   vsub(heads[f"bone_{pinky}"], heads[f"bone_{wrist}"]))
    if side == "L":
        normal = tuple(-x for x in normal)
    return unit(normal)


def jaw_shape_point(point, weight, pivot, axis, angle):
    """One weighted rigid jaw rotation in neutral mesh space (LBS)."""
    axis = unit(axis)
    delta = vsub(point, pivot)
    cosine, sine = math.cos(angle), math.sin(angle)
    dot = sum(a*b for a, b in zip(axis, delta))
    perpendicular = cross(axis, delta)
    rotated = tuple(delta[i]*cosine + perpendicular[i]*sine + axis[i]*dot*(1-cosine)
                    for i in range(3))
    return tuple(point[i] + weight*(rotated[i]-delta[i]) for i in range(3))


def vrm0_humanoid_mapping(keep_fingers):
    result = {"hips": "pelvis", "spine": "spine_low", "chest": "spine_mid",
              "upperChest": "chest", "neck": "neck", "head": "head", "jaw": "jaw"}
    for prefix, side in (("left", "L"), ("right", "R")):
        for role, bone in (("Shoulder", "clavicle"), ("UpperArm", "upper_arm"),
                           ("LowerArm", "forearm"), ("Hand", "hand"),
                           ("UpperLeg", "thigh"), ("LowerLeg", "shin"),
                           ("Foot", "foot"), ("Toes", "toe")):
            result[prefix+role] = f"{bone}.{side}"
        if keep_fingers:
            # VRM 0.x thumb uses Proximal/Intermediate/Distal. VRM 1.x differs.
            for role, bone in (("Thumb", "thumb"), ("Index", "index"),
                               ("Middle", "middle"), ("Ring", "ring"), ("Little", "pinky")):
                for joint, suffix in enumerate(("Proximal", "Intermediate", "Distal"), 1):
                    result[prefix+role+suffix] = f"{bone}.{joint:02d}.{side}"
    return result


def configure_vrm0(rig, meshes, humanoid_mapping):
    """Guarded optional integration; never guess another add-on's API."""
    ext = getattr(rig.data, "vrm_addon_extension", None)
    if ext is None or not hasattr(ext, "vrm0"):
        return {"status": "not_detected", "note": "Configure humanoid roles and mouth expression manually using the report."}
    try:
        human_bones = ext.vrm0.humanoid.human_bones
        groups = ext.vrm0.blend_shape_master.blend_shape_groups
        if any(entry.node.bone_name for entry in human_bones) or len(groups):
            return {"status": "not_configured", "note": "New armature already has VRM entries; review them manually rather than overwriting."}
        ext.spec_version = "0.0"
        for role, name in humanoid_mapping.items():
            entry = next((entry for entry in human_bones if entry.bone == role), None)
            if entry is None:
                entry = human_bones.add()
            entry.bone = role
            entry.node.bone_name = name
        mouth_enabled = CREATE_JAW_OPEN_SHAPE and bool(meshes)
        if mouth_enabled:
            # Direct MediaPipe path: a CUSTOM expression named jawOpen.
            # VRM vowel presets require the optional Snek converter module.
            group = groups.add()
            group.name = "jawOpen"
            group.preset_name = "unknown"
            group.is_binary = False
            for obj in meshes:
                bind = group.binds.add()
                bind.mesh.mesh_object_name = obj.name
                bind.index = "jawOpen"  # Blender key NAME, not its integer glTF index.
                bind.weight = 1.0       # Add-on uses 0..1; exported VRM0 uses 0..100.
        actual = {entry.bone: entry.node.bone_name for entry in human_bones if entry.node.bone_name}
        if actual != humanoid_mapping:
            raise RuntimeError("VRM humanoid property assignments did not read back correctly.")
        if mouth_enabled:
            if (group.name != "jawOpen" or group.preset_name != "unknown" or group.is_binary
                    or len(group.binds) != len(meshes)):
                raise RuntimeError("VRM expression properties did not read back correctly.")
            for bind, obj in zip(group.binds, meshes):
                if (bind.mesh.mesh_object_name != obj.name or bind.index != "jawOpen"
                        or abs(bind.weight - 1.0) > 1e-6):
                    raise RuntimeError("VRM mouth bind did not read back correctly.")
        return {"status": "configured_vrm0", "humanoid_roles": len(actual),
                "mouth_expression": "jawOpen" if mouth_enabled else None,
                "note": "Property readback passed. Export, T-pose normalization, metadata/license and SnekStudio behavior still need verification."}
    except Exception as error:
        # Only new rig's entries belong to this operation; clear partial setup.
        for collection in (locals().get("human_bones"), locals().get("groups")):
            if collection is not None:
                collection.clear()
        return {"status": "not_configured", "error": str(error),
                "note": "Unsupported VRM add-on API. Rig/shape remain usable; apply the report's mappings manually before export."}


def remap_vertex_weights(weights, group_names, mapping):
    """Sum source bone weights into targets; preserve unrelated vertex groups."""
    merged, unrelated = {}, []
    for group_index, weight in weights:
        name = group_names[group_index]
        if name in mapping:
            target = mapping[name]
            merged[target] = merged.get(target, 0.0) + float(weight)
        else:
            unrelated.append((name, float(weight)))
    return merged, unrelated


def mesh_signature(vertices, polygons, edges, weights, group_names):
    """Stable hash of ordered geometry and named positive skin weights."""
    digest = hashlib.sha256()
    for position, assignments in zip(vertices, weights):
        digest.update(struct.pack("<3f", *position))
        named = sorted((group_names[index], float(weight)) for index, weight in assignments
                       if weight > 1e-6)
        digest.update(struct.pack("<I", len(named)))
        for name, weight in named:
            encoded = name.encode("utf-8")
            digest.update(struct.pack("<I", len(encoded)))
            digest.update(encoded)
            digest.update(struct.pack("<f", weight))
    for topology in (polygons, edges):
        for indices in topology:
            digest.update(struct.pack("<I", len(indices)))
            digest.update(struct.pack("<" + "I" * len(indices), *indices))
    return digest.hexdigest()


def validate_skin_rows(vertices, assignments, group_names, bone_names, normalize=True, allow_unweighted=False):
    """Validate CURRENT geometry/skinning; utility groups are not skin influences."""
    if not vertices or len(vertices) != len(assignments):
        raise RuntimeError("Empty mesh or incomplete vertex-weight rows.")
    rows, fixed, unweighted = [], 0, 0
    maximum_error = 0.0
    for index, (point, entries) in enumerate(zip(vertices, assignments)):
        if len(point) != 3 or not all(math.isfinite(float(x)) for x in point):
            raise RuntimeError(f"Non-finite geometry at vertex {index}.")
        values = []
        seen = set()
        for group_index, weight in entries:
            if group_index not in group_names or group_index in seen:
                raise RuntimeError(f"Invalid or duplicate group index at vertex {index}.")
            seen.add(group_index)
            if not math.isfinite(weight) or weight < 0 or weight > 1.00001:
                raise RuntimeError(f"Invalid weight at vertex {index}: {weight}.")
            if group_names[group_index] in bone_names and weight > 0:
                values.append((group_index, float(weight)))
        total = sum(weight for _, weight in values)
        if total < 1e-12:
            if allow_unweighted:
                rows.append([])
                unweighted += 1
                continue
            raise RuntimeError(f"Vertex {index} has no positive weights to deform bones. Repair its weights before conversion.")
        maximum_error = max(maximum_error, abs(total - 1))
        if abs(total-1) > 1e-4 and not normalize:
            raise RuntimeError(f"Skin weights at vertex {index} sum to {total:g}; enable NORMALIZE_SOURCE_WEIGHTS or repair them.")
        fixed += int(abs(total-1) > 1e-4)
        rows.append([(group_index, weight/total if normalize else weight) for group_index, weight in values])
    return rows, {"vertices_normalized": fixed, "unweighted_input_vertices": unweighted,
                  "maximum_input_weight_sum_error": maximum_error}


def verify_skeleton(source):
    if GENERIC_PLAN is not None:
        if any(len(p.constraints) for p in source.pose.bones):
            raise RuntimeError("Source pose constraints need a separate control-preservation path.")
        data = source.animation_data
        if (data and data.drivers) or (source.data.animation_data and source.data.animation_data.drivers):
            raise RuntimeError("Source drivers need a separate control-preservation path.")
        return
    expected = EXPECTED_SOURCE
    bones = source.data.bones
    if {b.name for b in bones} != set(expected["parents"]):
        raise RuntimeError("This preset requires the original 193 numbered Moia bones. Select the imported rig, not a previously converted rig.")
    for bone in bones:
        parent = bone.parent.name if bone.parent else None
        if parent != expected["parents"][bone.name]:
            raise RuntimeError(f"Source hierarchy differs at {bone.name}; conversion stopped.")
        reference = expected["heads"][bone.name]
        if max(abs(float(a) - b) for a, b in zip(bone.head_local, reference)) > 0.01:
            raise RuntimeError(f"Source rest geometry differs at {bone.name}; conversion stopped.")
    if any(len(p.constraints) for p in source.pose.bones):
        raise RuntimeError("The source now has pose constraints. This preset is for the imported rig before custom rigging.")
    for animation in (getattr(source, 'animation_data', None), getattr(source.data, 'animation_data', None)):
        if animation and len(animation.drivers):
            raise RuntimeError("Source drivers need a separate control-preservation path.")
    if any(not b.use_deform for b in source.data.bones):
        raise RuntimeError("Moia's deform flags changed; this profile expects every original bone to be deform-enabled.")


def verify_source(source, meshes):
    verify_skeleton(source)
    if not meshes:
        raise RuntimeError("No mesh is bound to the selected armature.")
    checks = []
    skin_rows = []
    for obj in meshes:
        determinant = obj.matrix_world.to_3x3().determinant()
        if not math.isfinite(determinant) or abs(determinant) < 1e-15:
            raise RuntimeError(f"Mesh {obj.name} has a singular or invalid world transform.")
        if obj.data.shape_keys:
            raise RuntimeError(f"Mesh {obj.name} has existing shape keys; preservation is not implemented in this revision.")
        if obj.constraints or obj.animation_data:
            raise RuntimeError(f"Mesh {obj.name} has constraints or animation; review those dependencies first.")
        if len(obj.modifiers) != 1 or obj.modifiers[0].type != "ARMATURE":
            raise RuntimeError(f"Mesh {obj.name} needs a single Armature modifier; apply mesh-editing modifiers first if appropriate.")
        modifier = obj.modifiers[0]
        if modifier.object != source or not modifier.show_viewport or not modifier.show_render:
            raise RuntimeError(f"Mesh {obj.name} has a disabled or mismatched Armature modifier.")
        if modifier.use_bone_envelopes or not modifier.use_vertex_groups or modifier.vertex_group:
            raise RuntimeError(f"Mesh {obj.name} uses envelopes or a modifier mask; this path requires ordinary group skinning.")
        names = {g.index: g.name for g in obj.vertex_groups}
        vertices = [tuple(v.co) for v in obj.data.vertices]
        assignments = [[(g.group, g.weight) for g in v.groups] for v in obj.data.vertices]
        rows, weight_checks = validate_skin_rows(vertices, assignments, names, {b.name for b in source.data.bones if b.use_deform}, NORMALIZE_SOURCE_WEIGHTS, allow_unweighted=GENERIC_PLAN is not None and GENERIC_PLAN['route']=='guided_reconstruction_draft')
        counts = [len(obj.data.vertices), len(obj.data.edges), len(obj.data.polygons)]
        if not counts[2]:
            raise RuntimeError(f"Mesh {obj.name} has no faces.")
        signature = mesh_signature(vertices, [tuple(p.vertices) for p in obj.data.polygons],
                                   [tuple(e.vertices) for e in obj.data.edges], assignments, names)
        exact = len(meshes) == 1 and counts == EXPECTED_SOURCE['mesh_counts'] and signature == EXPECTED_SOURCE['mesh_signature']
        if STRICT_MESH_REFERENCE and GENERIC_PLAN is None and not exact:
            raise RuntimeError("Strict mesh reference checking is enabled and this mesh differs. Set STRICT_MESH_REFERENCE=False to allow cleanup with current-data validation.")
        checks.append({"mesh": obj.name, "counts": counts, "exact_dump_mesh_match": exact,
                       "mesh_reference_policy": "strict" if STRICT_MESH_REFERENCE else "cleanup_allowed",
                       "note": "Current geometry and skinning are used; ordered dump differences are informational.", **weight_checks})
        skin_rows.append(rows)
    return checks, skin_rows


def source_armature(bpy):
    active = bpy.context.view_layer.objects.active
    if active and active.type == "ARMATURE":
        return active
    if active and active.type == "MESH":
        targets = {m.object for m in active.modifiers if m.type == "ARMATURE" and m.object}
        if len(targets) == 1:
            return targets.pop()
    raise RuntimeError("Select the original imported armature or a mesh bound to it, in Object Mode.")


def main():
    import bpy
    from mathutils import Matrix, Vector

    if bpy.context.mode != "OBJECT":
        raise RuntimeError("Switch to Object Mode and select the original armature.")
    source = source_armature(bpy)
    meshes = conversion_meshes(bpy,source)
    source_checks, source_skin_rows = verify_source(source, meshes)
    parents = {b.name: b.parent.name if b.parent else None for b in source.data.bones}
    specs, mapping = build_profile(parents, KEEP_FINGERS)
    heads = {b.name: source.matrix_world @ b.head_local for b in source.data.bones}
    if GENERIC_PLAN is not None:
        for spec in specs:
            heads[spec['source']] = Vector(spec['head'])
            heads[spec['tail_landmark']] = Vector(spec['tail'])
    # Moia frame follows its source transform; other routes provide a fitted frame.
    # These source-local directions follow a rotated/scaled import correctly.
    up = (source.matrix_world.to_3x3() @ Vector((0, 0, -1))).normalized()
    forward = source.matrix_world.to_3x3() @ Vector((0, -1, 0))
    forward = (forward - up * forward.dot(up)).normalized()
    if GENERIC_PLAN is not None:
        up, forward = Vector(GENERIC_PLAN['up']), Vector(GENERIC_PLAN['forward'])
    if forward.length < 1e-6 or up.length < 1e-6:
        raise RuntimeError("Source transform has a degenerate body frame.")
    palms = ({side:Vector(normal) for side,normal in GENERIC_PLAN['palms'].items()} if GENERIC_PLAN is not None
             else {side: Vector(palm_normal(heads, side)) for side in ("L", "R")} if KEEP_FINGERS else {})
    if not math.isfinite(JAW_OPEN_DEGREES) or not 0 < JAW_OPEN_DEGREES <= 45:
        raise RuntimeError("JAW_OPEN_DEGREES must be greater than zero and at most 45.")
    orientation_matrix = Matrix.Identity(4)
    if CANONICALIZE_FOR_VRM0:
        pivot = (Vector(next(s['head'] for s in specs if s['name']=='pelvis'))
                 if GENERIC_PLAN is not None else heads['bone_1'])
        orientation_matrix = Matrix(canonical_frame(tuple(up),tuple(forward),tuple(pivot)))
        heads = {name:orientation_matrix@point for name,point in heads.items()}
        palms = {side:orientation_matrix.to_3x3()@normal for side,normal in palms.items()}
        up,forward = Vector((0,0,1)),Vector((0,1,0))
    offset = Vector(OUTPUT_OFFSET)
    if len(offset) != 3 or not all(math.isfinite(float(x)) for x in offset):
        raise RuntimeError("OUTPUT_OFFSET must contain three finite numbers.")
    profile = GENERIC_PLAN["profile"] if GENERIC_PLAN is not None else "Fingers70" if KEEP_FINGERS else "Compact40"
    selected_before = list(bpy.context.selected_objects)
    active_before = bpy.context.view_layer.objects.active
    source_visibility = [(obj, obj.hide_get(), obj.hide_render) for obj in [source] + meshes]
    collection = None
    created_objects, created_data, created_texts = [], [], []
    try:
        collection = bpy.data.collections.new(f"RuneRig_{profile}")
        bpy.context.scene.collection.children.link(collection)
        armature_data = bpy.data.armatures.new(f"RuneRig_{profile}_Skeleton")
        created_data.append(("armature", armature_data))
        rig = bpy.data.objects.new(f"RuneRig_{profile}_Rig", armature_data)
        created_objects.append(rig)
        collection.objects.link(rig)
        rig.matrix_world = Matrix.Identity(4)
        rig.show_in_front = True
        armature_data.display_type = "OCTAHEDRAL"
        armature_data.pose_position = "POSE"
        for obj in selected_before:
            obj.select_set(False)
        rig.select_set(True)
        bpy.context.view_layer.objects.active = rig
        bpy.ops.object.mode_set(mode="EDIT")
        for spec in specs:
            bone = armature_data.edit_bones.new(spec["name"])
            bone.head = heads[spec["source"]] + offset
            if spec["tail_landmark"]:
                bone.tail = heads[spec["tail_landmark"]] + offset
            elif spec["name"] == "root":
                bone.tail = bone.head + Vector((0, 0, 0.08))
            else:
                bone.tail = bone.head + Vector((0, 0, -0.08))
            if (bone.tail - bone.head).length < 1e-5:
                bone.tail = bone.head + Vector((0, 0, 0.025))
            roll_axis = forward.copy()
            if spec["collection"] == "Fingers" and not spec["name"].startswith("thumb."):
                # Local +X curl now bends toward the palm, not a global forward
                # direction shared by every finger on both hands.
                roll_axis = palms[spec["name"][-1]].copy()
            if abs((bone.tail - bone.head).normalized().dot(roll_axis)) > 0.95:
                roll_axis = up.copy()
            bone.align_roll(roll_axis)
            bone.use_deform = spec["name"] != "root"
            bone.use_connect = False
        for spec in specs:
            if spec["parent"]:
                armature_data.edit_bones[spec["name"]].parent = armature_data.edit_bones[spec["parent"]]
        bpy.ops.object.mode_set(mode="OBJECT")
        for label in sorted({s["collection"] for s in specs}):
            bone_collection = armature_data.collections.new(label)
            for spec in specs:
                if spec["collection"] == label:
                    bone_collection.assign(armature_data.bones[spec["name"]])
            bone_collection.is_visible = label in {"Body", "Face"}
        for pose_bone in rig.pose.bones:
            pose_bone.rotation_mode = "XYZ"
            pose_bone.matrix_basis = Matrix.Identity(4)
        rig["preset_version"] = PRESET_VERSION
        rig["source_rig_name"] = source.name
        rig["weight_mapping_json"] = json.dumps(mapping if GENERIC_PLAN is None or GENERIC_PLAN['explicit_weights'] is None else
                                               {'strategy':'per_vertex_guided_geometry_and_region_overrides'}, separators=(",", ":"))
        checks = []
        result_meshes = []
        for mesh_index, original in enumerate(meshes):
            new_mesh = original.data.copy()
            created_data.append(("mesh", new_mesh))
            obj = original.copy()
            created_objects.append(obj)
            obj.data = new_mesh
            obj.name = f"RuneRig_{profile}_Mesh"
            collection.objects.link(obj)
            result_meshes.append(obj)
            obj.animation_data_clear()
            obj.parent = rig
            obj.matrix_parent_inverse = Matrix.Identity(4)
            obj.matrix_basis = Matrix.Identity(4)
            obj.matrix_world = Matrix.Identity(4)
            obj.hide_set(False)
            obj.hide_viewport = False
            obj.hide_render = False
            # Capture original custom corner normals by face and vertex before
            # reversing winding. Rebuild their association after the mirror.
            custom_normals = None
            if original.data.has_custom_normals:
                custom_normals = [
                    {original.data.loops[i].vertex_index: original.data.corner_normals[i].vector.copy()
                     for i in polygon.loop_indices}
                    for polygon in original.data.polygons]
            transform = orientation_matrix @ original.matrix_world
            new_mesh.transform(transform)
            if transform.to_3x3().determinant() < 0:
                new_mesh.flip_normals()
            if custom_normals is not None:
                normal_matrix = transform.to_3x3().inverted().transposed()
                transformed = [None] * len(new_mesh.loops)
                for polygon in new_mesh.polygons:
                    for i in polygon.loop_indices:
                        normal = normal_matrix @ custom_normals[polygon.index][new_mesh.loops[i].vertex_index]
                        transformed[i] = normal.normalized()
                new_mesh.normals_split_custom_set(transformed)
            for vertex in new_mesh.vertices:
                vertex.co += offset
            new_mesh.update()
            expected_world = [(orientation_matrix @ original.matrix_world @ vertex.co) + offset
                              for vertex in original.data.vertices]
            group_names = {g.index: g.name for g in original.vertex_groups}
            remapped = [remap_vertex_weights(row, group_names, mapping)[0]
                        for row in source_skin_rows[mesh_index]]
            if GENERIC_PLAN is not None and GENERIC_PLAN['explicit_weights'] is not None:
                remapped = GENERIC_PLAN['explicit_weights'][mesh_index]
            existing = set(g.name for g in obj.vertex_groups)
            destination_names = {s["name"] for s in specs}
            for name in destination_names:
                if name in existing and name not in mapping:
                    raise RuntimeError(f"Destination group collision: {name}")
            for group in list(obj.vertex_groups):
                if group.name in mapping:
                    obj.vertex_groups.remove(group)
            targets = {name: obj.vertex_groups.new(name=name) for name in sorted(destination_names)}
            for index, weights in enumerate(remapped):
                for name, weight in weights.items():
                    if weight < 0 or weight > 1.00001:
                        raise RuntimeError(f"Invalid transferred weight at vertex {index}: {weight}")
                    if weight > 0:
                        targets[name].add([index], min(1.0, weight), "REPLACE")
            remapped, merge_check = weld_output_mesh(obj, set(targets), remapped, created_data)
            # Cleanup has a new index space. Verify neutral deformation against the
            # cleaned output base; pre-cleanup transfer and merge rows are checked separately.
            expected_world = [vertex.co.copy() for vertex in new_mesh.vertices]
            modifier = next(m for m in obj.modifiers if m.type == "ARMATURE")
            modifier.object = rig
            modifier.use_vertex_groups = True
            modifier.use_bone_envelopes = False
            color_check = bake_guided_colors(bpy,obj,created_data)
            # Verify actual Blender-stored weights, not only the pre-write map.
            new_group_names = {g.index: g.name for g in obj.vertex_groups}
            maximum_sum_error = 0.0
            for index, vertex in enumerate(new_mesh.vertices):
                actual = {new_group_names[g.group]: g.weight for g in vertex.groups}
                expected = remapped[index]
                for name, weight in expected.items():
                    if abs(actual.get(name, 0) - min(weight, 1.0)) > 1e-5:
                        raise RuntimeError(f"Transferred weights did not verify at vertex {index}, {name}.")
                total = sum(actual.get(name, 0) for name in targets)
                maximum_sum_error = max(maximum_sum_error, abs(total - 1.0))
                if not total or abs(total - 1.0) > 1e-4:
                    raise RuntimeError(f"Unweighted or non-normalized vertex after transfer: {index}")
            bpy.context.view_layer.update()
            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated = obj.evaluated_get(depsgraph)
            evaluated_mesh = evaluated.to_mesh()
            try:
                if len(evaluated_mesh.vertices) != len(expected_world):
                    raise RuntimeError("Evaluated mesh topology changed during validation.")
                maximum_rest_error = max(((evaluated.matrix_world @ v.co) - expected_world[i]).length
                                         for i, v in enumerate(evaluated_mesh.vertices))
            finally:
                evaluated.to_mesh_clear()
            if maximum_rest_error > 1e-5:
                raise RuntimeError(f"Rest-shape validation failed: max world-space error {maximum_rest_error:g}")
            mouth_changed_vertices = 0
            mouth_max_displacement = 0.0
            if CREATE_JAW_OPEN_SHAPE and any(row.get('jaw', 0) > 0 for row in remapped):
                obj.shape_key_add(name="Basis", from_mix=False)
                mouth = obj.shape_key_add(name="jawOpen", from_mix=False)
                pivot = heads[GENERIC_PLAN["jaw_source"] if GENERIC_PLAN is not None else "bone_113"] + offset
                axis = forward.cross(up).normalized()
                angle = -math.radians(JAW_OPEN_DEGREES)
                for index, vertex in enumerate(new_mesh.vertices):
                    point = jaw_shape_point(vertex.co, remapped[index].get("jaw", 0), pivot, axis, angle)
                    mouth.data[index].co = point
                    displacement = (mouth.data[index].co - vertex.co).length
                    if displacement > 1e-7:
                        mouth_changed_vertices += 1
                        mouth_max_displacement = max(mouth_max_displacement, displacement)
                mouth.value = 0.0
                if not mouth_changed_vertices:
                    raise RuntimeError("jawOpen shape has no visible displacement.")
                # Confirm all stored key coordinates, not just the intended math.
                for index, vertex in enumerate(new_mesh.vertices):
                    expected = Vector(jaw_shape_point(vertex.co, remapped[index].get("jaw", 0), pivot, axis, angle))
                    if (mouth.data[index].co - expected).length > 1e-5:
                        raise RuntimeError(f"jawOpen shape failed coordinate validation at vertex {index}.")
            checks.append({"mesh": obj.name, "vertex_count": len(new_mesh.vertices),
                           "max_weight_sum_error": maximum_sum_error,
                           "max_rest_world_error": maximum_rest_error,
                           "mouth_changed_vertices": mouth_changed_vertices,
                           "mouth_max_displacement": mouth_max_displacement, "merge":merge_check, "color_export":color_check})
        result_meshes, join_check = join_body_outputs(bpy,rig,result_meshes,meshes,
            {s['name'] for s in specs if s['name']!='root'},created_objects,created_data)
        humanoid_mapping = vrm0_humanoid_mapping(KEEP_FINGERS)
        mouth_meshes = [o for o in result_meshes if o.data.shape_keys and o.data.shape_keys.key_blocks.get('jawOpen')]
        vrm_setup = configure_vrm0(rig, mouth_meshes, humanoid_mapping) if CONFIGURE_VRM0 else {"status": "disabled"}
        validation = {"converter_version": UNIVERSAL_VERSION, "preset": PRESET_VERSION, "profile": profile,
                      "source_bones": len(source.data.bones), "result_bones": len(specs),
                      "source_checks": source_checks, "checks": checks, "vrm_setup": vrm_setup,
                      "route": GENERIC_PLAN['route'] if GENERIC_PLAN is not None else 'moia_layout',
                      "mesh_join": join_check,
                      "guided_object_targets": GENERIC_PLAN.get('object_targets',{}) if GENERIC_PLAN is not None else {},
                      "canonical_orientation_enabled": CANONICALIZE_FOR_VRM0,
                      "world_orientation_transform": [list(row) for row in orientation_matrix],
                      "weight_strategy": 'per_vertex_guided_geometry_and_region_overrides' if GENERIC_PLAN is not None and GENERIC_PLAN['explicit_weights'] is not None else 'source_group_map',
                      "route_limits": GENERIC_PLAN['limits'] if GENERIC_PLAN is not None else 'Moia 1.2 profile; tracking still needs runtime testing.',
                      "region_override_vertices": GENERIC_PLAN.get('region_override_vertices', 0) if GENERIC_PLAN is not None else 0,
                      "source_region_vertices": GENERIC_PLAN.get('source_region_vertices', 0) if GENERIC_PLAN is not None else 0,
                      "partial_source_region_vertices": GENERIC_PLAN.get('partial_source_region_vertices', 0) if GENERIC_PLAN is not None else 0,
                      "source_region_targets": GENERIC_PLAN.get('source_region_targets', {}) if GENERIC_PLAN is not None else {},
                      "guided_profile_reused": GENERIC_PLAN.get('guided_profile_reused', False) if GENERIC_PLAN is not None else False,
                      "guided_profile_name": GENERIC_PLAN.get('guided_profile_name') if GENERIC_PLAN is not None else None,
                      "guided_seam_checks": GENERIC_PLAN.get('guided_seam_checks', []) if GENERIC_PLAN is not None else [],
                      "guided_sides_repaired": GENERIC_PLAN.get('guided_sides_repaired', False) if GENERIC_PLAN is not None else False,
                      "guided_weight_reports": GENERIC_PLAN.get('guided_weight_reports', []) if GENERIC_PLAN is not None else [],
                      "reviewed_correction_profile": GENERIC_PLAN.get('reviewed_correction_profile') if GENERIC_PLAN is not None else None,
                      "vrm0_humanoid_mapping": humanoid_mapping,
                      "changes": ("Moia 1.1 anatomical/finger/mouth fixes retained; cleanup allowed." if GENERIC_PLAN is None
                                  else "Named humanoid roles fitted; existing skin and weighted extras retained." if GENERIC_PLAN['route']=='named_humanoid'
                                  else "Fitted body landmarks reconstructed; new per-vertex body weights; rigid hands, no face morphs."),
                      "limits": "Neutral weights/geometry and mouth coordinates verified. Export normalization and SnekStudio tracking still need runtime testing. No IK, original clips, or detailed viseme shapes."}
        rig["conversion_validation_json"] = json.dumps(validation)
        text = bpy.data.texts.new(f"RuneRig_{profile}_ConversionReport.txt")
        created_texts.append(text)
        text.write(json.dumps(validation, indent=2) +
                   ("\n\nGuided weights are per vertex, not a source-group merge.\n" if GENERIC_PLAN is not None and GENERIC_PLAN['explicit_weights'] is not None
                    else "\n\nSOURCE BONE -> DESTINATION\n"+"\n".join(f"{name} -> {mapping[name]}" for name in sorted(mapping))))
        if HIDE_SOURCE_AFTER_SUCCESS:
            for original in [source] + meshes:
                original.hide_set(True)
                original.hide_render = True
        bpy.ops.object.mode_set(mode="POSE")
        print(json.dumps(validation, indent=2))
        def draw_popup(self, context):
            self.layout.label(text=f"Created {len(specs)}-bone rig in {collection.name}")
            self.layout.label(text="Rest shape and vertex weights verified.")
            self.layout.label(text=f"VRM setup: {vrm_setup['status']}; inspect ConversionReport.")
            self.layout.label(text="Pose the new rig; inspect elbows, wrists, knees, and cloth.")
            self.layout.label(text="Source cleanup is recorded in RuneRig_FinalReport.")
        try:
            bpy.context.window_manager.popup_menu(draw_popup, title="Rune Rig conversion complete", icon="INFO")
        except Exception:
            pass
        return {'rig':rig,'meshes':result_meshes,'validation':validation}
    except Exception:
        # Roll back only data created by this run. Never remove source data.
        if bpy.context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        for obj, hidden, hidden_render in source_visibility:
            obj.hide_set(hidden)
            obj.hide_render = hidden_render
        for obj in reversed(created_objects):
            bpy.data.objects.remove(obj, do_unlink=True)
        for kind, data in reversed(created_data):
            if data.users == 0:
                getattr(bpy.data,{'mesh':'meshes','armature':'armatures','material':'materials','image':'images'}[kind]).remove(data)
        for text in created_texts:
            bpy.data.texts.remove(text)
        if collection is not None:
            bpy.data.collections.remove(collection)
        for obj in selected_before:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = active_before
        raise


"""Original helpers for output cleanup, guided surface weighting and color export."""

HEAD_REGION_MARKERS=('head_base','head_side.L','head_side.R')


def body_axes(markers):
    up=unit(vsub(markers['head'],markers['pelvis']))
    d=vsub(markers['forward'],markers['chest'])
    forward=unit(tuple(d[i]-up[i]*sum(a*b for a,b in zip(d,up)) for i in range(3)))
    return up,forward,cross(up,forward)


def head_region_seeds(markers):
    up,forward,left=body_axes(markers)
    radius=max(math.dist(markers['head'],markers['head_tip'])*1.35,
               math.dist(markers['shoulder.L'],markers['shoulder.R'])*.475)
    base=tuple(markers['neck'][i]*.85+markers['head'][i]*.15 for i in range(3))
    return {'head_base':base,**{'head_side.'+s:tuple(markers['head'][i]+left[i]*radius*sign for i in range(3))
                             for s,sign in (('L',1),('R',-1))}}


def landmark_help(name):
    part=name.split('.')[0]
    return {
        'pelvis':'Center between hip joints, inside the pelvis.',
        'spine_low':'Center of the lower spine inside the body; not the front of the belly.',
        'chest':'Center of upper rib cage inside the body, below collarbones.',
        'neck':'Center of neck at its base, above the chest.',
        'head':'Head rotation joint at base of skull, behind jaw; not the face center.',
        'head_tip':'Crown: highest point of the skull, centered over the head; ignore hair, hats, horns and ears.',
        'head_base':'Just below the lowest chin point in side view, not at the forward nose/chin tip. Sets the lower rigid-head boundary.',
        'head_side':'Outermost tip of this ear, not its middle or attachment. Controls lateral head width only.',
        'shoulder':'Upper-arm pivot inside shoulder socket; not the outer shoulder pad.',
        'elbow':'Center of elbow hinge, inside the joint.',
        'wrist':'Center of wrist where hand begins; not fingertips.',
        'hand_tip':'Center at base of middle-finger knuckle row; excludes held props.',
        'hip':'Leg pivot inside hip socket, not the outer garment.',
        'knee':'Internal knee hinge center behind the kneecap; centered left/right in front view and through the joint in side view.',
        'ankle':'Center of ankle joint above heel.',
        'toe':'Toe bend/base of toes, near ball of foot.',
        'toe_tip':'Front end of foot along toes, not beneath ankle.',
        'forward':'In front of chest toward face; defines facing, not a body joint.',
        'clavicle':'Inner collarbone joint near upper chest. Shoulder socket is its other endpoint; keep this off the shoulder pad.',
    }.get(part,'Place at the corresponding anatomical joint center.')


def landmark_instructions():
    return ('Fit in FRONT and SIDE views: joint markers belong at internal rotation centers, not on the skin.\n'
            'Head-region boundaries, skull top and toe_tip are extent markers; do not put these inside a joint.\n'
            'L/R always mean the CHARACTER\'S left/right. Keep the original posed arms; no T-pose is required.\n'
            'Head Region markers control mesh ownership separately from RR_head rotation pivot.\n\n'+
            '\n'.join('RR_'+n+': '+landmark_help(n) for n in list(marker_seed([(0,0,0),(1,1,1)],(0,0,1),(0,-1,0)))+list(HEAD_REGION_MARKERS))+
            '\n\nAfter conversion, test head turn/tilt, shoulder raise, elbow bend and wrist turn in Blender. '
            'For ambiguous pieces, paint an RR:head or RR:chest vertex group on the ORIGINAL mesh, then rerun. '
            'Set DELETE_SOURCE_AFTER_SUCCESS=False while iterating so originals stay available. '
            'RR overrides beat all geometric rules. Do not select an already converted rig for reconstruction.')


def fitted_head_volume(point,markers,scale):
    region={**head_region_seeds(markers),**{n:markers[n] for n in HEAD_REGION_MARKERS if n in markers}}
    up,forward,left=body_axes(markers)
    dot=lambda p,axis:sum(a*b for a,b in zip(vsub(p,markers['head']),axis))
    lo=dot(region['head_side.R'],left);hi=dot(region['head_side.L'],left)
    bottom=dot(region['head_base'],up)
    top=dot(markers['head_tip'],up)+scale*.08
    depth=max(math.dist(markers['head_tip'],markers['head'])*1.6,scale*.06)
    if lo>=hi or hi-lo>scale*.7 or bottom>=dot(markers['head_tip'],up):
        raise RuntimeError('Invalid Head Region markers: put head_side.L/R on their anatomical ear tips and head_base below the skull.')
    lateral=dot(point,left);z=dot(point,up);front=dot(point,forward)
    return lo-scale*.003<=lateral<=hi+scale*.003 and abs(front)<=depth and z<=top,z,bottom


def guided_candidate_allowed(name,point,markers,scale,body_zone):
    if name.startswith(('upper_arm.','forearm.','hand.')) and body_zone:return False
    up,forward,left=body_axes(markers)
    height=lambda p:sum(a*b for a,b in zip(vsub(p,markers['pelvis']),up))
    z=height(point);chest=height(markers['chest']);neck=height(markers['neck'])
    # Surface distance alone can blend a pelvis/buckle island with a thigh.
    # Joint-height bands and a central pelvis zone restrict anatomical ownership.
    if name.startswith(('thigh.','shin.','foot.','toe.')):
        side=name.rsplit('.',1)[1]
        hip=height(markers['hip.'+side]);knee=height(markers['knee.'+side]);ankle=height(markers['ankle.'+side])
        if name.startswith('thigh.'):
            if not knee-scale*.025<=z<=hip+scale*.025:return False
            center=tuple((markers['hip.L'][i]+markers['hip.R'][i])*.5 for i in range(3))
            width=abs(sum(a*b for a,b in zip(vsub(markers['hip.L'],markers['hip.R']),left)))*.5
            lateral=abs(sum(a*b for a,b in zip(vsub(point,center),left)))
            if lateral<width*.85 and z>=min(height(markers['hip.L']),height(markers['hip.R']))-scale*.01:return False
        elif name.startswith('shin.'):
            if not ankle-scale*.025<=z<=knee+scale*.025:return False
        elif z>ankle+scale*.015:return False
    if name.startswith('clavicle.') and body_zone and z<chest+scale*.015:return False
    if GUIDED_HEAD_POLICY!='FITTED_HEAD':return True
    if name=='head':
        inside,relative,bottom=fitted_head_volume(point,markers,scale)
        return inside and relative>=bottom-scale*.01
    if name=='neck':
        # A neck field can travel down a connected torso surface. Ownership
        # remains confined to a narrow anatomical neck, regardless of distance.
        delta=vsub(point,markers['neck'])
        lateral=abs(sum(a*b for a,b in zip(delta,left)))
        depth=abs(sum(a*b for a,b in zip(delta,forward)))
        width=max(math.dist(markers['shoulder.L'],markers['shoulder.R'])*.23,scale*.025)
        return z>=chest+(neck-chest)*.6 and lateral<=width and depth<=scale*.08
    return True

def repair_guided_sides(markers, automatic=True):
    markers = dict(markers)
    up = unit(vsub(markers['head'],markers['pelvis']))
    d = vsub(markers['forward'],markers['chest'])
    forward = unit(tuple(d[i]-up[i]*sum(a*b for a,b in zip(d,up)) for i in range(3)))
    left = cross(up,forward)
    scale = math.dist(markers['head_tip'],markers['ankle.L'])
    toes=tuple(sum(markers['toe.'+s][i]-markers['ankle.'+s][i] for s in ('L','R'))*.5 for i in range(3))
    toes=tuple(toes[i]-up[i]*sum(a*b for a,b in zip(toes,up)) for i in range(3))
    if math.sqrt(sum(x*x for x in toes))>scale*.01 and sum(a*b for a,b in zip(unit(toes),forward))<-.25:
        raise RuntimeError('Toe direction conflicts with RR_forward. Put RR_forward toward the face and toe markers toward the front of the feet before conversion.')
    values = [sum(a*b for a,b in zip(vsub(markers[j+'.L'],markers[j+'.R']),left))
              for j in ('shoulder','hip','wrist','ankle')]
    if all(v < -scale*.01 for v in values) and automatic:
        for joint in ('shoulder','elbow','wrist','hand_tip','hip','knee','ankle','toe','toe_tip'):
            markers[joint+'.L'],markers[joint+'.R'] = markers[joint+'.R'],markers[joint+'.L']
        if 'clavicle.L' in markers and 'clavicle.R' in markers:
            markers['clavicle.L'],markers['clavicle.R']=markers['clavicle.R'],markers['clavicle.L']
        if ('head_side.L' in markers and 'head_side.R' in markers and
            sum(a*b for a,b in zip(vsub(markers['head_side.L'],markers['head_side.R']),left))<0):
            markers['head_side.L'],markers['head_side.R']=markers['head_side.R'],markers['head_side.L']
        print('Corrected all guided L/R labels relative to RR_forward. Mesh orientation is unchanged.')
        return markers,True
    if not all(v>scale*.01 for v in values):
        raise RuntimeError('Guided side markers disagree: place RR_forward toward the FACE and all L/R pairs on the character\'s anatomical sides. Do not rotate only the mesh or swap just an arm.')
    return markers,False


def guided_body_zone(point, markers):
    """Central torso/robe corridor excludes arm ownership; explicit overrides win."""
    up = unit(vsub(markers['head'],markers['pelvis']))
    d = vsub(markers['forward'],markers['chest'])
    forward = unit(tuple(d[i]-up[i]*sum(a*b for a,b in zip(d,up)) for i in range(3)))
    left = cross(up,forward)
    def along(p,axis):return sum(a*b for a,b in zip(vsub(p,markers['pelvis']),axis))
    shoulder_width = abs(along(markers['shoulder.L'],left)-along(markers['shoulder.R'],left))*.5
    hip_width = abs(along(markers['hip.L'],left)-along(markers['hip.R'],left))*.5
    width = max(hip_width*1.15,shoulder_width*.82)
    z = along(point,up)
    floor = min(along(markers['ankle.'+s],up) for s in ('L','R'))
    top = along(markers['neck'],up)
    # No front/back cutoff: capes behind the spine still belong to the body.
    chest_z=along(markers['chest'],up)
    t=max(0,min(1,z/max(chest_z,1e-8)))
    center=tuple(markers['pelvis'][i]*(1-t)+markers['chest'][i]*t for i in range(3))
    lateral=sum(a*b for a,b in zip(vsub(point,center),left))
    return floor<=z<=top and abs(lateral)<=width


def guided_head_override(point,markers,scale):
    """Keep an upper head rigid; limit neck blending to the fitted neck/head band."""
    if GUIDED_HEAD_POLICY=='SURFACE':return None
    if GUIDED_HEAD_POLICY=='FITTED_HEAD':
        inside,height,bottom=fitted_head_volume(point,markers,scale)
        if not inside or height<bottom-scale*.01:return None
        if height>=bottom:return {'head':1.0}
        t=max(0,min(1,(height-bottom+scale*.01)/(scale*.01)))
        weight=t*t*(3-2*t)
        return {n:w for n,w in (('head',weight),('neck',1-weight)) if w>0}
    if GUIDED_HEAD_POLICY!='RIGID_UPPER_HEAD':
        raise RuntimeError('GUIDED_HEAD_POLICY must be FITTED_HEAD, RIGID_UPPER_HEAD or SURFACE.')
    up=unit(vsub(markers['head'],markers['pelvis']))
    delta=vsub(point,markers['head']);height=sum(a*b for a,b in zip(delta,up))
    neck_height=sum(a*b for a,b in zip(vsub(markers['neck'],markers['head']),up))
    if neck_height>=-scale*.001 or height<neck_height:return None
    radial=math.sqrt(sum((delta[i]-up[i]*height)**2 for i in range(3)))
    radius=max(math.dist(markers['head_tip'],markers['head'])*1.3,
               math.dist(markers['shoulder.L'],markers['shoulder.R'])*.425,scale*.05)
    if radial>radius:return None
    if height>=0:return {'head':1.0}
    t=max(0.0,min(1.0,(height-neck_height)/-neck_height));weight=t*t*(3-2*t)
    return {n:w for n,w in (('head',weight),('neck',1-weight)) if w>0}


def surface_guided_weights(points, edges, specs, scale, markers, overrides=None,stable_seeds=False):
    """Multi-source surface distances on exact-position seam graph, no mesh edits."""
    import heapq
    if len(points)==0:raise RuntimeError('No vertices for surface weighting.')
    overrides = overrides or [None]*len(points)
    if len(overrides)!=len(points):raise RuntimeError('Region override row count differs from vertices.')
    positions=[];lookup={};vertex_nodes=[];cells={}
    tolerance=max(scale*MERGE_DISTANCE_RELATIVE,1e-10) if MERGE_NEARBY_VERTICES else 0
    for p in points:
        key=tuple(p)
        if key not in lookup:
            found=None
            if tolerance:
                cell=tuple(math.floor(x/tolerance) for x in p)
                nearby=[]
                for dx in (-1,0,1):
                    for dy in (-1,0,1):
                        for dz in (-1,0,1):nearby.extend(cells.get((cell[0]+dx,cell[1]+dy,cell[2]+dz),[]))
                candidates_near=[i for i in nearby if math.dist(p,positions[i])<=tolerance]
                if candidates_near:found=min(candidates_near,key=lambda i:(math.dist(p,positions[i]),i))
            if found is None:
                found=len(positions);positions.append(key)
                if tolerance:cells.setdefault(cell,[]).append(found)
            lookup[key]=found
        vertex_nodes.append(lookup[key])
    graph=[{} for _ in positions]
    for a,b in edges:
        if a<0 or b<0 or a>=len(points) or b>=len(points):raise RuntimeError('Invalid mesh edge in surface weighting.')
        a,b=vertex_nodes[a],vertex_nodes[b]
        if a==b:continue
        length=math.dist(positions[a],positions[b])
        graph[a][b]=length;graph[b][a]=length
    candidates=[s for s in specs if s['name']!='root']
    byname={s['name']:s for s in candidates}
    arm=lambda n:n.startswith(('upper_arm.','forearm.','hand.'))
    body_zone=[guided_body_zone(p,markers) for p in positions]
    eligibility={s['name']:[guided_candidate_allowed(s['name'],p,markers,scale,body_zone[i])
                           for i,p in enumerate(positions)] for s in candidates}
    fields={};seed_counts={}
    for spec in candidates:
        seeds={}
        for t in (.2,.5,.8):
            sample=tuple(spec['head'][i]*(1-t)+spec['tail'][i]*t for i in range(3))
            allowed=[i for i in range(len(positions)) if eligibility[spec['name']][i]]
            if not allowed:continue
            index=min(allowed,key=lambda i:math.dist(sample,positions[i]))
            distance=math.dist(sample,positions[index])
            # Symmetric nearest surfaces must not pick different anchors merely
            # because floating-point roundoff changes after object rotation.
            selected=([i for i in allowed if math.dist(sample,positions[i])<=distance+scale*1e-7]
                      if stable_seeds else [index])
            # Do not anchor an invisible joint to an arbitrarily distant surface.
            if distance<=scale*.10:
                for seed in selected:
                    cost=math.dist(sample,positions[seed])
                    seeds[seed]=min(cost,seeds.get(seed,math.inf))
        for i,row in enumerate(overrides):
            if row and row.get(spec['name'],0)>.5:seeds[vertex_nodes[i]]=0
        distances=[math.inf]*len(positions)
        queue=[]
        for index,distance in seeds.items():distances[index]=distance;heapq.heappush(queue,(distance,index))
        while queue:
            distance,index=heapq.heappop(queue)
            if distance!=distances[index]:continue
            for neighbor,cost in graph[index].items():
                next_distance=distance+cost
                if next_distance<distances[neighbor]:
                    distances[neighbor]=next_distance;heapq.heappush(queue,(next_distance,neighbor))
        fields[spec['name']]=distances;seed_counts[spec['name']]=len(seeds)
    # Unseeded surface islands get one consensus part, instead of changing owner
    # at every vertex just because one edge of a cape passes near a hand.
    remaining=set(range(len(positions)));island_choice={};island_count=0
    while remaining:
        start=remaining.pop();pending=[start];members=[start]
        while pending:
            for neighbor in graph[pending.pop()]:
                if neighbor in remaining:remaining.remove(neighbor);pending.append(neighbor);members.append(neighbor)
        if any(math.isfinite(fields[s['name']][start]) for s in candidates):continue
        island_count+=1
        allow=[s for s in candidates if not (arm(s['name']) and sum(body_zone[i] for i in members)/len(members)>=.35)]
        owner=min(allow,key=lambda s:(sum(distance_to_segment(positions[i],s['head'],s['tail']) for i in members)/len(members),s['name']))
        for i in members:island_choice[i]=owner['name']
    result=[];fallback=0;body_guard=0;head_guard=0
    for i,point in enumerate(points):
        if overrides[i]:result.append(guided_vertex_weights(point,specs,scale,overrides[i]));continue
        head_row=guided_head_override(point,markers,scale)
        if head_row:
            result.append(head_row);head_guard+=1;continue
        node=vertex_nodes[i]
        allowed=[s for s in candidates if eligibility[s['name']][node]]
        body_guard+=body_zone[node]
        available=[s for s in allowed if math.isfinite(fields[s['name']][node])]
        if not available:
            fallback+=1
            owner=(byname[island_choice[node]] if node in island_choice else
                   min(allowed,key=lambda s:distance_to_segment(point,s['head'],s['tail'])))
            if owner not in allowed:owner=min(allowed,key=lambda s:distance_to_segment(point,s['head'],s['tail']))
            adjacent=[s for s in allowed if s['name']==owner['parent'] or s['parent']==owner['name']]
            selected=[owner]
            if adjacent:selected.append(min(adjacent,key=lambda s:distance_to_segment(point,s['head'],s['tail'])))
            radius=max(scale*.025,1e-8)
            weights={s['name']:1/(distance_to_segment(point,s['head'],s['tail'])+radius)**4 for s in selected}
            total=sum(weights.values());result.append({n:w/total for n,w in weights.items()})
            continue
        closest=min(available,key=lambda s:((round(fields[s['name']][node]/scale,10) if stable_seeds else fields[s['name']][node]),s['name']))
        adjacent=[s for s in available if s['name']==closest['parent'] or s['parent']==closest['name']]
        selected=[closest]
        if adjacent:selected.append(min(adjacent,key=lambda s:((round(fields[s['name']][node]/scale,10) if stable_seeds else fields[s['name']][node]),s['name'])))
        radius=max(scale*.025,1e-8)
        weights={s['name']:1/(fields[s['name']][node]+radius)**4 for s in selected}
        total=sum(weights.values());result.append({n:w/total for n,w in weights.items()})
    return result,{'method':'surface_geodesic_with_body_zone','graph_positions':len(positions),
                   'seed_counts':seed_counts,'surface_fallback_vertices':fallback,
                   'unseeded_island_components':island_count,'virtual_seam_distance':tolerance,
                   'body_zone_vertices':int(body_guard),'head_policy':GUIDED_HEAD_POLICY,'head_guard_vertices':int(head_guard),
                   'limits':'Fitted head boundary and ear width control rigid ownership; neck and chest guards restrict spill. Low hair and touching/crossed limbs still need explicit hints. Unseeded islands use part consensus.'}


def preserve_point_colors_as_corners(mesh):
    attributes=getattr(mesh,'color_attributes',None)
    if attributes is None:return
    active=getattr(getattr(attributes,'active_color',None),'name',None)
    render_index=getattr(attributes,'render_color_index',-1)
    render_name=attributes[render_index].name if 0<=render_index<len(attributes) else None
    for attribute in list(attributes):
        if attribute.domain!='POINT':continue
        name=attribute.name
        colors=[tuple(x.color) for x in attribute.data]
        replacement=attributes.new(name='RR_corner_'+name,type='FLOAT_COLOR',domain='CORNER')
        for loop in mesh.loops:replacement.data[loop.index].color=colors[loop.vertex_index]
        attributes.remove(attribute);replacement.name=name
    if active:
        for i,a in enumerate(attributes):
            if a.name==active:attributes.active_color_index=i;break
    if render_name:
        for i,a in enumerate(attributes):
            if a.name==render_name:attributes.render_color_index=i;break


def averaged_skin_rows(rows):
    values={}
    for row in rows:
        for name,weight in row.items():
            if not math.isfinite(weight) or weight<0:raise RuntimeError('Invalid skin weight during automatic merge.')
            values[name]=values.get(name,0)+weight/len(rows)
    total=sum(values.values())
    if total<1e-12:raise RuntimeError('Automatic merge has no positive deform skin.')
    return {n:w/total for n,w in values.items() if w>0}


def weld_output_mesh(obj, target_names, remapped, created_data):
    """Merge small positional duplicates on output; normalize averaged group skin."""
    import bmesh
    mesh=obj.data
    if not MERGE_NEARBY_VERTICES:return remapped,{'enabled':False}
    if not math.isfinite(MERGE_DISTANCE_RELATIVE) or not 0<MERGE_DISTANCE_RELATIVE<=.001:
        raise RuntimeError('MERGE_DISTANCE_RELATIVE must be >0 and <=0.001 of model height.')
    points=[tuple(v.co) for v in mesh.vertices]
    size=max(max(p[i] for p in points)-min(p[i] for p in points) for i in range(3))
    distance=max(size*MERGE_DISTANCE_RELATIVE,1e-10)
    preserve_point_colors_as_corners(mesh)
    normal_attribute=None
    if mesh.has_custom_normals:
        normal_attribute=mesh.attributes.new(name='RR_temporary_corner_normals',type='FLOAT_VECTOR',domain='CORNER')
        for i,n in enumerate(mesh.corner_normals):normal_attribute.data[i].vector=n.vector
    before=len(mesh.vertices);polygons_before=len(mesh.polygons)
    expected_rows={};maximum_movement=0
    bm=bmesh.new()
    try:
        bm.from_mesh(mesh);bm.verts.ensure_lookup_table();bm.verts.index_update()
        deform=bm.verts.layers.deform.verify()
        targetmap=bmesh.ops.find_doubles(bm,verts=list(bm.verts),dist=distance)['targetmap']
        clusters={}
        for v in bm.verts:
            root=v;seen=set()
            while root in targetmap:
                if root in seen:raise RuntimeError('Unexpected cyclic merge map.')
                seen.add(root);root=targetmap[root]
            clusters.setdefault(root,[]).append(v)
        for root,members in clusters.items():
            expected_rows[root]=averaged_skin_rows([remapped[v.index] for v in members])
            maximum_movement=max(maximum_movement,max(math.dist(tuple(v.co),tuple(root.co)) for v in members))
            values={}
            for v in members:
                for index,w in v[deform].items():values[index]=values.get(index,0)+w/len(members)
            root[deform].clear()
            for index,w in values.items():root[deform][index]=w
        if maximum_movement>distance*1.01:
            raise RuntimeError('A chained vertex merge exceeds the cleanup distance. Reduce MERGE_DISTANCE_RELATIVE.')
        bmesh.ops.weld_verts(bm,targetmap=targetmap)
        bm.verts.index_update()
        expected_rows={v.index:row for v,row in expected_rows.items() if v.is_valid}
        bm.to_mesh(mesh)
    finally:bm.free()
    if normal_attribute is not None:
        stored=mesh.attributes.get('RR_temporary_corner_normals')
        if stored:
            mesh.normals_split_custom_set([tuple(x.vector) for x in stored.data]);mesh.attributes.remove(stored)
    mesh.update()
    names={g.index:g.name for g in obj.vertex_groups}
    rows=[]
    groups={g.name:g for g in obj.vertex_groups if g.name in target_names}
    for v in mesh.vertices:
        row={names[g.group]:float(g.weight) for g in v.groups if names[g.group] in target_names and g.weight>0}
        total=sum(row.values())
        if total<1e-12:raise RuntimeError('Automatic merge produced an unweighted output vertex.')
        row={n:w/total for n,w in row.items()}
        expected=expected_rows[v.index]
        if any(abs(row.get(n,0)-expected.get(n,0))>1e-5 for n in set(row)|set(expected)):
            raise RuntimeError(f'Automatic merge skin mismatch at vertex {v.index}.')
        row=expected
        for name,weight in row.items():groups[name].add([v.index],weight,'REPLACE')
        rows.append(row)
    if not len(mesh.polygons):raise RuntimeError('Automatic merge removed every face. Lower MERGE_DISTANCE_RELATIVE.')
    return rows,{'enabled':True,'world_distance':distance,'vertices_before':before,
                 'vertices_after':len(mesh.vertices),'vertices_merged':before-len(mesh.vertices),
                 'maximum_vertex_movement':maximum_movement,
                 'polygons_before':polygons_before,'polygons_after':len(mesh.polygons)}


def separate_accessory(name):
    base = name.rsplit('.',1)[0] if name.rsplit('.',1)[-1].isdigit() and '.' in name else name
    return base.casefold() in {n.casefold() for n in SEPARATE_ACCESSORY_MESHES}


def excluded_object(obj):
    getter=getattr(obj,'get',lambda *args:False)
    if getter('rune_rig_exclude',False):return True
    if getter('rune_rig_include',False):return False
    base=obj.name.rsplit('.',1)[0] if '.' in obj.name and obj.name.rsplit('.',1)[-1].isdigit() else obj.name
    if base.casefold() in {n.casefold() for n in EXCLUDED_OBJECT_NAMES}:return True
    if BODY_MESH_POLICY=='RUNEAPPS_NAMES':
        import re
        return re.fullmatch(r'mesh_[0-9]+',base,re.IGNORECASE) is None
    if BODY_MESH_POLICY!='EXPLICIT':raise RuntimeError('Invalid BODY_MESH_POLICY; use RUNEAPPS_NAMES or EXPLICIT.')
    return False


def bound_source_meshes(bpy,source):
    return sorted([o for o in bpy.data.objects if o.type=='MESH' and
                   any(m.type=='ARMATURE' and m.object==source for m in o.modifiers)],key=lambda o:o.name)


def conversion_meshes(bpy,source):
    return [o for o in bound_source_meshes(bpy,source) if not excluded_object(o)]


def original_material(material):
    # Evaluated IDs can be temporary depsgraph copies. new_from_object remaps
    # their references to Main database IDs; compare the same original ID on
    # both sides, never material names (different materials can share names).
    if material is None:return None
    original=getattr(material,'original',None)
    return original if original is not None else material


def static_mesh_record(mesh):
    """Appearance and topology snapshot in the evaluated mesh's local space."""
    return {'points':[tuple(v.co) for v in mesh.vertices],
            'edges':[tuple(e.vertices) for e in mesh.edges],
            'faces':[(tuple(f.vertices),f.material_index,f.use_smooth) for f in mesh.polygons],
            'materials':[original_material(m) for m in mesh.materials],
            'uv':{a.name:[tuple(v.uv) for v in a.data] for a in mesh.uv_layers},
            'colors':{a.name:(a.domain,a.data_type,[tuple(v.color) for v in a.data]) for a in mesh.color_attributes},
            'normals':[tuple(n.vector) for n in mesh.corner_normals]}


def validate_static_copy(before,after):
    for key in ('edges','faces','materials','uv','colors'):
        if before[key]!=after[key]:raise RuntimeError('Excluded object copy changed '+key+'.')
    if len(before['points'])!=len(after['points']) or any(math.dist(a,b)>1e-6 for a,b in zip(before['points'],after['points'])):
        raise RuntimeError('Excluded object copy changed geometry.')
    if len(before['normals'])!=len(after['normals']) or any(normal_angle_degrees(a,b)>JOIN_NORMAL_ANGLE_TOLERANCE_DEGREES
            for a,b in zip(before['normals'],after['normals'])):
        raise RuntimeError('Excluded object copy changed shading normals.')


def run_conversion_with_exclusions(bpy,source):
    """Prepare pose-frozen data, convert body, then detach preserved objects."""
    excluded=[o for o in bound_source_meshes(bpy,source) if excluded_object(o)]
    if not excluded:return main()
    staged=[];report=[]
    try:
        bpy.context.view_layer.update()
        depsgraph=bpy.context.evaluated_depsgraph_get()
        for obj in excluded:
            entry={'object':obj.name,'status':'retained_external_dependency','reason':None}
            report.append(entry)
            # Controllers and unusual modifiers need explicit handling, rather
            # than losing their behavior as an incidental conversion cleanup.
            if (len(obj.modifiers)!=1 or obj.modifiers[0].type!='ARMATURE' or
                obj.constraints or obj.animation_data or obj.data.shape_keys or
                (obj.parent is not None and obj.parent!=source) or obj.children or
                getattr(obj,'library',None) or getattr(obj.data,'library',None)):
                entry['reason']='Extra modifiers, animation, shape keys, children, linked data or external parent; original kept with source dependency.'
                continue
            data=None
            try:
                evaluated=obj.evaluated_get(depsgraph)
                before=static_mesh_record(evaluated.data)
                data=bpy.data.meshes.new_from_object(evaluated,preserve_all_data_layers=True,depsgraph=depsgraph)
                if data is None:raise RuntimeError('Blender did not return a static mesh.')
                validate_static_copy(before,static_mesh_record(data))
                data.name=obj.name+'_RuneRig_Static'
                staged.append((obj,data,obj.matrix_world.copy(),entry))
            except Exception as error:
                if data is not None and data.users==0:bpy.data.meshes.remove(data)
                entry['reason']='Static copy could not be verified; original accessory and source dependency retained: '+str(error)
                print(obj.name+': '+entry['reason'])
        result=main()
        if not isinstance(result,dict) or 'rig' not in result:return result
        for obj,data,matrix,entry in staged:
            # Keep the actual original object/name, material links and world
            # placement. Only its evaluated mesh and old rig link are changed.
            old_data=obj.data;parent=obj.parent;parent_type=obj.parent_type;parent_bone=obj.parent_bone
            modifier=obj.modifiers[0]
            settings={n:getattr(modifier,n) for n in ('object','use_vertex_groups','use_bone_envelopes',
                      'use_deform_preserve_volume','vertex_group','invert_vertex_group','show_viewport','show_render')}
            modname=modifier.name;removed=False
            try:
                obj.data=data
                if obj.parent==source:obj.parent=None
                obj.matrix_world=matrix
                obj.modifiers.remove(modifier);removed=True
                obj['rune_rig_exclude']=True
                entry['status']='retained_static_unrigged';entry['reason']=None
            except Exception as error:
                obj.data=old_data;obj.parent=parent;obj.parent_type=parent_type;obj.parent_bone=parent_bone;obj.matrix_world=matrix
                if removed:
                    restored=obj.modifiers.new(modname,'ARMATURE')
                    for name,value in settings.items():setattr(restored,name,value)
                entry['reason']='Detachment failed; original preserved: '+str(error)
        result['validation']['excluded_objects']=report
        print('Excluded objects:',json.dumps(report))
        return result
    finally:
        # Failed body conversion never edits an original prop. Discard unused
        # prepared meshes; attached successful snapshots have an object user.
        for obj,data,matrix,entry in staged:
            if data.users==0:bpy.data.meshes.remove(data)


def guided_batch_weights(batches,specs,scale,markers,source_regions=None):
    """Let body seam neighbors communicate across objects before weighting."""
    if GUIDED_WEIGHT_METHOD not in ('REGION_SOLVE','SURFACE','DISTANCE'):
        raise RuntimeError('GUIDED_WEIGHT_METHOD must be REGION_SOLVE, SURFACE or DISTANCE.')
    if source_regions is not None and len(source_regions)!=len(batches):
        raise RuntimeError('Source region mesh count differs from weighting batches.')
    body = [i for i,b in enumerate(batches) if not separate_accessory(b[0])]
    groups = ([body] if JOIN_BODY_MESHES and body else [])
    groups += [[i] for i in range(len(batches)) if not JOIN_BODY_MESHES or i not in body]
    result = [None]*len(batches)
    for indices in groups:
        points,edges,overrides,ranges,regions = [],[],[],[],[]
        for i in indices:
            name,p,e,o = batches[i]
            start = len(points)
            ranges.append((i,start,start+len(p)))
            points.extend(p); overrides.extend(o)
            skin = source_regions[i] if source_regions is not None else [{} for _ in p]
            if len(skin)!=len(p):raise RuntimeError('Source region vertex count differs from mesh.')
            regions.extend(skin)
            edges.extend((a+start,b+start) for a,b in e)
        if GUIDED_WEIGHT_METHOD == 'REGION_SOLVE':
            rows,info = region_solve_weights(points,edges,specs,scale,markers,overrides,regions)
        elif GUIDED_WEIGHT_METHOD == 'SURFACE':
            rows,info = surface_guided_weights(points,edges,specs,scale,markers,overrides)
        else:
            rows = [guided_vertex_weights(p,specs,scale,o) for p,o in zip(points,overrides)]
            info = {'method':'distance','surface_fallback_vertices':len(rows)}
        for i,start,end in ranges:
            result[i] = (rows[start:end],{**info,'graph_meshes':[batches[j][0] for j in indices],
                         'graph_statistics_scope':'whole listed graph; not per-object counts',
                         'separate_accessory':separate_accessory(batches[i][0])})
    return result


def material_uses_vertex_color(material):
    if material is None or not material.use_nodes or not material.node_tree:return False
    return any(n.type in ('VERTEX_COLOR','ATTRIBUTE') for n in material.node_tree.nodes)


def live_rna(value):
    try:
        return bool(value.as_pointer())
    except ReferenceError:
        return False


class JoinNormalMismatch(RuntimeError):
    pass


def normal_angle_degrees(a,b):
    if len(a)!=3 or len(b)!=3 or not all(math.isfinite(x) for x in (*a,*b)):
        raise JoinNormalMismatch('Body join returned invalid normal vectors.')
    na=math.sqrt(sum(x*x for x in a));nb=math.sqrt(sum(x*x for x in b))
    if na<1e-12 or nb<1e-12:
        if na<1e-12 and nb<1e-12:return 0.0
        raise JoinNormalMismatch('Body join changed a degenerate corner normal.')
    # atan2 is accurate even for the small differences from normal encoding.
    aa=tuple(x/na for x in a);bb=tuple(x/nb for x in b)
    return math.degrees(math.atan2(math.sqrt(sum(x*x for x in cross(aa,bb))),sum(x*y for x,y in zip(aa,bb))))


def validate_join_records(vertices,faces,edges,expected_vertices,expected_faces,expected_edges):
    """Order-independent verification; IDs are carried as mesh attributes."""
    from collections import Counter
    if len(vertices)!=len(expected_vertices) or len(faces)!=len(expected_faces):
        raise RuntimeError('Body join changed the vertex or face count.')
    if len({v['id'] for v in vertices})!=len(vertices) or len({f['id'] for f in faces})!=len(faces):
        raise RuntimeError('Body join lost unique geometry validation IDs.')
    for v in vertices:
        old = expected_vertices.get(v['id'])
        if old is None or math.dist(v['co'],old['co'])>1e-5:
            raise RuntimeError('Body join changed neutral geometry.')
        if any(abs(v['weights'].get(n,0)-old['weights'].get(n,0))>1e-5
               for n in set(v['weights'])|set(old['weights'])):
            raise RuntimeError('Body join changed skin weights.')
    maximum_angle=0.0
    for face in faces:
        old = expected_faces.get(face['id'])
        if old is None or face['vertices']!=old['vertices'] or face['material']!=old['material']:
            raise RuntimeError('Body join changed face winding or material assignment.')
        for field in ('uv','normals','normal_carrier'):
            a,b=face.get(field),old.get(field)
            if (a is None)!=(b is None) or (a is not None and len(a)!=len(b)):
                raise RuntimeError(f'Body join changed {field} corner data.')
            if a is None:continue
            if field=='normals':
                maximum_angle=max(maximum_angle,max((normal_angle_degrees(x,y) for x,y in zip(a,b)),default=0.0))
            elif any(math.dist(x,y)>1e-5 for x,y in zip(a,b)):
                raise RuntimeError(f'Body join changed {field} corner data.')
    if Counter(tuple(sorted(e)) for e in edges)!=Counter(tuple(sorted(e)) for e in expected_edges):
        raise RuntimeError('Body join changed mesh edges.')
    tolerance=JOIN_NORMAL_ANGLE_TOLERANCE_DEGREES
    if not math.isfinite(tolerance) or not 0<tolerance<=1:
        raise RuntimeError('JOIN_NORMAL_ANGLE_TOLERANCE_DEGREES must be >0 and <=1.')
    if maximum_angle>tolerance:
        raise JoinNormalMismatch(f'Body join normal deviation {maximum_angle:.6f} degrees exceeds {tolerance:g} degrees; separate pieces will be retained.')
    return {'maximum_normal_angle_degrees':maximum_angle,'normal_angle_tolerance_degrees':tolerance}


def _join_body_outputs_in_place(bpy,rig,outputs,originals,target_names,created_objects,created_data):
    """Join validated body copies, then weld across their seams. Never select sources."""
    report = {'enabled':JOIN_BODY_MESHES,'source_meshes':[o.name for o in originals],
              'accessories_kept_separate':[s.name for s in originals if separate_accessory(s.name)]}
    body = [o for o,s in zip(outputs,originals) if not separate_accessory(s.name)]
    print('Rune Rig body join inputs:',[s.name for s in originals if not separate_accessory(s.name)])
    if not JOIN_BODY_MESHES or len(body)<2:
        report['status']='disabled' if not JOIN_BODY_MESHES else 'fewer_than_two_body_meshes'
        return outputs,report
    if any(o.data.shape_keys for o in body):
        report['status']='kept_separate_existing_output_morphs'
        return outputs,report
    modes = {bool(o.modifiers[0].use_deform_preserve_volume) for o in body}
    if len(modes)>1:
        report['status']='kept_separate_different_skinning_modes'
        return outputs,report
    # Conflicting attribute domains/types cannot be silently replaced by Join.
    schemas={}
    for o in body:
        preserve_point_colors_as_corners(o.data)
        for a in o.data.attributes:
            if a.name.startswith('.') or a.name in ('position',):continue
            key=(a.domain,a.data_type)
            if a.name in schemas and schemas[a.name]!=key:
                report['status']='kept_separate_conflicting_attribute_types'
                report['attribute']=a.name
                return outputs,report
            schemas[a.name]=key
    import uuid
    token=uuid.uuid4().hex[:12]
    vid,fid,nid,uvname=('RR_join_'+token+s for s in ('_vertex','_face','_normal','_uv'))
    expected_vertices,expected_faces,expected_edges={},{},[]
    has_uv=any(o.data.uv_layers.active for o in body)
    custom_normals=any(o.data.has_custom_normals for o in body)
    vertex_offset=face_offset=0
    for o in body:
        mesh=o.data
        old_uv=next((u for u in mesh.uv_layers if u.active_render),mesh.uv_layers.active)
        if has_uv:
            if old_uv is None: old_uv=mesh.uv_layers.new(name=uvname)
            old_name=old_uv.name
            old_uv.name=uvname;mesh.uv_layers.active=old_uv;old_uv.active_render=True
            # Explicit UV references live on copied materials; original shaders stay intact.
            for slot in o.material_slots:
                if slot.material is None:continue
                material=slot.material.copy();created_data.append(('material',material));slot.material=material
                if material.use_nodes and material.node_tree:
                    for node in material.node_tree.nodes:
                        if node.type=='UVMAP' and node.uv_map==old_name:node.uv_map=uvname
        vattr=mesh.attributes.new(name=vid,type='INT',domain='POINT')
        fattr=mesh.attributes.new(name=fid,type='INT',domain='FACE')
        nattr=mesh.attributes.new(name=nid,type='FLOAT_VECTOR',domain='CORNER') if custom_normals else None
        names={g.index:g.name for g in o.vertex_groups}
        for v in mesh.vertices:
            identity=vertex_offset+v.index;vattr.data[v.index].value=identity
            expected_vertices[identity]={'id':identity,'co':tuple(v.co),
                'weights':{names[g.group]:float(g.weight) for g in v.groups if names[g.group] in target_names and g.weight>0}}
        for face in mesh.polygons:
            identity=face_offset+face.index;fattr.data[face.index].value=identity
            normal_values=[]
            if nattr is not None:
                for loop in face.loop_indices:
                    value=tuple(mesh.corner_normals[loop].vector)
                    nattr.data[loop].vector=value;normal_values.append(value)
            material=o.material_slots[face.material_index].material if face.material_index<len(o.material_slots) else None
            expected_faces[identity]={'id':identity,'vertices':[vertex_offset+mesh.loops[i].vertex_index for i in face.loop_indices],
                'material':material.as_pointer() if material else None,
                'uv':[tuple(old_uv.data[i].uv) for i in face.loop_indices] if has_uv else None,
                'normals':normal_values if custom_normals else None,
                'normal_carrier':normal_values if custom_normals else None}
        expected_edges.extend(tuple(vertex_offset+i for i in e.vertices) for e in mesh.edges)
        vertex_offset+=len(mesh.vertices);face_offset+=len(mesh.polygons)
    for o in list(bpy.context.selected_objects):o.select_set(False)
    for o in body:o.select_set(True)
    active=body[0];bpy.context.view_layer.objects.active=active
    try:
        status=bpy.ops.object.join()
        if status!={'FINISHED'}:raise RuntimeError('Blender did not finish joining the output body copies.')
    finally:
        # Join removes RNA objects and may replace Mesh IDs, even in a partial failure.
        created_objects[:]=[o for o in created_objects if live_rna(o)]
        created_data[:]=[(k,d) for k,d in created_data if live_rna(d)]
        if live_rna(active) and not any(k=='mesh' and d==active.data for k,d in created_data):
            created_data.append(('mesh',active.data))
    mesh=active.data
    vattr,fattr,nattr=mesh.attributes.get(vid),mesh.attributes.get(fid),mesh.attributes.get(nid)
    if vattr is None or fattr is None or (custom_normals and nattr is None):
        raise RuntimeError('Body join lost validation attributes.')
    if custom_normals:mesh.normals_split_custom_set([tuple(v.vector) for v in nattr.data])
    names={g.index:g.name for g in active.vertex_groups}
    vertices=[{'id':vattr.data[v.index].value,'co':tuple(v.co),
        'weights':{names[g.group]:float(g.weight) for g in v.groups if names[g.group] in target_names and g.weight>0}}
        for v in mesh.vertices]
    uv=mesh.uv_layers.get(uvname) if has_uv else None
    if has_uv and uv is None:raise RuntimeError('Body join lost the export UV layer.')
    if uv is not None:mesh.uv_layers.active=uv;uv.active_render=True
    faces=[]
    for face in mesh.polygons:
        material=active.material_slots[face.material_index].material if face.material_index<len(active.material_slots) else None
        faces.append({'id':fattr.data[face.index].value,
            'vertices':[vattr.data[mesh.loops[i].vertex_index].value for i in face.loop_indices],
            'material':material.as_pointer() if material else None,
            'uv':[tuple(uv.data[i].uv) for i in face.loop_indices] if has_uv else None,
            'normals':[tuple(mesh.corner_normals[i].vector) for i in face.loop_indices] if custom_normals else None,
            'normal_carrier':[tuple(nattr.data[i].vector) for i in face.loop_indices] if custom_normals else None})
    edges=[tuple(vattr.data[i].value for i in e.vertices) for e in mesh.edges]
    normal_check=validate_join_records(vertices,faces,edges,expected_vertices,expected_faces,expected_edges)
    rows=[v['weights'] for v in vertices]
    for name in (vid,fid,nid):
        attribute=mesh.attributes.get(name)
        if attribute is not None:mesh.attributes.remove(attribute)
    rows,weld= weld_output_mesh(active,target_names,rows,created_data)
    bpy.context.view_layer.update()
    evaluated=active.evaluated_get(bpy.context.evaluated_depsgraph_get());evaluated_mesh=evaluated.to_mesh()
    try:
        if len(evaluated_mesh.vertices)!=len(mesh.vertices):raise RuntimeError('Joined body evaluated topology changed.')
        error=max(((evaluated.matrix_world@v.co)-mesh.vertices[i].co).length for i,v in enumerate(evaluated_mesh.vertices))
        if error>1e-5:raise RuntimeError('Joined body neutral deformation changed.')
    finally:evaluated.to_mesh_clear()
    remaining=[o for o in outputs if live_rna(o)]
    active.name='RuneRig_JoinedBody'
    active.select_set(False);rig.select_set(True);bpy.context.view_layer.objects.active=rig
    report.update(status='joined_and_validated',joined_body_objects=len(body),result_meshes=len(remaining),
                  vertices_before_weld=vertex_offset,polygons_before_weld=face_offset,
                  cross_object_merge=weld,max_rest_world_error=error,
                  **normal_check,
                  verified=['geometry','edges','winding','material_slots','active_uv','skin_weights','custom_normals_if_present'])
    return remaining,report


def join_body_outputs(bpy,rig,outputs,originals,target_names,created_objects,created_data):
    """Attempt join on disposable staging copies, preserving validated fallback."""
    pairs=[(o,s) for o,s in zip(outputs,originals) if not separate_accessory(s.name)]
    if (not JOIN_BODY_MESHES or len(pairs)<2 or any(o.data.shape_keys for o,s in pairs)
        or len({bool(o.modifiers[0].use_deform_preserve_volume) for o,s in pairs})>1):
        return _join_body_outputs_in_place(bpy,rig,outputs,originals,target_names,created_objects,created_data)
    initial_objects={o.as_pointer() for o in created_objects}
    initial_data={d.as_pointer() for k,d in created_data}
    staging=[]
    for original,source in pairs:
        mesh=original.data.copy();created_data.append(('mesh',mesh))
        obj=original.copy();obj.data=mesh;created_objects.append(obj);staging.append(obj)
        original.users_collection[0].objects.link(obj)
        obj.hide_set(False);obj.hide_viewport=False;obj.hide_render=False
    try:
        joined,report=_join_body_outputs_in_place(bpy,rig,staging,[s for o,s in pairs],target_names,created_objects,created_data)
    except JoinNormalMismatch as error:
        # Geometry/UV/weight failures still abort the conversion. Only a shading
        # mismatch falls back to the already verified separate output objects.
        for obj in list(created_objects):
            if live_rna(obj) and obj.as_pointer() not in initial_objects:bpy.data.objects.remove(obj,do_unlink=True)
        for kind,data in reversed(created_data):
            if live_rna(data) and data.as_pointer() not in initial_data and data.users==0:
                getattr(bpy.data,{'mesh':'meshes','material':'materials','image':'images','armature':'armatures'}[kind]).remove(data)
        created_objects[:]=[o for o in created_objects if live_rna(o)]
        created_data[:]=[(k,d) for k,d in created_data if live_rna(d)]
        for o in list(bpy.context.selected_objects):o.select_set(False)
        rig.select_set(True);bpy.context.view_layer.objects.active=rig
        report={'enabled':True,'status':'kept_separate_normal_mismatch','reason':str(error),
                'source_meshes':[s.name for s in originals],'result_meshes':len(outputs),
                'normal_angle_tolerance_degrees':JOIN_NORMAL_ANGLE_TOLERANCE_DEGREES}
        print('Rune Rig: kept validated separate pieces after join shading mismatch:',str(error))
        return outputs,report
    if report['status']!='joined_and_validated':
        # A schema conflict can be discovered in staging without touching outputs.
        for obj in staging:
            if live_rna(obj):bpy.data.objects.remove(obj,do_unlink=True)
        created_objects[:]=[o for o in created_objects if live_rna(o)]
        for kind,data in reversed(created_data):
            if live_rna(data) and data.as_pointer() not in initial_data and data.users==0:
                getattr(bpy.data,{'mesh':'meshes','material':'materials','image':'images','armature':'armatures'}[kind]).remove(data)
        created_data[:]=[(k,d) for k,d in created_data if live_rna(d)]
        rig.select_set(True);bpy.context.view_layer.objects.active=rig
        return outputs,report
    body=[o for o,s in pairs]
    for obj in body:bpy.data.objects.remove(obj,do_unlink=True)
    created_objects[:]=[o for o in created_objects if live_rna(o)]
    # Only our unused copies are removed; source mesh datablocks are untouched.
    for kind,data in reversed(created_data):
        if kind=='mesh' and live_rna(data) and data.users==0:bpy.data.meshes.remove(data)
    created_data[:]=[(k,d) for k,d in created_data if live_rna(d)]
    result=[o for o in outputs if live_rna(o)]+joined
    report['source_meshes']=[s.name for s in originals];report['result_meshes']=len(result)
    report['accessories_kept_separate']=[s.name for s in originals if separate_accessory(s.name)]
    return result,report


def atlas_layout(face_count,tile_pixels):
    if face_count<1 or tile_pixels<8:raise RuntimeError('Color bake needs faces and at least 8 pixels per tile.')
    grid=math.ceil(math.sqrt(face_count));size=1
    while size<grid*tile_pixels:size*=2
    if size>8192:raise RuntimeError('Vertex-color atlas would exceed 8192 pixels; reduce COLOR_BAKE_TILE_PIXELS.')
    return grid,size


def bake_guided_colors(bpy,obj,created_data):
    """Bake Principled base-color graphs (including source UV textures) to a packed atlas."""
    if GENERIC_PLAN is None or not BAKE_GUIDED_VERTEX_COLORS:return {'status':'unchanged'}
    original_materials=[s.material for s in obj.material_slots]
    affected=[i for i,m in enumerate(original_materials) if material_uses_vertex_color(m)]
    if not affected:return {'status':'no_vertex_color_materials','slots':len(original_materials)}
    mesh=obj.data
    # Bake all slots into one atlas so their original textures can use different source UVs.
    for material in original_materials:
        if material is None or not material.use_nodes:
            raise RuntimeError('Color bake requires node materials in every slot. Set BAKE_GUIDED_VERTEX_COLORS=False for manual material preparation.')
        principled=[n for n in material.node_tree.nodes if n.type=='BSDF_PRINCIPLED']
        outputs=[n for n in material.node_tree.nodes if n.type=='OUTPUT_MATERIAL' and n.is_active_output]
        if len(principled)!=1 or len(outputs)!=1 or not outputs[0].inputs['Surface'].is_linked or outputs[0].inputs['Surface'].links[0].from_node!=principled[0]:
            raise RuntimeError(f'{material.name}: vertex-color baking supports a directly connected Principled shader. Use a material dump/manual bake for this shader graph.')
    grid,size=atlas_layout(len(mesh.polygons),COLOR_BAKE_TILE_PIXELS)
    old_uv=next((u for u in mesh.uv_layers if u.active_render),mesh.uv_layers.active)
    old_uv_name=old_uv.name if old_uv else None
    uv=mesh.uv_layers.new(name='RR_ExportColorUV')
    mesh.uv_layers.active=uv;uv.active_render=True
    for face in mesh.polygons:
        coords=[tuple(mesh.vertices[mesh.loops[i].vertex_index].co) for i in face.loop_indices]
        axis=max(range(3),key=lambda i:abs(face.normal[i]));axes=[i for i in range(3) if i!=axis]
        lo=[min(p[a] for p in coords) for a in axes];hi=[max(p[a] for p in coords) for a in axes]
        extent=max(hi[0]-lo[0],hi[1]-lo[1],1e-12)
        x,y=face.index%grid,face.index//grid
        for loop,p in zip(face.loop_indices,coords):
            uv.data[loop].uv=((x*COLOR_BAKE_TILE_PIXELS+2+(p[axes[0]]-lo[0])/extent*(COLOR_BAKE_TILE_PIXELS-4))/size,
                              (y*COLOR_BAKE_TILE_PIXELS+2+(p[axes[1]]-lo[1])/extent*(COLOR_BAKE_TILE_PIXELS-4))/size)
    image=bpy.data.images.new(obj.name+'_RR_Colors',width=size,height=size,alpha=True)
    created_data.append(('image',image));image.colorspace_settings.name='sRGB';image.generated_color=(0,0,0,1)
    alpha_image=None;copies=[];shader_nodes=[];has_alpha=False
    for i,original in enumerate(original_materials):
        material=original.copy();created_data.append(('material',material));copies.append(material)
        obj.material_slots[i].material=material
        nodes=material.node_tree.nodes;links=material.node_tree.links
        shader=next(n for n in nodes if n.type=='BSDF_PRINCIPLED')
        output=next(n for n in nodes if n.type=='OUTPUT_MATERIAL' and n.is_active_output)
        # Preserve implicit source UV coordinates before changing the render UV layer.
        for node in list(nodes):
            if node.type=='TEX_IMAGE' and not node.inputs['Vector'].is_linked and old_uv_name:
                mapping=nodes.new('ShaderNodeUVMap');mapping.uv_map=old_uv_name;links.new(mapping.outputs['UV'],node.inputs['Vector'])
            if node.type=='TEX_COORD' and old_uv_name:
                for link in list(node.outputs['UV'].links):
                    mapping=nodes.new('ShaderNodeUVMap');mapping.uv_map=old_uv_name;links.new(mapping.outputs['UV'],link.to_socket)
        emission=nodes.new('ShaderNodeEmission')
        color=shader.inputs['Base Color'];alpha=shader.inputs['Alpha']
        if color.is_linked:links.new(color.links[0].from_socket,emission.inputs['Color'])
        else:emission.inputs['Color'].default_value=color.default_value
        links.new(emission.outputs[0],output.inputs['Surface'])
        target=nodes.new('ShaderNodeTexImage');target.image=image;nodes.active=target
        has_alpha=has_alpha or alpha.is_linked or alpha.default_value<.99999
        shader_nodes.append((material,shader,emission,target))
    scene=bpy.context.scene;engine=scene.render.engine
    selected=list(bpy.context.selected_objects);active=bpy.context.view_layer.objects.active
    old_device=None;old_samples=None
    try:
        scene.render.engine='CYCLES';old_device=scene.cycles.device;old_samples=scene.cycles.samples
        scene.cycles.device='CPU';scene.cycles.samples=1
        for item in selected:item.select_set(False)
        obj.select_set(True);bpy.context.view_layer.objects.active=obj
        status=bpy.ops.object.bake(type='EMIT',margin=2,use_clear=True,use_selected_to_active=False,uv_layer=uv.name)
        if 'FINISHED' not in status:raise RuntimeError('Color bake was cancelled.')
        if has_alpha:
            alpha_image=bpy.data.images.new(obj.name+'_RR_AlphaBake',width=size,height=size,alpha=True)
            created_data.append(('image',alpha_image));alpha_image.colorspace_settings.name='Non-Color'
            for material,shader,emission,target in shader_nodes:
                links=material.node_tree.links
                for link in list(emission.inputs['Color'].links):links.remove(link)
                alpha=shader.inputs['Alpha']
                if alpha.is_linked:links.new(alpha.links[0].from_socket,emission.inputs['Color'])
                else:emission.inputs['Color'].default_value=(alpha.default_value,)*3+(1,)
                target.image=alpha_image
            status=bpy.ops.object.bake(type='EMIT',margin=2,use_clear=True,use_selected_to_active=False,uv_layer=uv.name)
            if 'FINISHED' not in status:raise RuntimeError('Alpha bake was cancelled.')
            from array import array
            colors=array('f',[0])*(size*size*4);alphas=array('f',[0])*(size*size*4)
            image.pixels.foreach_get(colors);alpha_image.pixels.foreach_get(alphas)
            for i in range(size*size):colors[i*4+3]=max(0,min(1,alphas[i*4]))
            image.pixels.foreach_set(colors);image.update()
        image.file_format='PNG';image.pack()
        for i,original in enumerate(original_materials):
            material=original.copy();created_data.append(('material',material));material.name=original.name+'_RR_Export'
            material.use_nodes=True;nodes=material.node_tree.nodes;nodes.clear();links=material.node_tree.links
            shader=nodes.new('ShaderNodeBsdfPrincipled');shader.inputs['Roughness'].default_value=1;shader.inputs['Metallic'].default_value=0
            output=nodes.new('ShaderNodeOutputMaterial');links.new(shader.outputs['BSDF'],output.inputs['Surface'])
            texture=nodes.new('ShaderNodeTexImage');texture.image=image
            mapping=nodes.new('ShaderNodeUVMap');mapping.uv_map=uv.name;links.new(mapping.outputs['UV'],texture.inputs['Vector'])
            links.new(texture.outputs['Color'],shader.inputs['Base Color'])
            if has_alpha:links.new(texture.outputs['Alpha'],shader.inputs['Alpha'])
            obj.material_slots[i].material=material
    except Exception as error:
        raise RuntimeError('Vertex-color texture baking failed: '+str(error)+'. CPU Cycles is required; original source will be retained on conversion failure.') from error
    finally:
        if old_device is not None:scene.cycles.device=old_device;scene.cycles.samples=old_samples
        scene.render.engine=engine
        obj.select_set(False)
        for item in selected:item.select_set(True)
        bpy.context.view_layer.objects.active=active
    return {'status':'baked_vertex_colors_to_packed_texture','image':image.name,'size':size,
            'uv_layer':uv.name,'alpha_baked':has_alpha,'material_slots':len(original_materials),
            'limits':'Base color/alpha baked; complex shader surfaces are rejected. Small per-face atlas tiles may soften detailed textures.'}


def finish_conversion(bpy,source,meshes,result):
    # Deletion is outside the creation transaction and after reports/geometry checks.
    if not isinstance(result,dict) or 'rig' not in result:return result
    rig=result['rig'];validation=result['validation'];owned=[source]+list(meshes)
    # RuneApps imports include a leaf Node_3 empty parented to the original rig.
    # Preserve such inert locators in world space so they do not unnecessarily
    # keep the entire old rig alive. Bone attachments/instances/controllers stay dependencies.
    helpers=[o for o in bpy.data.objects if o not in owned and o not in result['meshes'] and o!=rig
             and getattr(o,'type',None)=='EMPTY' and o.parent in owned
             and getattr(o,'parent_type','OBJECT')=='OBJECT' and not getattr(o,'children',())
             and not getattr(o,'constraints',()) and not getattr(o,'animation_data',None)
             and getattr(o,'instance_type','NONE')=='NONE']
    dependencies=[]
    for obj in bpy.data.objects:
        if obj in owned or obj in result['meshes'] or obj==rig:continue
        if obj.parent in owned and obj not in helpers:dependencies.append(obj.name+' (parent)')
        for modifier in obj.modifiers:
            if getattr(modifier,'object',None) in owned:dependencies.append(obj.name+' (modifier)')
        owners=[obj]+list(getattr(getattr(obj,'pose',None),'bones',[]))
        for owner in owners:
            for c in getattr(owner,'constraints',[]):
                if getattr(c,'target',None) in owned or getattr(c,'pole_target',None) in owned:dependencies.append(obj.name+' (constraint)')
        for animation_owner in (obj,getattr(obj,'data',None)):
            data=getattr(animation_owner,'animation_data',None)
            for curve in getattr(data,'drivers',[]):
                for variable in curve.driver.variables:
                    for target in variable.targets:
                        if getattr(target,'id',None) in owned:dependencies.append(obj.name+' (driver)')
    status={'requested':DELETE_SOURCE_AFTER_SUCCESS,'deleted_objects':[],'retained_dependencies':dependencies,'detached_leaf_empties':[]}
    if DELETE_SOURCE_AFTER_SUCCESS and not dependencies:
        for obj in helpers:
            matrix=obj.matrix_world.copy();obj.parent=None;obj.matrix_world=matrix
            status['detached_leaf_empties'].append(obj.name)
        for obj in meshes:
            name=obj.name;bpy.data.objects.remove(obj,do_unlink=True);status['deleted_objects'].append(name)
        name=source.name;bpy.data.objects.remove(source,do_unlink=True);status['deleted_objects'].append(name)
    status['status']='deleted' if status['deleted_objects'] else 'retained_dependencies' if dependencies else 'retained_by_setting'
    try:
        validation['quick_pose_check']=register_rune_rig_preview(bpy)
    except Exception as error:
        # Optional inspection UI cannot invalidate an already validated conversion.
        validation['quick_pose_check']={'status':'unavailable','reason':str(error)}
        print('Quick pose check unavailable:',error)
    validation['source_cleanup']=status;rig['conversion_validation_json']=json.dumps(validation)
    print('Source cleanup:',json.dumps(status))
    text=bpy.data.texts.new('RuneRig_FinalReport_'+rig.name+'.json');text.use_fake_user=True;text.write(json.dumps(validation,indent=2))
    return result


"""Source-aware, simplex-constrained graph skinning. NumPy; no learned asset IDs.

This is an original screened graph/region optimization, not volumetric BBW or
the published weight-transfer implementation. Original groups are soft evidence.
Explicit artist rows are hard constraints. All computation is in a temporary
index space; this module does not edit Blender meshes or rendering attributes.
"""


def skin_simplex(values, allowed):
    """Euclidean projection onto per-row allowed, nonnegative sum-one weights."""
    import numpy as np
    z=np.where(allowed,values,-1e30)
    u=np.sort(z,axis=1)[:,::-1]
    sums=np.cumsum(u,axis=1)-1
    ranks=np.arange(1,z.shape[1]+1)
    rho=np.sum(u-sums/ranks>0,axis=1)-1
    theta=sums[np.arange(len(z)),rho]/(rho+1)
    return np.where(allowed,np.maximum(z-theta[:,None],0),0)


def skin_projected_solve(prior, confidence, edge_a, edge_b, conductance,
                         memberships, region_strength, allowed, fixed,
                         max_iterations=180, tolerance=1e-5, smoothness=.65):
    """Minimize data + edge + source-region variance on a product of simplexes.

    A source region contributes a weighted variance around its CURRENT mean,
    rather than requiring all members to follow one bone. Overlapping source
    weights are supported. A monotone accelerated projected-gradient solve
    checks convergence, reports its objective, and retains hard constraints.
    """
    import numpy as np
    prior=np.asarray(prior,dtype=float)
    confidence=np.asarray(confidence,dtype=float)
    allowed=np.asarray(allowed,dtype=bool)
    n,k=prior.shape
    if n==0 or confidence.shape!=(n,) or allowed.shape!=prior.shape:
        raise RuntimeError('Invalid skin solver dimensions.')
    if not np.isfinite(prior).all() or not np.isfinite(confidence).all() or (confidence<=0).any():
        raise RuntimeError('Invalid skin priors or confidence.')
    if not allowed.any(axis=1).all():raise RuntimeError('Skin solver has a vertex without eligible influences.')
    if not math.isfinite(smoothness) or not 0<=smoothness<=10 or not isinstance(max_iterations,int) or not 1<=max_iterations<=2000 or not math.isfinite(tolerance) or tolerance<=0:
        raise RuntimeError('Invalid REGION_SOLVE configuration.')
    a=np.asarray(edge_a,dtype=int);b=np.asarray(edge_b,dtype=int)
    g=np.asarray(conductance,dtype=float)*smoothness
    if len(a)!=len(b) or len(a)!=len(g) or (len(a) and
        (min(a.min(),b.min())<0 or max(a.max(),b.max())>=n)) or not np.isfinite(g).all() or (g<0).any():
        raise RuntimeError('Invalid skin solve graph.')
    vi,ri,rw=memberships
    vi=np.asarray(vi,dtype=int);ri=np.asarray(ri,dtype=int);rw=np.asarray(rw,dtype=float)
    rs=np.asarray(region_strength,dtype=float)
    if len(vi)!=len(ri) or len(vi)!=len(rw) or not np.isfinite(rw).all() or (rw<0).any() or not np.isfinite(rs).all() or (rs<0).any():
        raise RuntimeError('Invalid source region memberships.')
    if len(vi) and (vi.min()<0 or vi.max()>=n or ri.min()<0 or ri.max()>=len(rs)):
        raise RuntimeError('Source region membership out of bounds.')
    mass=np.bincount(ri,weights=rw,minlength=len(rs))
    active=mass>0
    mass=np.maximum(mass,1e-12)
    fixed_mask=np.zeros(n,dtype=bool);fixed_values=np.zeros((n,k))
    for i,row in fixed.items():
        if not 0<=i<n:raise RuntimeError('Fixed skin row index out of bounds.')
        row=np.asarray(row,dtype=float)
        if row.shape!=(k,) or not np.isfinite(row).all() or (row<0).any() or abs(row.sum()-1)>1e-8 or (row[~allowed[i]]>0).any():
            raise RuntimeError('Invalid fixed skin row.')
        fixed_mask[i]=True;fixed_values[i]=row
    degree=np.bincount(a,weights=g,minlength=n)+np.bincount(b,weights=g,minlength=n)
    rdegree=np.bincount(vi,weights=rw*rs[ri],minlength=n)
    step=1/max(float(np.max(confidence+2*degree+rdegree)),1e-8)

    def region_mean(w):
        means=np.zeros((len(rs),k))
        np.add.at(means,ri,w[vi]*rw[:,None])
        return means/mass[:,None]

    def objective_gradient(w,gradient=True):
        delta=w-prior
        energy=.5*float(np.sum(confidence[:,None]*delta*delta))
        grad=confidence[:,None]*delta if gradient else None
        d=w[a]-w[b]
        energy+=.5*float(np.sum(g[:,None]*d*d))
        if gradient:
            gd=g[:,None]*d
            np.add.at(grad,a,gd);np.add.at(grad,b,-gd)
        if len(vi):
            d=w[vi]-region_mean(w)[ri]
            c=rw*rs[ri]
            energy+=.5*float(np.sum(c[:,None]*d*d))
            if gradient:np.add.at(grad,vi,c[:,None]*d)
        return energy,grad

    def project(w):
        w=skin_simplex(w,allowed)
        w[fixed_mask]=fixed_values[fixed_mask]
        return w

    w=project(prior);y=w.copy();momentum=1.
    initial,_=objective_gradient(w,False);energy=initial
    converged=False;change=0.;iterations=0
    for iteration in range(max_iterations):
        _,grad=objective_gradient(y)
        candidate=project(y-step*grad)
        candidate_energy,_=objective_gradient(candidate,False)
        if candidate_energy>energy+1e-12*max(1,abs(energy)):
            y=w;momentum=1.
            _,grad=objective_gradient(y)
            candidate=project(y-step*grad)
            candidate_energy,_=objective_gradient(candidate,False)
        change=float(np.max(np.abs(candidate-w)))
        next_momentum=(1+math.sqrt(1+4*momentum*momentum))*.5
        y=candidate+(momentum-1)/next_momentum*(candidate-w)
        w=candidate;momentum=next_momentum;energy=candidate_energy
        iterations=iteration+1
        # Use the projected gradient mapping, not energy stagnation alone.
        if change<tolerance:
            _,grad=objective_gradient(w)
            residual=float(np.max(np.abs(project(w-step*grad)-w)))
            if residual<tolerance:
                converged=True;break
    _,grad=objective_gradient(w)
    residual=float(np.max(np.abs(project(w-step*grad)-w)))
    if not np.isfinite(w).all() or np.max(np.abs(w.sum(axis=1)-1))>1e-8 or (w<0).any():
        raise RuntimeError('Constrained skin solve produced invalid weights.')
    return w,{'iterations':iterations,'converged':converged,
              'initial_objective':initial,'final_objective':energy,
              'projected_step_residual':residual,'max_last_step':change,
              'fixed_rows':int(fixed_mask.sum()),'active_source_regions':int(active.sum())}


def skin_analysis_graph(points,edges,scale,source_regions,overrides):
    """Weld tiny seam duplicates in analysis only, retaining input provenance."""
    import numpy as np
    p=np.asarray(points,dtype=float)
    if p.ndim!=2 or p.shape[1]!=3 or not np.isfinite(p).all() or not math.isfinite(scale) or scale<=0:
        raise RuntimeError('Invalid source geometry for region skinning.')
    if len(source_regions)!=len(p) or len(overrides)!=len(p):
        raise RuntimeError('Source region/override vertex count mismatch.')
    tolerance=max(scale*MERGE_DISTANCE_RELATIVE,1e-10) if MERGE_NEARBY_VERTICES else 0
    lookup={};cells={};positions=[];groups=[];inverse=[]
    for i,point in enumerate(p):
        key=tuple(point);index=lookup.get(key)
        if index is None:
            near=[]
            if tolerance:
                cell=tuple(math.floor(x/tolerance) for x in point)
                for dx in (-1,0,1):
                    for dy in (-1,0,1):
                        for dz in (-1,0,1):near.extend(cells.get((cell[0]+dx,cell[1]+dy,cell[2]+dz),()))
                near=[j for j in near if math.dist(point,positions[j])<=tolerance]
            index=min(near,key=lambda j:(math.dist(point,positions[j]),tuple(positions[j]))) if near else len(positions)
            if index==len(positions):
                positions.append(key);groups.append([])
                if tolerance:cells.setdefault(cell,[]).append(index)
            lookup[key]=index
        inverse.append(index);groups[index].append(i)
    adjacency=set()
    for edge in edges:
        if len(edge)!=2:raise RuntimeError('Invalid mesh edge for region skinning.')
        a,b=edge
        if not isinstance(a,(int,np.integer)) or not isinstance(b,(int,np.integer)) or min(a,b)<0 or max(a,b)>=len(p):
            raise RuntimeError('Invalid mesh edge index for region skinning.')
        a,b=inverse[a],inverse[b]
        if a!=b:adjacency.add((min(a,b),max(a,b)))
    regions=[]
    for group in groups:
        row={}
        for i in group:
            total=sum(source_regions[i].values())
            if not math.isfinite(total) or any(not math.isfinite(w) or w<0 for w in source_regions[i].values()):
                raise RuntimeError('Invalid positive source skin evidence.')
            if total:
                for name,w in source_regions[i].items():
                    if w>0:row[name]=row.get(name,0)+w/total/len(group)
        total=sum(row.values())
        regions.append({name:w/total for name,w in row.items()} if total else {})
    return np.asarray(positions),np.asarray(inverse),groups,sorted(adjacency),regions,tolerance


def skin_pose_audit(points,edges,rows,specs,scale,markers):
    """Offline LBS stress probes. Flags deformation; cannot infer artist intent."""
    import numpy as np
    p=np.asarray(points,dtype=float);e=np.asarray(edges,dtype=int)
    if not len(e):return {'pose_count':0,'status':'no_surface_edges'}
    lengths=np.linalg.norm(p[e[:,0]]-p[e[:,1]],axis=1)
    valid=lengths>scale*1e-5
    e=e[valid];lengths=lengths[valid]
    if not len(e):return {'pose_count':0,'status':'no_nonzero_surface_edges'}
    lookup={s['name']:s for s in specs};names=[s['name'] for s in specs if s['name']!='root']
    w=np.array([[row.get(name,0) for name in names] for row in rows])
    up,forward,left=body_axes(markers);worst=[];pose_count=0
    for name in names:
        descendant=[]
        for candidate in names:
            current=candidate;seen=set()
            while current in lookup and current not in seen:
                if current==name:descendant.append(candidate);break
                seen.add(current);current=lookup[current]['parent']
        influence=w[:,[names.index(n) for n in descendant]].sum(axis=1)
        pivot=np.asarray(lookup[name]['head'])
        for label,axis in (('up',up),('forward',forward),('left',left)):
            a=np.asarray(axis);angle=math.radians(45)
            skew=np.array([[0,-a[2],a[1]],[a[2],0,-a[0]],[-a[1],a[0],0]])
            rotation=np.eye(3)*math.cos(angle)+(1-math.cos(angle))*np.outer(a,a)+math.sin(angle)*skew
            posed=p+influence[:,None]*((p-pivot)@rotation.T-(p-pivot))
            ratio=np.linalg.norm(posed[e[:,0]]-posed[e[:,1]],axis=1)/lengths
            strain=np.abs(np.log(np.maximum(ratio,1e-12)));edge=int(strain.argmax())
            worst.append({'bone':name,'axis':label,'degrees':45,'edge_length_ratio':float(ratio[edge]),
                          'absolute_log_strain':float(strain[edge]),
                          'source_world_midpoint':((p[e[edge,0]]+p[e[edge,1]])*.5).tolist()})
            pose_count+=1
    return {'status':'numerical_preview_only','pose_count':pose_count,
            'worst_probes':sorted(worst,key=lambda r:r['absolute_log_strain'],reverse=True)[:8],
            'limits':'Large edge stretch/compression is a review hint. Joint folds may be valid; rigid incorrect attachments can escape this check. No runtime or collision test.'}


def region_solve_weights(points,edges,specs,scale,markers,overrides=None,source_regions=None):
    """Infer priors using fitted anatomy + source support; optimize their blend."""
    import numpy as np
    if len(points)==0:raise RuntimeError('No vertices for region skinning.')
    overrides=[None]*len(points) if overrides is None else overrides
    source_regions=[{} for _ in points] if source_regions is None else source_regions
    p,inverse,groups,graph,skin,tolerance=skin_analysis_graph(points,edges,scale,source_regions,overrides)
    candidates=[s for s in specs if s['name']!='root']
    names=[s['name'] for s in candidates];index={name:i for i,name in enumerate(names)}
    if len(index)!=len(names) or not names:raise RuntimeError('Duplicate or empty target skeleton.')
    n,k=len(p),len(names)
    # Fitted segments support geometry diagnostics; surface distances are the
    # initial prior. Pure closest-segment initialization loses surface topology.
    for j,spec in enumerate(candidates):
        h=np.asarray(spec['head']);d=np.asarray(spec['tail'])-h;length2=float(d@d)
        if not np.isfinite(h).all() or not np.isfinite(d).all() or length2<scale*scale*1e-16:
            raise RuntimeError('Invalid or zero-length fitted bone.')
    body_zone=[guided_body_zone(point,markers) for point in p]
    allowed=np.array([[guided_candidate_allowed(name,point,markers,scale,body_zone[i])
                       for name in names] for i,point in enumerate(p)],dtype=bool)
    if not allowed.any(axis=1).all():raise RuntimeError('No anatomical candidate for a source vertex.')
    initial,initial_report=surface_guided_weights(points,edges,specs,scale,markers,overrides,stable_seeds=True)
    prior=np.zeros((n,k))
    for node,group in enumerate(groups):
        for i in group:
            for name,w in initial[i].items():prior[node,index[name]]+=w/len(group)
    head_rows=[guided_head_override(point,markers,scale) for point in p]
    for i,row in enumerate(head_rows):
        if row:
            prior[i]=0
            for name,w in row.items():
                if name in index:prior[i,index[name]]=w
    # Sparse source memberships retain blended input evidence. Never use group
    # names/IDs as anatomy. Deduplicated positions prevent export seams voting twice.
    region_names=sorted({name for row in skin for name in row})
    region_index={name:i for i,name in enumerate(region_names)}
    vi=[];ri=[];rw=[]
    for i,row in enumerate(skin):
        for name,w in sorted(row.items()):
            vi.append(i);ri.append(region_index[name]);rw.append(w)
    vi=np.asarray(vi,dtype=int);ri=np.asarray(ri,dtype=int);rw=np.asarray(rw)
    count=len(region_names);mass=np.bincount(ri,weights=rw,minlength=count)
    means=np.zeros((count,k))
    if len(vi):np.add.at(means,ri,prior[vi]*rw[:,None])
    means/=np.maximum(mass,1e-12)[:,None]
    # A bilateral source patch spanning the torso is attachment evidence even
    # when a lowered arm is close. Score spine CONTROLS at the robust patch
    # center; a segment-distance field can incorrectly favor its distal end.
    up,forward,left=body_axes(markers)
    axes=np.array([left,forward,up])
    local=(p-np.asarray(markers['pelvis']))@axes.T
    shoulder_width=abs(np.dot(np.asarray(markers['shoulder.L'])-markers['shoulder.R'],left))
    neck_height=np.dot(np.asarray(markers['neck'])-markers['pelvis'],up)
    torso_indices=[index[name] for name in ('pelvis','spine_low','chest') if name in index]
    bilateral_regions=0
    for r in range(count):
        member=vi[ri==r]
        if len(member)<6:continue
        lo,median,hi=np.quantile(local[member],[.1,.5,.9],axis=0)
        central_fraction=float(np.mean(np.abs(local[member,0])<shoulder_width*.25))
        if central_fraction>=.15 and lo[0]<-shoulder_width*.15 and hi[0]>shoulder_width*.15 and hi[0]-lo[0]>shoulder_width*.6 and hi[2]-lo[2]<scale*.4 and median[2]<neck_height-scale*.035:
            center=median@axes+np.asarray(markers['pelvis'])
            torso_distance=np.array([np.linalg.norm(center-np.asarray(candidates[j]['head'])) for j in torso_indices])
            owner=torso_indices[int(torso_distance.argmin())]
            means[r]=0;means[r,owner]=1;bilateral_regions+=1
    # A surface field can confuse the clavicle with the adjacent torso. Use
    # whole-patch shaft fit as a second, independent source of evidence when
    # the patch actually spans a shaft and surface consensus is ambiguous.
    # Pointwise nearest-bone distances alone are not a reliable initialization.
    region_shaft_corrections=0
    segment_distance=np.zeros((n,k));segment_fraction=np.zeros((n,k))
    for j,spec in enumerate(candidates):
        h=np.asarray(spec['head']);d=np.asarray(spec['tail'])-h
        t=(p-h)@d/(d@d);segment_fraction[:,j]=t
        segment_distance[:,j]=np.linalg.norm(p-h-np.clip(t,0,1)[:,None]*d,axis=1)
    for r in range(count):
        member=vi[ri==r]
        if len(member)<6 or means[r].max()>=.8:continue
        eligible=(allowed[member].mean(axis=0)>=.7)&(means[r]>.03)
        ds=np.median(segment_distance[member],axis=0)
        order=np.argsort(np.where(eligible,ds,np.inf),kind='stable')
        best,second=order[:2]
        if not eligible[best] or not eligible[second]:continue
        owner=int(means[r].argmax())
        # Do not count geometric agreement twice or move a patch to a remote
        # branch. This evidence resolves adjacent-control disagreements only.
        if best==owner or not (candidates[best]['parent']==names[owner] or
                               candidates[owner]['parent']==names[best]):continue
        margin=(ds[second]-ds[best])/max(ds[second],scale*.015)
        lo,hi=np.quantile(segment_fraction[member,best],[.1,.9])
        if margin<.2 or lo<-.2 or lo>.3 or hi<.7 or hi>1.2:continue
        reliability=min(.8,margin*1.5)
        means[r]*=1-reliability;means[r,best]+=reliability
        region_shaft_corrections+=1
    purity=means.max(axis=1) if count else np.zeros(0)
    strength=np.clip((purity-.35)/.55,0,1)
    # Promote coherent regional evidence; a diffuse region stays a mixture.
    means=means**3
    means/=np.maximum(means.sum(axis=1),1e-12)[:,None]
    # A confident connected source region can support a head piece beyond a
    # tight geometric box (ears/chin). Respect the fitted neck floor.
    head=index.get('head');head_extensions=0
    if head is not None:
        head_support=np.zeros(n)
        for v,r,w in zip(vi,ri,rw):
            if means[r,head]>=.85 and purity[r]>=.6:head_support[v]+=w*means[r,head]
        up,_,_=body_axes(markers)
        floor=np.asarray(markers.get('head_base',head_region_seeds(markers)['head_base']))
        height=(p-floor)@np.asarray(up)
        extension=(head_support>.75)&(height>=-scale*.025)
        head_extensions=int(np.sum(extension&~allowed[:,head]))
        allowed[extension,head]=True
        for i in np.flatnonzero(extension):
            prior[i]=0;prior[i,head]=1
            head_rows[i]={'head':1}
    region_prior=np.zeros_like(prior);region_confidence=np.zeros(n)
    if len(vi):
        c=rw*strength[ri]
        np.add.at(region_prior,vi,means[ri]*c[:,None])
        np.add.at(region_confidence,vi,c)
        region_prior/=np.maximum(region_confidence,1e-12)[:,None]
    blend=.65*region_confidence
    prior=(1-blend[:,None])*prior+blend[:,None]*region_prior
    # Restrict diffusion to local anatomical support. Without this constraint,
    # smoothness can grow tiny far-away channels throughout a connected body.
    support=(prior>1e-5)
    allowed&=support
    prior=skin_simplex(prior,allowed)
    confidence=.4+1.5*np.clip((prior.max(axis=1)-.4)/.6,0,1)
    fixed={};override_conflicts=0
    for node,group in enumerate(groups):
        rows=[]
        for i in group:
            row=overrides[i]
            if row:
                if any(name not in index or not math.isfinite(w) or w<0 for name,w in row.items()):
                    raise RuntimeError('Invalid RR/source/object assignment for region skinning.')
                values=np.array([row.get(name,0) for name in names],dtype=float)
                if values.sum()<=0:raise RuntimeError('Empty fixed skin assignment.')
                rows.append(values/values.sum())
        if rows:
            allowed[node]|=np.any(np.array(rows)>0,axis=0)
            mean=np.mean(rows,axis=0)
            if any(np.max(np.abs(row-mean))>1e-8 for row in rows):override_conflicts+=1
            fixed[node]=mean
        elif head_rows[node]:
            values=np.array([head_rows[node].get(name,0) for name in names])
            if values.sum()>0:
                allowed[node]|=values>0;fixed[node]=values/values.sum()
        # A confident automatic guess is evidence, never an artist constraint.
        # It must remain movable when the connected surface disagrees.
    a=np.array([a for a,b in graph],dtype=int);b=np.array([b for a,b in graph],dtype=int)
    length=np.linalg.norm(p[a]-p[b],axis=1)
    g=np.clip(scale*.012/np.maximum(length,scale*.001),.1,5.)
    # Real surface edges still communicate across source boundaries, with lower
    # conductance. Source regions are soft constraints, not disconnected cages.
    for e,(aa,bb) in enumerate(graph):
        shared=sum(min(w,skin[bb].get(name,0)) for name,w in skin[aa].items())
        if skin[aa] and skin[bb]:g[e]*=.3+.7*shared
    degree=np.bincount(a,weights=g,minlength=n)+np.bincount(b,weights=g,minlength=n)
    if len(g):g/=np.sqrt(np.maximum(degree[a],1e-8)*np.maximum(degree[b],1e-8))
    w,solver=skin_projected_solve(prior,confidence,a,b,g,(vi,ri,rw),strength*1.5,
        allowed,fixed,REGION_SOLVE_MAX_ITERATIONS,REGION_SOLVE_TOLERANCE,REGION_SOLVE_SMOOTHNESS)
    # The inferred skin at a single body joint belongs to adjacent controls.
    # Small nonlocal channels can cause large motion despite little label error.
    # Choose the strongest row and strongest eligible parent/child, normalize
    # their mass, and restore every explicit/head constraint afterwards. This
    # is a compact BODY policy, not a limit imposed on artist-authored RR rows.
    pruned,compatibility=skin_joint_compatible_weights(w,names,candidates,fixed)
    lost=compatibility['maximum_removed_mass']
    output=[{name:float(pruned[node,j]) for j,name in enumerate(names) if pruned[node,j]>0} for node in inverse]
    # Conflicting coincident artist assignments remain distinct original rows.
    for i,row in enumerate(overrides):
        if row:
            total=sum(row.values());output[i]={name:float(value/total) for name,value in row.items() if value>0}
    uncertainty=1-pruned.max(axis=1)
    return output,{'method':'source_region_constrained_graph','engine_version':'0.10.0',
        'graph_positions':n,'graph_edges':len(graph),'source_regions':count,
        'region_supported_positions':int(np.sum(region_confidence>0)),
        'mixed_or_uncertain_source_regions':int(np.sum(purity<.8)),
        'bilateral_torso_source_regions':bilateral_regions,
        'shaft_supported_source_regions':region_shaft_corrections,
        'head_extension_positions':head_extensions,'virtual_seam_distance':tolerance,
        'conflicting_fixed_seam_nodes':override_conflicts,'maximum_pruned_mass':lost,
        'joint_compatibility':compatibility,
        'uncertain_positions':int(np.sum(uncertainty>.4)),
        'uncertainty_means':'Blended/inferred influences, not calibrated correctness probability.',
        'initial_surface_report':initial_report,
        'pose_audit':skin_pose_audit(points,edges,output,specs,scale,markers),
        'solver':solver,'limits':'Original region IDs never encode anatomy. RR rows are fixed. Adjacent-pair inference suits compact humanoid body rigs; complex multi-joint garment intent needs explicit assignments.'}


def skin_joint_compatible_weights(w,names,candidates,fixed):
    """Remove inferred nonlocal branches, retaining the most likely joint pair."""
    import numpy as np
    w=np.asarray(w,dtype=float)
    n,k=w.shape
    if k!=len(names) or k!=len(candidates) or not np.isfinite(w).all() or (w<0).any() or not np.allclose(w.sum(1),1,atol=1e-8):
        raise RuntimeError('Invalid weights for skeletal compatibility.')
    compatible=np.array([[i==j or candidates[i]['parent']==names[j] or candidates[j]['parent']==names[i]
                         for j in range(k)] for i in range(k)])
    owner=w.argmax(axis=1)
    eligible=compatible[owner].copy()
    eligible[np.arange(n),owner]=False
    second=np.argmax(np.where(eligible,w,-1),axis=1)
    keep=np.zeros_like(w,dtype=bool)
    keep[np.arange(n),owner]=True
    valid_second=eligible[np.arange(n),second]
    keep[np.arange(n)[valid_second],second[valid_second]]=True
    pruned=np.where(keep&(w>1e-6),w,0)
    lost=float(np.max(1-pruned.sum(axis=1)))
    pruned/=pruned.sum(axis=1)[:,None]
    for node,row in fixed.items():pruned[node]=row
    exempt=np.zeros(n,bool)
    for node in fixed:exempt[node]=True
    removed=np.maximum(0,1-np.where(keep,w,0).sum(1));removed[exempt]=0
    return pruned,{'policy':'inferred_parent_child_pair; explicit/head rows retained',
                  'corrected_positions':int(np.sum(removed>1e-6)),
                  'maximum_removed_mass':float(removed.max()),
                  'average_removed_mass':float(removed.mean()),
                  'explicit_or_head_exempt_positions':int(exempt.sum())}


"""Reversible Blender sidebar pose checks; never creates an Action/keyframes."""


def rune_preview_poses():
    return [('neutral','Neutral',()),
            ('head_turn','Head turn',(('head','up',30),)),
            ('head_tilt','Head tilt',(('head','forward',20),)),
            ('shoulder_l','Left shoulder',(('clavicle.L','forward',30),)),
            ('shoulder_r','Right shoulder',(('clavicle.R','forward',-30),)),
            ('arm_l','Left arm',(('upper_arm.L','forward',45),)),
            ('arm_r','Right arm',(('upper_arm.R','forward',-45),)),
            ('elbow_l','Left elbow',(('forearm.L','left',60),)),
            ('elbow_r','Right elbow',(('forearm.R','left',60),)),
            ('wrist_l','Left wrist',(('hand.L','up',35),)),
            ('wrist_r','Right wrist',(('hand.R','up',35),)),
            ('hip_l','Left hip',(('thigh.L','left',35),)),
            ('hip_r','Right hip',(('thigh.R','left',35),)),
            ('knee_l','Left knee',(('shin.L','left',60),)),
            ('knee_r','Right knee',(('shin.R','left',60),))]


def register_rune_rig_preview(bpy):
    """Register once per Blender session. Also callable from a standalone Text."""
    if not hasattr(bpy,'types') or not hasattr(bpy,'props'):
        return {'status':'unavailable_in_offline_adapter'}
    if hasattr(bpy.types,'RUNERIG_PT_quick_check'):
        return {'status':'already_registered','location':'3D View > N sidebar > RuneRig'}
    from mathutils import Matrix,Vector
    import json,math,time
    backup_key='rune_rig_pose_preview_backup'

    def active_rig(context):
        obj=context.object
        if obj and obj.type=='MESH':
            obj=next((m.object for m in obj.modifiers if m.type=='ARMATURE' and m.object),None)
        return obj if obj and obj.type=='ARMATURE' and obj.get('source_rig_name') else None

    def restore(rig,clear=True):
        if rig is None or backup_key not in rig:return False
        saved=json.loads(rig[backup_key])
        for name,values in saved.items():
            bone=rig.pose.bones.get(name)
            if bone:bone.matrix_basis=Matrix(values)
        if clear:del rig[backup_key]
        return True

    def apply(rig,mode,sign):
        if rig.animation_data and (rig.animation_data.action or rig.animation_data.drivers or
                                  any(t.strips and not t.mute for t in rig.animation_data.nla_tracks)):
            raise RuntimeError('Use an unanimated conversion copy for pose checks; animation is left intact.')
        if any(b.constraints for b in rig.pose.bones):
            raise RuntimeError('Use an unconstrained conversion copy for pose checks.')
        moves=next((moves for key,label,moves in rune_preview_poses() if key==mode),None)
        if moves is None:raise RuntimeError('Unknown pose check.')
        if backup_key not in rig:
            rig[backup_key]=json.dumps({b.name:[list(row) for row in b.matrix_basis] for b in rig.pose.bones})
        restore(rig,False)
        pelvis=rig.data.bones.get('pelvis');head=rig.data.bones.get('head')
        if not pelvis or not head:raise RuntimeError('Pose checker requires pelvis and head controls.')
        up=(head.head_local-pelvis.head_local).normalized()
        forward=Vector((0,-1,0))
        if rig.get('fitted_landmarks_world_json'):
            m=json.loads(rig['fitted_landmarks_world_json'])
            forward=rig.matrix_world.to_3x3().inverted()@(Vector(m['forward'])-Vector(m['chest']))
        forward=(forward-up*forward.dot(up)).normalized()
        if forward.length<1e-8:forward=Vector((1,0,0))
        axes={'up':up,'forward':forward,'left':up.cross(forward).normalized()}
        for name,axis,degrees in moves:
            bone=rig.pose.bones.get(name)
            if bone is None:continue
            local_axis=(bone.bone.matrix_local.to_3x3().inverted()@axes[axis]).normalized()
            bone.matrix_basis=bone.matrix_basis@Matrix.Rotation(math.radians(degrees*sign),4,local_axis)

    class RUNERIG_OT_check_pose(bpy.types.Operator):
        bl_idname='runerig.check_pose';bl_label='Preview pose';bl_options={'REGISTER','UNDO'}
        mode:bpy.props.StringProperty(default='head_turn')
        sign:bpy.props.FloatProperty(default=1)
        def execute(self,context):
            if RUNERIG_OT_check_cycle.running:
                self.report({'WARNING'},'Stop the quick check before selecting a pose.');return {'CANCELLED'}
            rig=active_rig(context)
            if not rig:self.report({'ERROR'},'Select the converted RuneRig armature or body.');return {'CANCELLED'}
            try:apply(rig,self.mode,self.sign);context.view_layer.update()
            except Exception as error:
                restore(rig);self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'FINISHED'}

    class RUNERIG_OT_check_restore(bpy.types.Operator):
        bl_idname='runerig.check_restore';bl_label='Restore original pose';bl_options={'REGISTER','UNDO'}
        def execute(self,context):
            if RUNERIG_OT_check_cycle.running:
                RUNERIG_OT_check_cycle.running.cancel(context)
            rig=active_rig(context)
            if rig:restore(rig);context.view_layer.update()
            return {'FINISHED'}

    class RUNERIG_OT_check_cycle(bpy.types.Operator):
        bl_idname='runerig.check_cycle';bl_label='Run quick movement check'
        running=None
        def execute(self,context):
            if type(self).running:return {'CANCELLED'}
            self.rig=active_rig(context)
            if not self.rig:self.report({'ERROR'},'Select the converted RuneRig armature or body.');return {'CANCELLED'}
            self.steps=[('neutral',1)]+[(key,sign) for key,label,moves in rune_preview_poses() if moves for sign in (1,-1)]
            self.position=0;self.timer=None;self.next_step=time.monotonic()+1.2
            try:
                apply(self.rig,'neutral',1)
                self.timer=context.window_manager.event_timer_add(1.2,window=context.window)
                context.window_manager.modal_handler_add(self);type(self).running=self
            except Exception as error:
                self.cancel(context);self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'RUNNING_MODAL'}
        def modal(self,context,event):
            if type(self).running is not self:return {'CANCELLED'}
            if event.type in {'ESC','RIGHTMOUSE'}:self.cancel(context);return {'CANCELLED'}
            # Blender Event does not expose the originating timer. A monotonic
            # deadline ignores unrelated faster TIMER events in the same window.
            if event.type=='TIMER' and time.monotonic()>=self.next_step:
                try:
                    if self.position>=len(self.steps):self.cancel(context);return {'FINISHED'}
                    key,sign=self.steps[self.position];self.position+=1
                    self.next_step=time.monotonic()+1.2
                    apply(self.rig,key,sign);context.view_layer.update()
                except Exception as error:
                    self.cancel(context);self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'PASS_THROUGH'}
        def cancel(self,context):
            if self.timer:context.window_manager.event_timer_remove(self.timer);self.timer=None
            try:restore(self.rig);context.view_layer.update()
            except ReferenceError:pass
            type(self).running=None

    class RUNERIG_PT_quick_check(bpy.types.Panel):
        bl_label='RuneRig quick check';bl_idname='RUNERIG_PT_quick_check'
        bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='RuneRig'
        def draw(self,context):
            layout=self.layout;rig=active_rig(context)
            layout.label(text='Select the converted rig or body.')
            layout.operator('runerig.check_cycle',text='Run 35-second check',icon='PLAY')
            layout.operator('runerig.check_restore',text='Restore pose / stop')
            if not rig:return
            if backup_key in rig:layout.label(text='Preview active: restore before export.',icon='INFO')
            for key,label,moves in rune_preview_poses():
                if not moves:continue
                row=layout.row(align=True);row.label(text=label)
                for sign in (1,-1):
                    op=row.operator('runerig.check_pose',text='+' if sign==1 else '−');op.mode=key;op.sign=sign
            layout.label(text='No keyframes or Actions are created.')
    registered=[]
    try:
        for cls in (RUNERIG_OT_check_pose,RUNERIG_OT_check_restore,RUNERIG_OT_check_cycle,RUNERIG_PT_quick_check):
            bpy.utils.register_class(cls);registered.append(cls)
    except Exception:
        for cls in reversed(registered):bpy.utils.unregister_class(cls)
        raise
    return {'status':'registered','location':'3D View > N sidebar > RuneRig',
            'instructions':'Run quick check or choose an individual pose. Restore before export. Animation is not modified.'}




"""Fitting controls and visual inspection. Original rig/materials remain untouched."""

FIT_OPTIONAL_MARKERS=('clavicle.L','clavicle.R')
FIT_SECTIONS=('Body','Head Region','Left Arm','Right Arm','Left Leg','Right Leg','Direction')


def fit_marker_label(name):
    part=name.split('.')[0]
    label={'pelvis':'Pelvis center','spine_low':'Lower spine center','chest':'Rib cage center',
           'neck':'Neck base joint','head':'Skull rotation joint','head_tip':'Skull top (extent)',
           'head_base':'Below chin (boundary)','head_side':'Outer ear tip (boundary)',
           'shoulder':'Shoulder socket','elbow':'Elbow hinge center','wrist':'Wrist joint',
           'hand_tip':'Middle knuckle row (extent)','hip':'Hip socket','knee':'Knee hinge center',
           'ankle':'Ankle joint','toe':'Ball of foot / toe bend','toe_tip':'Toe end (extent)',
           'forward':'Facing direction','clavicle':'Collarbone inner joint'}.get(part,name)
    if name.endswith(('.L','.R')):label+= ' — '+('character left' if name.endswith('.L') else 'character right')
    return label


def fit_bone_endpoints():
    result={n:(n,tail) for n,tail in (('pelvis','spine_low'),('spine_low','chest'),
                                    ('chest','neck'),('neck','head'),('head','head_tip'))}
    for side in ('L','R'):
        for bone,h,t in (('clavicle','clavicle','shoulder'),('upper_arm','shoulder','elbow'),
                         ('forearm','elbow','wrist'),('hand','wrist','hand_tip'),
                         ('thigh','hip','knee'),('shin','knee','ankle'),('foot','ankle','toe'),('toe','toe','toe_tip')):
            result[bone+'.'+side]=(h+'.'+side,t+'.'+side)
    return result


def fit_control_label(name):
    part=name.split('.')[0]
    label={'pelvis':'Pelvis','spine_low':'Lower spine','chest':'Rib cage','neck':'Neck','head':'Head',
           'clavicle':'Collarbone','upper_arm':'Upper arm','forearm':'Forearm','hand':'Hand',
           'thigh':'Thigh','shin':'Lower leg','foot':'Foot','toe':'Toes'}.get(part,name)
    if name.endswith(('.L','.R')):label+=' — '+('character left' if name.endswith('.L') else 'character right')
    return label


def fit_markers_from_bones(markers,endpoints,scale):
    """Read a draft atomically; shared joints must agree before writing points."""
    proposals={};expected=fit_bone_endpoints()
    if set(endpoints)!=set(expected):raise RuntimeError('The fitting skeleton is missing or has renamed bones. Rebuild it from points.')
    for bone,(h,t) in expected.items():
        for name,p in zip((h,t),endpoints[bone]):
            if len(p)!=3 or not all(math.isfinite(float(v)) for v in p):raise RuntimeError('Invalid fitting bone coordinates.')
            proposals.setdefault(name,[]).append(tuple(float(v) for v in p))
    result=dict(markers)
    for name,positions in proposals.items():
        if any(math.dist(positions[0],p)>scale*.002 for p in positions[1:]):
            raise RuntimeError(f'{fit_marker_label(name)} has disconnected bone endpoints. Join the shared joint before applying.')
        result[name]=tuple(sum(p[i] for p in positions)/len(positions) for i in range(3))
    guided_specs(result)  # Reject collapsed bones before modifying any marker.
    return result


def fit_signature(markers):
    return json.dumps({n:list(p) for n,p in sorted(markers.items())},sort_keys=True,allow_nan=False)


def fit_placement_report(markers,points=None):
    """Conservative placement checks. Surface proximity cannot prove containment."""
    errors=[];warnings=[];specs=[];scale=None
    try:
        if not all(len(p)==3 and all(math.isfinite(float(v)) for v in p) for p in markers.values()):
            raise RuntimeError('Some point coordinates are invalid.')
        specs,_,scale=guided_specs(markers)
        repair_guided_sides(markers,False)
        fitted_head_volume(markers['head'],markers,scale)
    except (RuntimeError,ValueError,KeyError,TypeError) as error:
        errors.append(str(error))
    if errors:return {'errors':errors,'warnings':warnings,'can_convert':False}
    lookup={s['name']:s for s in specs}
    for part in ('upper_arm','forearm','thigh','shin'):
        lengths=[math.dist(lookup[part+'.'+s]['head'],lookup[part+'.'+s]['tail']) for s in ('L','R')]
        if max(lengths)>min(lengths)*1.6:
            warnings.append(part.replace('_',' ').capitalize()+': left/right lengths differ greatly; check both views or accept intentional asymmetry.')
    if points:
        import numpy as np
        p=np.asarray(points,dtype=float)
        for spec in specs:
            if spec['name']=='root':continue
            samples=np.array([np.array(spec['head'])*(1-t)+np.array(spec['tail'])*t for t in (.2,.5,.8)])
            nearest=np.linalg.norm(samples[:,None,:]-p[None,:,:],axis=2).min(axis=1)
            if nearest.max()>scale*.10:
                warnings.append(spec['name']+': part of this bone is far from body vertices; check its placement.')
    return {'errors':errors,'warnings':warnings,'can_convert':True,
            'limits':'Checks detect inconsistent placement and large surface gaps, not exact bone containment or correct skin ownership.'}


def fit_style_marker(obj,name,scale,size_multiplier=1):
    obj.empty_display_type='SPHERE';obj.empty_display_size=max(scale*.020*size_multiplier,.001)
    obj.show_in_front=True;obj.show_name=False
    obj['rune_rig_friendly_label']=fit_marker_label(name)
    obj['rune_rig_placement_help']=landmark_help(name)


def fit_palette(name):
    # Distinct hues for adjacent controls, not only a shared limb color.
    central={'pelvis':(.9,.45,.1),'spine_low':(.95,.72,.12),'chest':(.75,.9,.15),
             'neck':(.35,.9,.45),'head':(.15,.85,.7)}
    if name in central:return central[name]
    part=name.split('.')[0]
    i=['clavicle','upper_arm','forearm','hand','thigh','shin','foot','toe'].index(part) if part in ('clavicle','upper_arm','forearm','hand','thigh','shin','foot','toe') else 0
    colors=([(.25,.4,.95),(.15,.65,.95),(.15,.85,.95),(.45,.95,.8),(.4,.3,.95),(.65,.4,.95),(.6,.7,.95),(.8,.85,.95)]
            if name.endswith('.L') else [(.95,.25,.35),(.95,.45,.3),(.95,.65,.4),(.95,.8,.7),(.85,.2,.65),(.95,.4,.8),(.95,.6,.9),(.95,.85,.9)])
    return colors[i]


def fit_selected_object(bpy,context,obj):
    if context.mode!='OBJECT':raise RuntimeError('Apply skeleton edits or leave Edit Mode before selecting a point.')
    for selected in context.selected_objects:selected.select_set(False)
    obj.hide_set(False);obj.hide_select=False;obj.select_set(True)
    context.view_layer.objects.active=obj


def register_rune_rig_fitting(bpy):
    """Session UI backed by current converter; explicit updates avoid handler edits."""
    if not hasattr(bpy,'types') or not hasattr(bpy,'props') or not hasattr(bpy,'app'):
        return {'status':'unavailable_in_offline_adapter'}
    from mathutils import Matrix,Vector
    import textwrap
    key='rune_rig_fitting_backend'
    ns=bpy.app.driver_namespace
    previous=ns.get(key)
    # Keep registered UI classes, but replace its converter implementation after
    # rerunning a Text. Buttons must never call a previous release's converter.
    backend={'version':UNIVERSAL_VERSION,'source':None,'overlay':None,
             'preview_stale':False,'last_report':None,'draw_handle':None,'geometry_handler':None}
    if previous:
        for n in ('source','overlay','preview_stale','last_report','draw_handle','geometry_handler'):backend[n]=previous.get(n)
    elif hasattr(bpy.types,'RUNERIG_PT_fitting'):
        # Driver namespace is cleared on file load, registered classes survive.
        panel=bpy.types.RUNERIG_PT_fitting
        backend['draw_handle']=getattr(panel,'_rune_rig_fit_draw_handle',None)
        backend['geometry_handler']=getattr(panel,'_rune_rig_fit_geometry_handler',None)
    ns[key]=backend

    def collection_for(source):
        return next((c for c in bpy.data.collections if c.get('rune_rig_guide_source')==source.name),None)

    def current_source(context):
        def fitting(source):
            c=collection_for(source) if source else None
            return source if c and not c.hide_viewport else None
        obj=context.object
        if obj:
            if obj.get('source_rig_name'):return None
            name=obj.get('rune_rig_fit_source')
            if not name and obj.get('rune_rig_landmark'):
                for c in bpy.data.collections:
                    if c.get('rune_rig_guide_source') and obj in guide_objects(c):name=c['rune_rig_guide_source'];break
            if name:
                source=bpy.data.objects.get(name)
                if fitting(source):return source
            if obj.type=='MESH':obj=next((m.object for m in obj.modifiers if m.type=='ARMATURE' and m.object),None)
            if obj and obj.get('source_rig_name'):return None
            if obj and obj.type=='ARMATURE' and fitting(obj):return obj
        source=bpy.data.objects.get(backend.get('source') or '')
        return fitting(source)

    def owned(source):
        c=collection_for(source)
        return {o.get('rune_rig_landmark'):o for o in guide_objects(c) if o.get('rune_rig_landmark')} if c else {}

    def markers(source):return {n:tuple(o.matrix_world.translation) for n,o in owned(source).items()}

    def draft_for(source):
        return next((o for o in bpy.data.objects if o.type=='ARMATURE' and o.get('rune_rig_fit_draft') and o.get('rune_rig_fit_source')==source.name),None)

    def draft_endpoints(draft):
        return {b.name:(tuple(draft.matrix_world@b.head_local),tuple(draft.matrix_world@b.tail_local)) for b in draft.data.bones}

    def points_for(source):
        return [tuple(o.matrix_world@v.co) for o in conversion_meshes(bpy,source) for v in o.data.vertices]

    def check(source,geometry=False):
        report=fit_placement_report(markers(source),points_for(source) if geometry else None)
        backend['last_report']={'source':source.name,'marker_signature':fit_signature(markers(source)),**report};return report

    def need_source(context):
        source=current_source(context)
        if not source:raise RuntimeError('Run the converter on the original import once to create fitting guides.')
        backend['source']=source.name;return source

    def show_section(source,section):
        for n,o in owned(source).items():o.hide_set(section!='ALL' and guide_section(n)!=section)

    def toggle_source(context):
        source=need_source(context);source.hide_set(not source.hide_get())

    def repair_sides(context):
        source=need_source(context)
        if context.mode!='OBJECT':raise RuntimeError('Apply skeleton edits or leave Edit Mode before repairing point labels.')
        m,repaired=repair_guided_sides(markers(source),True)
        if repaired:
            for name,o in owned(source).items():
                if name in m:o.matrix_world.translation=Vector(m[name])
            context.view_layer.update();backend['overlay']=None;backend['preview_stale']=True
        return repaired

    def select_point(context,name):
        source=need_source(context);objects=owned(source)
        if name not in objects:raise RuntimeError('That point is not present. Apply skeleton edits to add collarbone inner points.')
        show_section(source,context.scene.rune_rig_fit_section)
        fit_selected_object(bpy,context,objects[name])

    def set_view(context,side):
        source=need_source(context);m=markers(source);up,forward,left=body_axes(m)
        z=Vector(forward if side=='FRONT' else left);y=Vector(up);x=y.cross(z).normalized()
        region=context.space_data.region_3d
        region.view_rotation=Matrix((x,y,z)).transposed().to_quaternion()
        region.view_perspective='ORTHO'
        p=Vector(m['pelvis']);h=Vector(m['head_tip']);region.view_location=(p+h)*.5
        region.view_distance=math.dist(m['head_tip'],m['ankle.L'])*1.5

    def make_draft(context):
        source=need_source(context)
        if context.mode!='OBJECT':raise RuntimeError('Leave Edit Mode before rebuilding the fitting skeleton.')
        m=markers(source);specs,_,scale=guided_specs(m);report=check(source)
        if report['errors']:raise RuntimeError(report['errors'][0])
        c=collection_for(source);old=draft_for(source)
        data=bpy.data.armatures.new(source.name+'_RuneRig_FitSkeleton')
        obj=old or bpy.data.objects.new(source.name+'_RuneRig_FitSkeleton',data)
        old_data=old.data if old else None
        selected=list(context.selected_objects);active=context.view_layer.objects.active
        if old:obj.data=data
        else:c.objects.link(obj)
        try:
            obj['rune_rig_fit_draft']=True;obj['rune_rig_fit_source']=source.name
            obj.matrix_world=Matrix.Identity(4);obj.show_in_front=True;obj.hide_render=True
            obj.hide_select=False;obj.hide_set(False);data.display_type='OCTAHEDRAL';data.pose_position='REST'
            fit_selected_object(bpy,context,obj);bpy.ops.object.mode_set(mode='EDIT')
            bones={}
            for s in specs:
                if s['name']=='root':continue
                b=data.edit_bones.new(s['name']);b.head=s['head'];b.tail=s['tail'];b.use_deform=False;bones[b.name]=b
            for s in specs:
                if s['name'] not in bones:continue
                b=bones[s['name']];parent=bones.get(s['parent'])
                if parent:
                    b.parent=parent;b.use_connect=(Vector(b.head)-Vector(parent.tail)).length<scale*1e-6
            bpy.ops.object.mode_set(mode='OBJECT')
            obj['rune_rig_fit_marker_snapshot']=fit_signature(m)
            obj['rune_rig_fit_bone_snapshot']=json.dumps(draft_endpoints(obj),sort_keys=True)
            for o in owned(source).values():o.hide_set(True)
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            if context.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
            if old:obj.data=old_data
            else:bpy.data.objects.remove(obj,do_unlink=True)
            if data.users==0:bpy.data.armatures.remove(data)
            for o in selected:
                try:o.select_set(True)
                except ReferenceError:pass
            context.view_layer.objects.active=active
            raise
        if old_data and old_data.users==0:bpy.data.armatures.remove(old_data)

    def apply_draft(context):
        source=need_source(context);draft=draft_for(source)
        if draft is None:raise RuntimeError('Create a fitting skeleton first.')
        if context.mode=='EDIT_ARMATURE' and context.object==draft:bpy.ops.object.mode_set(mode='OBJECT')
        if context.mode!='OBJECT':raise RuntimeError('Leave the other object\'s Edit Mode first.')
        m=markers(source)
        if draft.get('rune_rig_fit_marker_snapshot')!=fit_signature(m):
            raise RuntimeError('Points changed after the skeleton was built. Rebuild from points before applying skeleton edits.')
        _,_,scale=guided_specs(m)
        updated=fit_markers_from_bones(m,draft_endpoints(draft),scale)
        report=fit_placement_report(updated)
        if report['errors']:raise RuntimeError(report['errors'][0])
        objects=owned(source);c=collection_for(source);created=[];before={n:o.matrix_world.copy() for n,o in objects.items()}
        try:
            for name,p in updated.items():
                if name not in objects:
                    o=bpy.data.objects.new('RR_'+name,None);o['rune_rig_landmark']=name;o['rune_rig_fit_source']=source.name
                    fit_style_marker(o,name,scale,context.scene.rune_rig_fit_handle_size)
                    destination=next((child for child in c.children if child.get('rune_rig_guide_section')==guide_section(name)),c)
                    destination.objects.link(o);objects[name]=o;created.append(o)
                objects[name].matrix_world.translation=Vector(p)
            context.view_layer.update()
        except Exception:
            for n,matrix in before.items():objects[n].matrix_world=matrix
            for o in created:bpy.data.objects.remove(o,do_unlink=True)
            raise
        draft['rune_rig_fit_marker_snapshot']=fit_signature(markers(source))
        draft['rune_rig_fit_bone_snapshot']=json.dumps(draft_endpoints(draft),sort_keys=True)
        draft.hide_set(True);show_section(source,context.scene.rune_rig_fit_section)
        fit_selected_object(bpy,context,source);backend['overlay']=None;backend['preview_stale']=True
        return report

    def preview_weights(context):
        source=need_source(context)
        if context.mode!='OBJECT':raise RuntimeError('Apply skeleton edits and use Object Mode before previewing weights.')
        draft=draft_for(source)
        if draft and json.dumps(draft_endpoints(draft),sort_keys=True)!=draft.get('rune_rig_fit_bone_snapshot'):
            raise RuntimeError('Apply skeleton edits before previewing weights.')
        m=markers(source);report=check(source,True)
        if report['errors']:raise RuntimeError(report['errors'][0])
        specs,_,scale=guided_specs(m);meshes=conversion_meshes(bpy,source)
        rules=validate_source_region_targets(dict(GUIDED_SOURCE_REGION_TARGETS),{b.name:b.parent.name if b.parent else None for b in source.data.bones},specs)
        batches,regions,counts=prepare_guided_weight_batches(meshes,specs,rules,dict(GUIDED_OBJECT_TARGETS),{b.name for b in source.data.bones if b.use_deform})
        results=guided_batch_weights(batches,specs,scale,m,regions)
        triangles=[];weights=[]
        for mesh,batch,(rows,info) in zip(meshes,batches,results):
            mesh.data.calc_loop_triangles()
            for triangle in mesh.data.loop_triangles:
                for i in triangle.vertices:triangles.append(batch[1][i]);weights.append(rows[i])
        context.view_layer.update()  # Flush triangle-cache updates before caching.
        backend['overlay']={'source':source.name,'points':triangles,'rows':weights,
                            'marker_signature':fit_signature(m),'vertex_counts':[len(o.data.vertices) for o in meshes],
                            'mesh_names':[o.name for o in meshes],'mesh_data_names':[o.data.name for o in meshes],
                            'geometry_stale':False}
        backend['preview_stale']=False
        text=bpy.data.texts.new(source.name+'_RuneRig_FitCheck.json')
        text.write(json.dumps({'converter':UNIVERSAL_VERSION,'placement':report,
                              'weight_reports':[info for rows,info in results]},indent=2,allow_nan=False))
        return report

    def convert(context):
        source=need_source(context)
        if context.mode!='OBJECT':raise RuntimeError('Click Apply skeleton edits before conversion.')
        draft=draft_for(source)
        if draft and json.dumps(draft_endpoints(draft),sort_keys=True)!=draft.get('rune_rig_fit_bone_snapshot'):
            raise RuntimeError('The skeleton has unapplied edits. Apply them or rebuild from points before conversion.')
        report=check(source,True)
        if report['errors']:raise RuntimeError(report['errors'][0])
        fit_selected_object(bpy,context,source)
        global GUIDED_LANDMARKS_READY,CONVERSION_MODE
        old_ready,old_mode=GUIDED_LANDMARKS_READY,CONVERSION_MODE
        try:
            GUIDED_LANDMARKS_READY=True;CONVERSION_MODE='GUIDED';result=universal_main()
        finally:GUIDED_LANDMARKS_READY,CONVERSION_MODE=old_ready,old_mode
        if result:
            if draft:
                try:draft.hide_set(True)
                except (ReferenceError,RuntimeError):pass
            backend['overlay']=None;backend['last_report']=None
        return result

    def resize(context):
        source=current_source(context)
        if not source:return
        m=markers(source)
        try:_,_,scale=guided_specs(m)
        except Exception:return
        for name,o in owned(source).items():fit_style_marker(o,name,scale,context.scene.rune_rig_fit_handle_size)

    def vertex_lock(context,clear=False):
        source=need_source(context);obj=context.object
        if obj is None or obj.type!='MESH' or obj not in conversion_meshes(bpy,source):
            raise RuntimeError('Select vertices on an included ORIGINAL body mesh. Renamed accessories are excluded.')
        target=context.scene.rune_rig_fit_weight_control
        if not clear and target=='ALL':raise RuntimeError('Choose a specific preview control before locking vertices.')
        if context.mode not in ('OBJECT','EDIT_MESH'):raise RuntimeError('Select original body vertices in mesh Edit Mode.')
        editing=context.mode=='EDIT_MESH'
        if editing:obj.update_from_editmode()
        ids=[v.index for v in obj.data.vertices if v.select]
        if not ids:raise RuntimeError('Select a small surface patch in mesh Edit Mode first.')
        if editing:bpy.ops.object.mode_set(mode='OBJECT')
        try:
            rr={g.index:g for g in obj.vertex_groups if g.name.startswith('RR:')}
            removing={i:[] for i in rr}
            for i in ids:
                for membership in obj.data.vertices[i].groups:
                    if membership.group in rr:removing[membership.group].append(i)
            for i,vertices in removing.items():
                if vertices:rr[i].remove(vertices)
            if not clear:
                group=obj.vertex_groups.get('RR:'+target) or obj.vertex_groups.new(name='RR:'+target)
                group.add(ids,1,'REPLACE')
            context.view_layer.update();backend['overlay']=None;backend['preview_stale']=True
        finally:
            if editing:bpy.ops.object.mode_set(mode='EDIT')
        return len(ids)

    backend.update(source_for=current_source,owned=owned,markers=markers,check=check,
                   select=select_point,view=set_view,build=make_draft,apply=apply_draft,
                   preview=preview_weights,convert=convert,resize=resize,section=show_section,
                   toggle_source=toggle_source,repair_sides=repair_sides,vertex_lock=vertex_lock)

    def draw_overlay():
        state=bpy.app.driver_namespace.get(key)
        if not state:return
        context=bpy.context;source=state['source_for'](context)
        if not source:return
        c=collection_for(source)
        if not c or c.hide_viewport:return
        try:
            import gpu
            from gpu_extras.batch import batch_for_shader
            m=state['markers'](source);specs,_,scale=guided_specs(m)
            # A moved fit must never display cached ownership as current output.
            overlay=state.get('overlay')
            if overlay and overlay['source']==source.name:
                counts=[len(o.data.vertices) for o in conversion_meshes(bpy,source)]
                stale=overlay.get('geometry_stale',False) or overlay['marker_signature']!=fit_signature(m) or overlay['vertex_counts']!=counts
                state['preview_stale']=stale
                if not stale and context.scene.rune_rig_fit_show_weights:
                    selected=context.scene.rune_rig_fit_weight_control
                    if overlay.get('batch_control')!=selected:
                        colors=[]
                        for row in overlay['rows']:
                            if selected=='ALL':
                                rgb=tuple(sum(fit_palette(n)[j]*w for n,w in row.items()) for j in range(3))
                            else:
                                w=row.get(selected,0);rgb=(.12+.88*w,.12+.55*w,.15*(1-w))
                            colors.append((*rgb,.8))
                        overlay['shader']=gpu.shader.from_builtin('SMOOTH_COLOR')
                        overlay['batch']=batch_for_shader(overlay['shader'],'TRIS',{'pos':overlay['points'],'color':colors})
                        overlay['batch_control']=selected
                    shader=overlay['shader'];batch=overlay['batch']
                    gpu.state.blend_set('ALPHA');gpu.state.depth_test_set('LESS_EQUAL');gpu.state.depth_mask_set(False)
                    shader.bind();batch.draw(shader)
            if context.mode=='EDIT_ARMATURE':return  # Editable bones already draw themselves.
            shader=gpu.shader.from_builtin('UNIFORM_COLOR');gpu.state.depth_test_set('NONE');gpu.state.blend_set('ALPHA')
            section=context.scene.rune_rig_fit_section
            for spec in specs:
                if spec['name']=='root':continue
                group=('Left Arm' if spec['name'].endswith('.L') else 'Right Arm') if spec['name'].startswith(('clavicle.','upper_arm.','forearm.','hand.')) else ('Left Leg' if spec['name'].endswith('.L') else 'Right Leg') if '.' in spec['name'] else 'Body'
                if section!='ALL' and group!=section and not(section=='Head Region' and spec['name'] in ('head','neck')):continue
                batch=batch_for_shader(shader,'LINES',{'pos':[spec['head'],spec['tail']]})
                shader.bind();shader.uniform_float('color',(*fit_palette(spec['name']),1));gpu.state.line_width_set(3);batch.draw(shader)
            # The exact fitted head ownership box (including the existing top
            # allowance/depth rule), rather than an unrelated decorative cage.
            if section in ('ALL','Head Region'):
                up,forward,left=body_axes(m);region={**head_region_seeds(m),**m};origin=m['head']
                dot=lambda p,a:sum(x*y for x,y in zip(vsub(p,origin),a))
                lo=dot(region['head_side.R'],left)-scale*.003;hi=dot(region['head_side.L'],left)+scale*.003
                bottom=dot(region['head_base'],up);top=dot(m['head_tip'],up)+scale*.08
                depth=max(math.dist(m['head_tip'],m['head'])*1.6,scale*.06)
                corners=[tuple(origin[i]+left[i]*x+forward[i]*y+up[i]*z for i in range(3)) for x in (lo,hi) for y in (-depth,depth) for z in (bottom,top)]
                lines=[corners[i] for a in range(8) for b in range(a+1,8) if (a^b) in (1,2,4) for i in (a,b)]
                batch=batch_for_shader(shader,'LINES',{'pos':lines});shader.bind();shader.uniform_float('color',(.2,1,.65,.7));gpu.state.line_width_set(1);batch.draw(shader)
        except (RuntimeError,ValueError,KeyError,ReferenceError):pass
        finally:
            try:
                gpu.state.line_width_set(1);gpu.state.depth_mask_set(True);gpu.state.depth_test_set('NONE');gpu.state.blend_set('NONE')
            except Exception:pass

    backend['draw']=draw_overlay
    if not backend['draw_handle']:
        def draw_current():
            state=bpy.app.driver_namespace.get(key)
            if state:state['draw']()
        backend['draw_handle']=bpy.types.SpaceView3D.draw_handler_add(draw_current,(),'WINDOW','POST_VIEW')

    if not backend['geometry_handler'] and hasattr(bpy.app,'handlers'):
        def geometry_changed(scene,depsgraph):
            state=bpy.app.driver_namespace.get(key);overlay=state.get('overlay') if state else None
            if not overlay:return
            for update in depsgraph.updates:
                ident=update.id.original
                if (isinstance(ident,bpy.types.Object) and ident.name in overlay['mesh_names'] and
                    (update.is_updated_geometry or update.is_updated_transform)) or (
                    isinstance(ident,bpy.types.Mesh) and ident.name in overlay['mesh_data_names'] and update.is_updated_geometry):
                    overlay['geometry_stale']=True;state['preview_stale']=True;break
        backend['geometry_handler']=geometry_changed
        bpy.app.handlers.depsgraph_update_post.append(geometry_changed)
    elif backend['geometry_handler'] and hasattr(bpy.app,'handlers') and backend['geometry_handler'] not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(backend['geometry_handler'])

    if hasattr(bpy.types,'RUNERIG_PT_fitting'):return {'status':'backend_updated','version':UNIVERSAL_VERSION}

    def state():return bpy.app.driver_namespace[key]
    def section_update(self,context):
        b=state();source=b['source_for'](context)
        if source:b['section'](source,self.rune_rig_fit_section)
    def size_update(self,context):state()['resize'](context)
    bpy.types.Scene.rune_rig_fit_section=bpy.props.EnumProperty(name='Show points',items=[('ALL','All body parts','Show all fitting points')]+[(s,s,s) for s in FIT_SECTIONS],default='ALL',update=section_update)
    bpy.types.Scene.rune_rig_fit_handle_size=bpy.props.FloatProperty(name='Handle size',default=1,min=.4,max=3,update=size_update)
    bpy.types.Scene.rune_rig_fit_show_weights=bpy.props.BoolProperty(name='Show predicted weights',default=True)
    bpy.types.Scene.rune_rig_fit_weight_control=bpy.props.EnumProperty(name='Preview control',items=[('ALL','All regions','Distinct colors for inferred bone weights')]+[(n,fit_control_label(n),'Preview influence of '+n) for n in fit_bone_endpoints()],default='ALL')

    class RUNERIG_OT_fit_point(bpy.types.Operator):
        bl_idname='runerig.fit_point';bl_label='Select fitting point';bl_options={'REGISTER','UNDO'}
        landmark:bpy.props.StringProperty()
        @classmethod
        def description(cls,context,properties):return landmark_help(properties.landmark)
        def execute(self,context):
            try:state()['select'](context,self.landmark)
            except Exception as error:self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'FINISHED'}

    class RUNERIG_OT_fit_action(bpy.types.Operator):
        bl_idname='runerig.fit_action';bl_label='RuneRig fitting';bl_options={'REGISTER','UNDO'}
        action:bpy.props.StringProperty()
        def execute(self,context):
            try:
                b=state()
                if self.action in ('FRONT','SIDE'):b['view'](context,self.action)
                elif self.action in ('build','apply','preview','convert','toggle_source','repair_sides'):b[self.action](context)
                elif self.action in ('lock_vertices','clear_locks'):
                    count=b['vertex_lock'](context,self.action=='clear_locks');self.report({'INFO'},str(count)+' selected vertices updated; refresh preview.')
                elif self.action=='check':
                    source=b['source_for'](context)
                    if source is None:raise RuntimeError('Select the original source or a fitting point.')
                    report=b['check'](source,True)
                    self.report({'ERROR' if report['errors'] else 'WARNING' if report['warnings'] else 'INFO'},
                                report['errors'][0] if report['errors'] else report['warnings'][0] if report['warnings'] else 'Placement checks passed. Inspect the weight preview and movement before export.')
                else:raise RuntimeError('Unknown fitting action.')
                context.area.tag_redraw()
            except Exception as error:self.report({'ERROR'},str(error));return {'CANCELLED'}
            return {'FINISHED'}

    class RUNERIG_PT_fitting(bpy.types.Panel):
        bl_label='RuneRig fitting';bl_idname='RUNERIG_PT_fitting'
        bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='RuneRig'
        def draw(self,context):
            b=state();source=b['source_for'](context);layout=self.layout
            if not source:
                layout.label(text='Run converter on the original import once.');return
            layout.label(text='Fit: '+source.name);layout.label(text='L/R = the character\'s own sides.')
            layout.operator('runerig.fit_action',text='Hide / show imported bones').action='toggle_source'
            row=layout.row(align=True)
            for action,text in (('FRONT','Front view'),('SIDE','Side view')):row.operator('runerig.fit_action',text=text).action=action
            layout.prop(context.scene,'rune_rig_fit_handle_size');layout.prop(context.scene,'rune_rig_fit_section')
            objects=b['owned'](source);m=b['markers'](source)
            # The common selection problem is solved by direct list buttons.
            for section in FIT_SECTIONS:
                if context.scene.rune_rig_fit_section not in ('ALL',section):continue
                if hasattr(layout,'panel'):
                    header,box=layout.panel('runerig_fit_'+section.replace(' ','_'),default_closed=section!='Body')
                    header.label(text=section)
                    if box is None:continue
                else:box=layout.box();box.label(text=section)
                for name in objects:
                    if guide_section(name)==section:box.operator('runerig.fit_point',text=fit_marker_label(name).split(' — ')[0]).landmark=name
            active=context.object;name=active.get('rune_rig_landmark') if active else None
            if name:
                box=layout.box();box.label(text=fit_marker_label(name))
                for line in textwrap.wrap(landmark_help(name),width=43):box.label(text=line)
                box.label(text='Joint center: fit in BOTH views.' if name.split('.')[0] not in ('head_tip','head_base','head_side','hand_tip','toe_tip','forward') else 'Extent/direction marker; see instructions above.')
                box.prop(active,'location',text='Position' if active.parent is None else 'Local position')
            box=layout.box();box.label(text='Alternative: fit the connected skeleton')
            box.operator('runerig.fit_action',text='Build / rebuild skeleton from points').action='build'
            box.operator('runerig.fit_action',text='Apply skeleton edits to points').action='apply'
            box.label(text='Edit bone endpoints; apply before preview.')
            report=fit_placement_report(m)
            for message in report['errors']:
                for line in textwrap.wrap(message,width=43):layout.label(text=line,icon='ERROR')
            layout.operator('runerig.fit_action',text='Repair fully reversed L/R labels').action='repair_sides'
            layout.operator('runerig.fit_action',text='Check placement against body').action='check'
            if b.get('last_report') and b['last_report']['source']==source.name and b['last_report'].get('marker_signature')==fit_signature(m):
                for message in b['last_report']['warnings'][:4]:
                    for line in textwrap.wrap(message,width=43):layout.label(text=line)
            layout.operator('runerig.fit_action',text='Calculate / refresh weight preview').action='preview'
            layout.prop(context.scene,'rune_rig_fit_show_weights');layout.prop(context.scene,'rune_rig_fit_weight_control')
            layout.label(text='Bright = stronger selected influence.' if context.scene.rune_rig_fit_weight_control!='ALL' else 'Colors distinguish predicted body regions.')
            if b.get('preview_stale'):layout.label(text='Fit changed: refresh the weight preview.',icon='INFO')
            box=layout.box();box.label(text='Optional: correct a small surface patch')
            box.label(text='Select ORIGINAL body vertices in Edit Mode.')
            box.operator('runerig.fit_action',text='Lock selected vertices to preview control').action='lock_vertices'
            box.operator('runerig.fit_action',text='Clear selected vertex locks').action='clear_locks'
            row=layout.row();row.enabled=report['can_convert'] and context.mode=='OBJECT'
            row.operator('runerig.fit_action',text='Convert fitted model').action='convert'
            layout.label(text='Preview colors are overlays; materials stay intact.')

    registered=[]
    try:
        for cls in (RUNERIG_OT_fit_point,RUNERIG_OT_fit_action,RUNERIG_PT_fitting):
            bpy.utils.register_class(cls);registered.append(cls)
    except Exception:
        for cls in reversed(registered):bpy.utils.unregister_class(cls)
        if backend['draw_handle']:bpy.types.SpaceView3D.draw_handler_remove(backend['draw_handle'],'WINDOW')
        handler=backend['geometry_handler']
        if handler and hasattr(bpy.app,'handlers') and handler in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(handler)
        ns.pop(key,None)
        for prop in ('rune_rig_fit_section','rune_rig_fit_handle_size','rune_rig_fit_show_weights','rune_rig_fit_weight_control'):
            if hasattr(bpy.types.Scene,prop):delattr(bpy.types.Scene,prop)
        raise
    RUNERIG_PT_fitting._rune_rig_fit_draw_handle=backend['draw_handle']
    RUNERIG_PT_fitting._rune_rig_fit_geometry_handler=backend['geometry_handler']
    return {'status':'registered','version':UNIVERSAL_VERSION,'location':'3D View > N > RuneRig'}


"""Reviewed correction replay; exact source skeleton and surface matching only."""

def correction_point_key(point):
    if len(point)!=3 or not all(math.isfinite(float(v)) for v in point):
        raise RuntimeError('Correction profile has invalid coordinates.')
    return tuple(round(float(v),5) for v in point)


def correction_surface_fingerprint(batches):
    """Source-armature coordinates, independent of names/order/duplicate seams.

    Faces remain a multiset. This allows separating/joining pieces and welding
    identical vertices, without treating a different surface as the same asset.
    Face winding and materials do not determine anatomical ownership.
    """
    import hashlib
    points=set();faces=[]
    for positions,polygons in batches:
        keys=[correction_point_key(p) for p in positions];points.update(keys)
        for face in polygons:
            if len(face)<3 or any(i<0 or i>=len(keys) for i in face):
                raise RuntimeError('Invalid face in correction profile matching.')
            faces.append(tuple(sorted(keys[i] for i in face)))
    payload={'points':sorted(points),'faces':sorted(faces)}
    return hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest()


def correction_mesh_batches(source,meshes):
    inverse=source.matrix_world.inverted()
    batches=[]
    for obj in meshes:
        transform=inverse@obj.matrix_world
        batches.append(([tuple(transform@v.co) for v in obj.data.vertices],
                        [tuple(face.vertices) for face in obj.data.polygons]))
    return batches


def choose_reviewed_correction(source,meshes,parents,heads):
    candidates=[p for p in builtin_reviewed_corrections() if guided_profile_matches(p,parents,heads)]
    if not candidates:return None
    fingerprint=correction_surface_fingerprint(correction_mesh_batches(source,meshes))
    candidates=[p for p in candidates if p.get('corrected_skin',{}).get('source_surface_fingerprint')==fingerprint]
    if len(candidates)>1:raise RuntimeError('Multiple reviewed corrections match this source. Disable USE_REVIEWED_CORRECTIONS and choose an explicit fitting profile.')
    if not candidates:
        print('Reviewed skeleton found, but source surface differs; using ordinary fitting instead of applying its skin corrections.')
        return None
    profile=candidates[0];profile_landmarks(profile)
    print('Matched reviewed correction:',profile['name'])
    return profile


def reviewed_accessory_exclusions(source,meshes,parents,heads):
    """Recognize reviewed separate pieces only when the remaining body matches.

    Returns suggestions without mutating Blender. Ordinary unknown models still
    need an explicit name/property; a separate mesh alone is not an exclusion.
    """
    candidates=[p for p in builtin_reviewed_corrections() if guided_profile_matches(p,parents,heads)]
    if not candidates:return []
    batches=correction_mesh_batches(source,meshes)
    for profile in candidates:
        parts=profile['corrected_skin'].get('excluded_part_fingerprints',{})
        proposed=[]
        for i,(obj,batch) in enumerate(zip(meshes,batches)):
            if excluded_object(obj):continue
            fingerprint=correction_surface_fingerprint([batch])
            label=next((name for name,key in parts.items() if key==fingerprint),None)
            if label:proposed.append((i,label))
        if not proposed:continue
        body=[batch for i,(obj,batch) in enumerate(zip(meshes,batches))
              if not excluded_object(obj) and i not in {j for j,name in proposed}]
        if body and correction_surface_fingerprint(body)==profile['corrected_skin']['source_surface_fingerprint']:
            return [(meshes[i],label) for i,label in proposed]
    return []


def reviewed_correction_rows(profile,batches,specs):
    targets={s['name'] for s in specs if s['name']!='root'}
    lookup={}
    for entry in profile['corrected_skin']['entries']:
        point,row=entry
        key=correction_point_key(point)
        if (not isinstance(row,dict) or not row or any(n not in targets or not math.isfinite(w) or w<=0 for n,w in row.items())
            or abs(sum(row.values())-1)>1e-6):raise RuntimeError('Invalid reviewed correction weight row.')
        if key in lookup and lookup[key]!=row:raise RuntimeError('Ambiguous coincident positions in reviewed corrections.')
        lookup[key]=row
    result=[]
    for points,faces in batches:
        rows=[]
        for point in points:
            key=correction_point_key(point)
            if key not in lookup:raise RuntimeError('Reviewed surface matched but a vertex has no correction row. Source retained.')
            rows.append(dict(lookup[key]))
        result.append(rows)
    return result


def apply_reviewed_corrections(profile,source,meshes,specs,batches):
    """Explicit RR paint/object/region overrides take precedence over replay."""
    if len(meshes)!=len(batches):raise RuntimeError('Reviewed correction mesh batch count differs.')
    rows=reviewed_correction_rows(profile,correction_mesh_batches(source,meshes),specs)
    result=[]
    for obj,corrected,batch in zip(meshes,rows,batches):
        overrides=batch[3]
        if len(overrides)!=len(corrected):raise RuntimeError('Reviewed correction override row count differs.')
        for i,override in enumerate(overrides):
            if override:corrected[i]=guided_vertex_weights(batch[1][i],specs,1.0,override)
        result.append((corrected,{'method':'reviewed_asset_corrections','profile':profile['name'],
            'source_surface_fingerprint':profile['corrected_skin']['source_surface_fingerprint'],
            'graph_meshes':[obj.name],'graph_statistics_scope':'this object',
            'explicit_override_vertices':sum(bool(x) for x in overrides),
            'reference_gap_repairs':profile['corrected_skin'].get('reference_gap_repairs',[]),
            'limits':'Exact reviewed source surface and skeleton only. Reference weights normalized; recorded missing-weight repairs are inferred and need runtime inspection.'}))
    return result


def builtin_reviewed_corrections():
    import base64,zlib
    return json.loads(zlib.decompress(base64.b64decode('eNqsvduOJMeRLforAz5nJfx+mV/YB+dhXgsNokW2JGK4SaFJjQ4gzL+ftcwv5lnlEdVk5N4zGKk60zPCzd2uy5a9/vu7r//85cv3X3/62/f/+PrrX3/6+ct3/2lv3/3y+f/iP3z3f3765W//8V+/fv75x//4+uV/fvryry8//scPv379+uWH33/69Zff/sMZl16sebH2u9t3v/36z68/4Fv//u4fn79++eX33/gf/99ff/zyvYvf/ecv//z559t3X3/99ffvLVYef79995df8fv8U/+3/iH3/kNufMiND/n3H/LjQ358KLz/UBgfCuND8f2H4vhQHB9K7z+UxofS+FB+/6E8PpTHh8r7D5XxoTI+VN9/qI4P1fEhaza7aeZ2mvm53a7rts99t5uNt3Pn7dx6u9l7Ozffzt23m+23c//tFIDdSMBOEdgpA7sRgp1SsFMMdiMHOwVhpyTsRhR2ysJOYdiNNOwUh53ycBt5uCkPN+XhNvJwUx5O78HuIuhNmPJwG3m4KQ835eE28nBTHm7Kw23k4aY83JSH28jDTXm4KQ+3kYeb8nBTHm4jDzfl4aY83EYebsrDTXn4jTz8lIef8vAbefgpDz/l4Tfy8FMeXlXTTjepcpry8Bt5+CkPP+XhN/LwUx5+ysNv5OGnPPyUh9/Iw095+CkPv5GHn/LwUx5+Iw8/5eGnPMJGHmHKI0x5hI08wpRHmPIIG3mEKY8w5RE28ghTHkGtxc5cqL2Y8ggbeYQpjzDlETbyCFMeYcojbOQRpjzClEfYyCNMeYQpj7CRR5jyCFMecSOPOOURpzziRh5xyiNOecSNPOKUR5zyiBt5xCmPOOURN/KIUx5RDfjOgqsJn/KIG3nEKY845RE38ohTHnHKI27kEac84pRH3MgjTnnEKY+0kUea8khTHmkjjzTlkaY80kYeacojTXmkjTzSlEea8kgbeaQpjzTlkTbySFMeSX2qnVOlXtWUR9rII015pCmPtJFHmvJIUx5pI4805ZGmPPJGHnnKI0955I088pRHnvLIG3nkKY885ZE38shTHnnKI2/kkac88pRH3sgjT3nkKY+8kUee8sjq5u78XHV0pzzyRh55yiNPeeSNPPKUR57yKBt5lCmPMuVRNvIoUx5lyqNs5FGmPMqUR9nIo0x5lCmPspFHmfIoUx5lI48y5VGmPMpGHmXKo0x5lI08ypRH0chjF3po7DHlUTbyKFMeZcqjbuRRpzzqlEfdyKNOedQpj7qRR53yqFMedSOPOuVRpzzqRh51yqNOedSNPOqUR53yqBt51CmPOuVRN/KoUx51yqNu5FGnPKoGg7toUMPBJR7cBoRLRKghodnFhEaDQqNRodmFhUbjQqOBodlFhkZDQ6OxodkFh0ajQ6PhodnFh0YDRKMRotmFiEZjRKNBotlFiUbDRKNxotkFikYjRaOhotnFikaDRaPS2obvS/y+BvDbCH4J4VVa2yB+ieKXMH4bxy+B/BLJb0P5JZZfgvltNL+E80s8vw3ol4h+Cem3Mf0S1C9R/TasX+L6JbDfRvZLaK+xvd0F91aje6vhvd3F91YDfOuWjMs25bLkXFRauyjfaphvNc63u0DfaqRvNdS3u1jfarBvNdq3u3DfarxvNeC3u4jfashvNea3u6DfatRvNey3u7jfauBvNfK3u9DfauxvNfi3u+jfavhvNf63uwSA1QyA9UuKbJsjW5JkKq1dGsBqHsBqIsDuMgFWUwFWcwF2lwywmg2wmg6wu3yA1YSA1YyA3aUErOYErCYF7C4rYDUtYDUvYHeJAauZAaupAbvLDVhNDljNDthdesBqfsBqgsDuMgRWUwQ2LDnNbVJzyWqqtHZ5AquJAquZArtLFVjNFVhNFthdtsBqusBqvsDuEgZWMwZWUwZ2lzOwmjSwmjWwu7SB1byB1cSB3WUOrKYOrOYO7C55YDV7YDV9YHf5A6sJBKsZBLtLIVjNIdi4JKG3WeglDa3S2iUSrGYSrKYS7C6XYDWZYDWbYHfpBKv5BKsJBbvLKFhNKVjNKdhdUsFqVsFqWsHu8gpWEwtWMwt2l1qwmluwmlywu+yC1fSC1fyC3SUYrGYYrKYY7C7HYDXJYNNSNdiWDZa6gUprl2mwmmqwmmuwu2SD1WyD1XSD3eUbrCYcrGYc7C7lYDXnYDXpYHdZB6tpB6t5B7tLPFjNPFhNPdhd7sFq8sFq9sHu0g9W8w9WExB2l4GwmoKwmoOwuySE1SyEzUuZZ1vnWQo9Kq1dKsJqLsJqMsLushFW0xFW8xF2l5CwmpGwmpKwu5yE1aSE1ayE3aUlrOYlrCYm7C4zYTU1YTU3YXfJCavZCavpCbvLT1hNUFjNUNhdisJqjsJqksLushRW0xS2LHW5bWFuqcyptHa5CqvJCqvZCrtLV1jNV1hNWNhdxsJqysJqzsLukhZWsxZW0xZ2l7ewmriwmrmwu9SF1dyF1eSF3WUvrKYvrOYv7C6BYTWDYTWFYXc5DKtJDKtZDLtLY1jNY9i6FFK3ldSllLrUUrfF1KWaquXUXS7DaS7DaS7D7XIZTnMZTnMZbpfLcJrLcJrLcLtchtNchtNchtvlMpzmMpzmMtwul+E0l+E0l+F2uQynuQynuQy3y2U4zWU4zWW4XS7DaS7DaS7D7XIZTnMZzi7F7231eyl/q7R2uQynuQynuQy3y2U4zWU4zWW4XS7DaS7DaS7D7XIZTnMZTnMZbpfLcJrLcJrLcLtchtNchtNchtvlMpzmMpzmMtwul+E0l+EWnMIWqLAgFRaowharsIAVVrTCFq6w4BVUWlvEwgJZWDALW9DCglpYYAtb3MICXFiQC1vowoJdWMALW/TCAl9Y8AtbAMOCYFggDFsMwwJi0FyG2+UynOYynOYy3C6X4TSX4TSX4Xa5DKe5DOcXeMkWX7IATFRau1yG01yG01yG2+UynOYynOYy3C6X4TSX4TSX4Xa5DKe5DKe5DLfLZTjNZTjNZbhdLsNpLsNpLsPtchlOcxlOcxlul8twmstwmstwu1yG01yG01yG2+UynOYyXFjwQFtA0IIIUmntchlOcxlOcxlul8twmstwmstwu1yG01yG01yG2+UynOYynOYy3C6X4TSX4TSX4Xa5DKe5DKe5DLfLZTjNZTjNZbhdLsNpLsNpLsPtchlOcxlOcxlul8twmstwcQFwbRFcC4RLpbXLZTjNZTjNZbhdLsNpLsNpLsPtchlOcxlOcxlul8twmstwmstwu1yG01yG01yG2+UynOYynOYy3C6X4TSX4TSX4Xa5DKe5DKe5DLfLZTjNZfA//u/tu79/+fzjI1j21dzNrf/vJ0XNvvnzQM7uPo0nf7XuHmIuAVGVt6nUEG+p3rFBobhciimxhluO9W5cralgOzKiqk+Ktv3zKwx07mu4l+RDicV6G0xJ9RbdPYdasvEG33I1317i3ZhUC8xNiibHNJ/h0goD/Mu34L8hCqsVrxFMuoVwtzFzTVc9XvGWjbnjI9bEGrGwdZ8UKvynFxjI4ldr7znngi0q+ISPNt0SPm6KTwXbVpL1/vaS7iYGX3yOIXsDT+WTIpEvLDGgy1efIl1/ityWQCgCKeGjofhS8s2aco8lhmBjqT7iW7cXf4+5RgNRIiDEVudPCqa+ssaAX1/djXJ9N2o7Wsa6bBIObaw24zDHfK+2Wptq9iWnijvn4j3kis/wuCe9o5dWmPBxvofHp3C+vcfZxWPfSr5D6+Nqp8DNxK17sffkik02eLxqKSVNkVxdZALUuQj2MuBap+oTPuJu/o4vwLfBTbPYVez2LWXscjT4WPFuvawX15gAeFnDZeg977L3FvLjo2fLZRPeJGT8s5VFYvG1BEj304KW/7MLTGj9dZn4Z8gkPONJwjOeJD7jSeIzniQ940nSM54kP+NJ8jOehNrwxVp/NxlOAf0FY23GxXP3iusFxyH7mkOyt1DTvVJPe2sjQsHwaWm6uLDGbNJ4fXEBd8rhTlXEOc1cZ3e3nno54PrjT3gZOEsJq1rcQ1/htk6lenWR2QaCt3EGmthjUzPMla3R3wLeBqrZQOVAa1f8Idq7wcZb7LaH0bCflq6RP7/EbDJ5fan5HuiwwUjAZEIR3jxUkU+wngHb6viVGwR6DxVmCtta3eoHXltjNrG8vqRwpzKEjUKw7vGYNw/FnEqGd1mC8d7BTqV7glKM3jnoyTQ1+6UVZoPMqw32XvnYpR1gd7P5ng2iwYy3g3tXTMR2QtDYS9+Mekyfln6aP7/EbL95tT7euW2wAA72AAf4Bgc2Jpwl53CiM494vkeIEyffulKNPsOFBWZjz6uvd18hJdhIBCE40HKYzR0WsuJoO7j8dCSgFqo3NnnItPlZn5ZWoEurzOah18LtSzhAON5tERwt/J+UZtThIdZwr7CUFleSJ1wPxqUlZmvSK+9Z9PAb4DTJuYk3+EyGDhRUHuLq0k44NE9N0Ax0GabJv7TCbHt6tQxjXDQ2lIznRmBxSxC0M5aHqhp+B7sZEWfhpeDPwcsLfmrQi2vMtqpXj5irVuibXKGGGfW9QPcVvFKG/m2Pfiu4/jHWnKyBXwvhflq6sP78ErNpS7xruErOIawyVCi43PCqEOCFHLCbnm7TDdbpjheACrCP6vPiGrMprHn5+LzDnsUIt9JzDZx6RHs2QgV7XnjcBai8aLAILpsejWtLzJaz1xfRKAkWsMScUsJ9uuFAZwYWJTr4kwaq8eZ4CEPkO8PNV6f04hqzpa3pYGNxfTJiLZhF6D9YKLxbwHfFLsJU4mTfEWsU2OwULH/o09IDd2WR2TQHEw31A//E4H+gVOBq4yv4E9xpB1sVsNnYZwf3IZiCMBDHP3HdT0uX3ZVFZlve60uod8i10jOSf8XV97z6uIcRX4KezriHUNV3yNbgb9ASUEmflj6+K4vMxr/XzEdfw5qb6GgcPuuSD7qEh1MDD8qFgmP5aekT/PNLzLbCVwTBiWkjPDuOD+43jhmjVHgPuIXdscOmQg1lGivYrYftuLbGbFt8LXAOLEL/DGdRgqwbpI1bXxM8FImFIVpIuzKxk3D1qJY+LU2Of3qF2RL5Wus9eFxvBKPiJNmbLdg6GG84EjGYyBtnJTxnuOrFi1me4toas+Xyarrj4hqzpfM1wC2BewBrhCiCLlq6VWglU03o4TpW9XDwsR60FGL2RYtdWmG2i/I9JNSppWYboV2gfqAHsVqG74rXMXBxoY8pfIfgpyf9Pi3tpRfWmO2oonwqvuEROYQAf6ne4LXhWEHTpGpaMgf3kOoIpxwGAid8GrhrS8xm19cMhxkHJtBlkBiGCVbsJFQfHFgcqYjtNOmO90rYcVy/umQ7ri0xW2nFNhmDA4QHL1mcWviwiPwkXRMkQYI1qBBxpgxtRVLP/NoSs1EXhglOSjFUdzXhUUtihAHTk3meXTNWVESMMPASYjkX7/zqIrMV+LXCOSpwaQNUSgv7oIahbnCuIOUEXWO5BEwoDjlsZAvBPi2dw39+idlo/Epv3kPNV5hD2D985obwB66jp2tZxdNNssnwXEKE+8vV9TGurTEbmcVhgM3z0z+6wcHMNuNkQf1Yw3QvV+AeJ9gjqGynKfwrK8wmaSZacZwhPIYVMVfGWHccaBxm+Pe+5VlhPSPOlvepil/zaWmp/tMrzAbsqxHCxTVmg/fl53BPeA7/hOfwT3iO8ITnCE94jviE54hPeI70hOdIT3iO/ITnyE94jicUm+ITqk1RPEl/R9gLdxr/KNEDs6uMjhGYw0uRem6CtxCqNXRkHqorl1aY5AYXS8LXlpjUCVefwl5/iifo0fQEPZqeoEfTE/RoeoIeTU/Qo+kJejQ9QY+mJ+jR9AQ9mp6gR9MT9Ghq9aFyd/AP4aom+Ir4arwVixCrmhhtjqxMxNtLudObwpo9eTAzHFcXmdQhr84gwIGiyxnBn89M4FlEOB6hBjRySc4bepR3/GvxcPlKEDXwaaEaubDGpCa5qMfydW2an+CX5if4pWxles3xzmod3HrfS3TO+Tsca3zScYexnyXcA6IzWEnTFv200LD86RUmacsrTlfBp2H+ekI1cD8R9fHLiCoYnHM/g5QuAw+cM4hKPi0sL1cWmbQwV72Oi2tM2pnrkJ/4BMxPTs94kvSMJ5H8pr/zHwyOfE8IBHc3CdqALhQrJ7cX7HPJlSlx6xGSJjfzDNeWmMQ8ry+slvoE4bUzlcvNJ7xd9HgjHCdWVFnPY2oJ71UdHD6z3Jhra0zin8sntV4/qeUJWdLyhCxpkXo7TANL+zFBuMVk6CN+JRBSFH020Aw2EdcEZVyYWUkpZegkfZKrq0xypNcIi4QP2FR9poefeLRhLAsEnFxmQcvf3J2vlT10VkcJfFrIlC6sMcmXLt6Ya0tMaqerN+biGpM66vJJfQKmtDwBVFqegCpl/+hFP+jaEpNY66ofVJ5QwS/1Cc9Rrz8Hm2pf3d2xJpFMgrKR2swtsQYdDNQBtFLLF/hU73VBkcznuLjGJB57JaqsQPG4aqBzrMnhFuKdSoBeHsQrHhaLRvzvNcTC8s0stVxcYxKbXTyl15aYtGlXn+I6Kr+KFiT21SRbMm51bagdouo9BU2gXUslhTu8rMQK20N7wrUlJuXb1b2I1/ciPSFmuLrIpKzbtZhs/j6p67afLwefrwefrwcdL+YJLtnVRZQpb9t9Y+zRsz8hvXd1EeXj2z+7P3r28Ix9D8/Y93j07EddUuyN338jHX0jH30jH32jHH2jHH2jHn3j6OzbZ5x9+4yzb+0znsQ+40ncwS5u/kHZDfffODr70q2w/UY4+kZ8xv7EZ+zP0dm3R2ffHp19e3T27dHZt0dn39Zn7M8TInxhanyNGerUGMhTAFRFPAYExCknYqxSIpYa2jVYwrkQEpsUlt6eK0soM+TlRPblVZR68nqy4foyym65PVvu6LYKGv6aC3dxDWXQvPwc8QnP8YSQ/Ooiyv55/UnyM56kPONJyjOe5Bma0D1DE/pneBf+Gd6FP/Ks/ZFn7d0znt0949mvpyUvrqHksRebNi6uocy01yXzDE/IH3lC/sgTEtA5zGnEsQ4jieQLkdaZbdUu+BqlAe/2Eu4+JZaAak0EAC+7eHEVJdjdP/2Rj+WfoVn8MzSLAMV3z775B2XzvWo7w3U8jm2wbpcIEw3JFCv9L5VX0bGLPpUB1L15iy2pCEKdwydXOPTlVZSLuK3ChtcSW3IRbiXesVS2g/jWqnTDGYLAQsm20W/UTyt18Z9fQ4mO2YMa7+6hQerGLpHK+oRUPdlX5XO4w/WtBS/NTgnNYlxcRHmUmYKFzwh5RjjWIQZ7wxGF650d+3ID23jCDZ4mkyFszLUPKcOLayhJM1/G3eG/loBTZNkFW2+l3nM1AQKtKUuTjHfwzo2T9v/HbqzLqygLNFYxkQ2WIcZo4Gdby95t7KjF3e19sjcfsQjh5tW/PSWX1lCK6dea75CsZVNQaYh/tvBArFiFTRLSuI1tZSuej8bUvOD3ry2h7NWviDDYCgr129ujbjbccZzwUtV7itciWmPUlPLsNPu0cl3/6SWUGPuVgvUVaqgi+KnSiBANu9jxCrDiUPrG37zHGtKta6qcuk8rj/afX0NZt19fKkM/2UA8dbXhVvAHhGgm6JtA8lDvo1dGT8aVFZTO+xXH9s7uV5eHlrtFqBsffGT3Y+/188Hgd0aXxqeV+/vPrqA84a/OE3gPv4Y9fQ3Dw64ElokiHOrWFHPLJPXBJWhSX9p7ry6iNOSvuPl3Qv9jv0XuhqiZpaLqUz/3GVe+3mE8wmxz/7Sylv/5NZTjnK0I0qgTTQq9A6PiwWEnAhzAjuPNvt5hOJLJsFJ26ca/uIYSqDfNQ4c2VQhb4MK34nHdaoAeTAF+KFRg9nec+5Te78elNZSdfeuxxKMcWINjX/UVr66iLPCXPb/4DM8vPSOmTM+IKQWdfbWkdnkVJcm/Bku8toTy7199Cn/9KcL1pwjXnyJef4p4/SnS9ajn2ho67QAa9A6Ng6c2tpgc8MDSsggXgyqnCIcYnY3KNEUMTCSv3ZdXF9FhCnC+7g7xUC0+Rly6KEwe1OOJi7oIny+LqYcfCIfVs3Evqc9ybQ2d1HAV9HZ1ER0E8fqSyZVQ2XQuCX74GHDEYRlIReAb1c70ik0j3lk8qGtr6JSJV5IxJLJYGHg9RhryYdDviEnwGviZ1tmZA3z4EGDtI//g9bBeXESHWNDvyCwhlOJGyzNcM7hfsOo443RBxe3gj7wPAi8tofMx4JWyxoPoJEXfupxugWk8th7XjkYJcsx8Ns70hmR18i8uouM3LoOaL6+i8z1eEdHDnYmwlKZxZWARIShkmap1IcNHNojyHZOIjSpzOa2X1tDhIULZSSYEa1r+FBct8niXwUFE4ibcNqyBLW5QofWwXlpDJ5Mw2+DIXgK/JQoiqR14KB4zLh6PmsnQAhG3ILxxtC8uooNP4Mg6+SfEMDjz2WIzbzXdraXUB60JFkn0bnBBjX/gsbm6iM5VEfYqRFAI5Yp44g7xXLxHBHNQi8OBRygDJxAvDN38oM8urKADW7ilpAWIuPGd0owagG3wcQjb3lIloUAaKy48k9fW0Gkw27ijHFU+BEptMw5DZpBlOoeUHIYKLcU0kURkvB64uvjP1fi3j35tEZ05gzi0sOxdA75FMiHYeyhuaqyAaCVE2RH4A3STAgkRyPuw8P1dWkMH2sDx8PTS8ZCTdyOSFibBAUikxgjMLAZ797AzcIvSo89wbQ2dlsM14FPgsOHbsOk8l+1A4JogJmhMbVgEXoHZcEdcXUSH8VyOwp6BypaxPtej5PKUikqZ5JIwtDD3uTaCwluhInERat528lxPYlic/EK+o7rwrVxdRGcVwbLghfA+LsE9FRV5i56cvZnUHKONGlt+x/9ibxuv0PIk1xbRUUiwtS4Ly5XtYIxmaw0Z6hBRtCys6AEcuzUz92e/rbOVXoWxqMILDHgH2SbSkcDZoRBNY45piSyGUzW5Nx7UxUV0dBM1OXwdH4miwcWzrt4KgyjSOvKPQjUJdY47x83FJx9qPtfW0LlQry8QqYEZY8yQhb6QcB46qFHzDy8IoBBOwvTZjvn5tM6RurCIjp16faGlRyzgYWAryySh1aCx6SSBhTYmKSluGv8oGoA+EPlK8J4LgvVJi+mUK7jMfJkIsbra/As2z2QYEYSWrsJueNgQxICRgbl7q+2vraEjtCQLi9OGLTXNAb0xF++54z6H2KhrU4V1Q2gOh1LQWJ/WgVt/egmdztXKahAhvVIxWzAXKZN7iaob+1ulrMZFSCA3fMNP6zSvC4vo8K/LNqc+A2FTr9NXXlxDB5dJfjxD4XhcL3GGw60aWC1E4aIgpAiMFbD1eIn6JnK/uIZORbtMK2qe0J0t89VeXYIiSLjscJlts+M1ytgEZzt5npXoAf4yFcVjCuHiGjrR7epZvbqIDoy7LpvwDNmITgyyClTj4HDzUlVhWdg4lhfJBJmhAqCsAmdeLB7JtSV01N11yaRnSKYrRQREMZHwvNZGspwslCKdjNS1MRwLZrTgfuYcHwPmy6voqL6uoDMtQhgdozExYcUsEc45jTxMK0MpRJpv6skX19A5gNel84Q6k0wUbGESFCK21XWYc5IiaGLFT3K6ERY8YKfhhTdjqrXti2voDMPLO/KMvgiZhvgqzNvEzuACdjJU9knizsGfgBOTpRLgHanzYeVTh1h8WkcqXlhEJzAKQWeMgtuohrgW2E5CBKCbcOeFdlEy4ZW8x1BZBbeirATSV1fREY889VmiQsQIcCnlS5GJjpJySg16RVAJ4RyI4SDxB47gq4voBEkox3zH5yqRRgJjKOSStSyCZFizRj3MHDxZZRHSNZ79T+vAyT+/ho6npIjtndzLPnLQgqQ6SrnTN8d3BjciTAr/c09zrjfn0ho6+/KVhM81OJdZhUkyx6B4MVr494aHQkCLPYXf6TvNcFqe49IaOlhzl4FzR70sMkpz/42DPi6ZqLn9hjNH37BH3zia9eXc0Tfc0Tf89RrX1UV0tOf+2cPRs8ejb8Sjb6Sjb6Sjb+Sjb+Sjb5RndNJcX0Yni+6f/+icNjC/K3dGOyaLLnWNx5fCdbb2EghiQpL7eXzqDarx4ho6vVQC4wwzLDAr/rNA3/DaGerftvEKkmMjSXsSgMaqtK+toaNRmbhg5MX0vifs3uXY65UUDIyzoD6kXonjPod96HCKq6vo7NXXl+zv2cKwIEwXAuVyy3AJLEe+lGpb7pzDYhy8a/Z/Sf5YjerFRXS061UKlKuL6OTY1xfiK8gAgSCv1yzwUiRfzviixfXw9QYzJNzD+I3AgqVdDuy1RXQw7cUukItr6NTb10ppws7VjqFNTEISQQqnf0DyIF/2LtJANjTcIppLa+hI3VfEEeKVzHEWN0vOekOw6uBhIK7WWgTyiYhKS6v9aR3Be2ERndh72UN/RleEO+qKcEddETIC+PKzh2dEF9LRQKQ+xwxauLdMXreafCZKo4dKZCrM4V7gFkTyauclVX9xDZ1pvN9Df7SHzXk3mSNL4X8U1wAlt1zuxDNwxkdM8rPQypzxGXC8HyFFVxfRycmMN6H0PTN3tpdsmJnnbhf4poKHIo4Zi3BMo4+PfRRXF9HBzPtdPPKFwhMIQK8uouOf989+5K+HIz8oHPlB8eimxqOb2kjVESDCwgd8LLeBsK2ezgE3ObZOhYZZ0aFdS2bz2ho6cPqybb64iM6zfuXICcTuxRPG5YpYVQN9jlM7UTuCljfMs9SOQ/i0jr/+82vosGyqP4SnnDwAF0juwi2xsJN4iQwbFxDMe0aNsCfpDRDo2hI6h3t/oo7ilYZqvxxLXF5GJ35f9W/idb5KmRx+lXb36iI6rfyybX4G5l7mnl8eeHl5FZ22fnlX0jM8luSe8STuGU9yvUP84ho6iP4y58jFVf73f2/f/fz5lx//7+ev//3b95+//t/Pv//z65fvf/vH5x++fPef//7u718+//j9Xz7/9qXjcwmKJWubTKLzLPIRUQJXoaUVGrQOZipnzrPrAbMs8ttPP365/z/MIQt+la1HtY+KJUQGrmWAkHKqBuvCx7xHW8bMtYc1/kvuBRQ7fiK2aavMf2/WiHcmql3vceIq//jy8//89FtLUnJoKWf8dQv1foEAi7vCEWSF3/7xE3b951//9Y2LRA4i5aMmI1OveDV/+PuX336XbMgdm8herdrKppudSESeRfb2McZr4JRfvvzw300ejkgFTteMnn1+xCkTLFixbX2iYWXfZJmzrLmNfeiNrTDieHJpC6t7GcBPlYXGeHKRwu8//eNbl2D+eYBw5fd/+/uv//z5xy9f5SQUf2fhwHByntsLUWakO8fZrg1TijW+/PyXX/8lC9DthjVoZD7S2ce5rwXWs+Vv2JUYcEZdhqVdMs3/+vrTb7+3FTheKHEOuQK7072GBG8Gz+H7LEqiSqForI/Nu+dW4NZwK9oyET8ysT193DuCJTjWbOzwDfSF4wKtgIuSB/xsboccaugTBgoJfnafD/tHNuS/RkhksBVm9HbY3Y7Ue0hEcwqoviX62pa0NVy540QZz069BsR5fzesoI6xPXHWJOeOtFXgAWIjPPv72EZdym5POGsp2di6TtpF71saC5NikJ7MlZOxmDvJGMgvvmnE/u9fvjRVA1MJr4GwQFuksH0LuNIRbmpvKud2cFwh59H6+Scs8fmX//65rcFwmMcLWqS0kokMV7GVLlqbmYZLyooXnhSqvvRZpb//2r5fsZmO+FTTQfG3HInp5X+BihLzBSsPCeExxxys9v15vN6vYRmXUJWH2Gv220X+PqThofoZBdcJzHwv0sOtlBUIbsWHcSbwpi3s+WOb+V+dGxRnl3IVANN2MwNRtIrxyn0z5fuFhh7xs3U+N72feSgmLJlm7mw32yLYDIRQsFte8JBJthP/nf0driF8t6v89dev//r89ccGLMwJhxvXCAoBgdDN0QeBxfOzVyXxcGe8AaFrEn3A2P726z+//vDl+69f/vbTr798//vnr3/78jsM0r/1n2CCv/70/33/r1+//vzj959///6vP9FWMCZpXUJ4w4f4RKKVl80/93/q/7v+6+O/ILo3n/h2P/3++5cfv1d3QB7hrReALzihQjAQkMdb4SAQNljY60xLYMgHXBMnTCM8NJQrjCBRbO9cAaxViUrJUBK1MpQVtCHL/16SDbgmDISYXAmJ0SS0Fv2q9w4BloJPknA0DN1lHo/DpRKieUTvYeKRp1vAlzNGCqR4GSrQ6rbLQNY0XJFLFc5wDG98g29eiTVbmGxJUcGeYrXFQ+AqWAA3zMDR42jRow3CxfNQB7xJBDw7dRNEYAY3HY/Beituu5fzgoVZJpYmcDiEsUmMRXwvTMqNNaB7DLIKTSyNHLQDp5se7W/k5EuH8B+aKaRHt+Hb1+G9gu9mCx1MaY58cB7wHdgVW7PMMycA4GhnSMUg6RCOFcwPDgS0EYJNOskFih2nRzbGc0q5gYJwMk4+Q9qVlx0L8oUYjT84EdRpTprasXuFHpkskwnXgHrEQctcj4cGf6zR8oYgJCjv/Ahzb+NTK2fsskfGtcsFJxfPAvlCyszMYanENhEimIzNcL7TO28CXyP6AvoeygeWHBfjD+5QXwb+JBvQEF8xK9xO4HaP8MQERSZ6J0YGNS5eBbealgP3howUNZpwdLNYlquWxYVI/pt3roVhS6RsJQSHJ8K1P94l+uecXtlGzC8OBr/Alg5EMxy+ScDGsdiIqrGB95wsOKuPgWVIKck6VICTA4HIKtXgv1d6XVZmWd7oxltSH8DYOryrOAnqZnCbDWcEG6nywVFrlxSb6dgkC3tKgosbpQq/DQ4EHUS4vpJaG84G4dsIknGcIdMCX8s2LYhvFISG7Jws+B8xAjB8zJtXLkcmovTG6ThYC6KBIHHwiObA6bJHa/1dxQVlAutMWeIB4O37Q8nv93ksUwnpzQi+2dDh/B/e6HEvsAb7JJmej/Bw8+FOUy9w4niGaxBNWj0R/DPDasT5tEyMP+SlIhN6kZAKmf3rP9rpsRZOnRMee84H9qHvtISNPBDQb+Vwp9UtoXblYF2PK5gTwxF5t8i5upHhDZxHxOa884gMZZI3THVJTnyTH379+vXLD/QBfvvvn36h4f+fL19/g5/y3X/a6Z789s+vf/2M//vXn37525ev//j60y8wVN/91X/Bof3rD7HQV/6h5L/+JcYffrTe//Wv4a8//qX+6P5aPn9hq6xJn2P4Uj7jaPm/5M/5c/1cf/wOOucX+D1faIVfET2QTCbPecBO/FUEAoVkXR0WgCAk37mgXyZK/1t0BbcVhvV/4ehwLQ76FU0pgUhui2EjjOeA5IYdwwJ3lsHKKPUfrhXohbSZ1ngyQvE87us6STdWeJP4MQ0X//3dP//xjy9fmWF5sx5rQsNn5KP5iIAdhiYItxJ5r+Dx3A3HBeuc+7Pl2CU82wUdxwvDAa2KT+PzFeZaB8MXzfzxgjDEIYl71oI0NiFgObh2WCAw2oEc8My0inZGttut46kLY+ZzJitNxv1ypXOgIRhClP0wH3y7DFWHhuJOlvKUL/yE0DqiGVcuSZejpfgpj4uA+9LjbQ5BZj6LbXxyzCT25yRxv+SRtmsVTviGyQi+82SRkwRqE/fQduI0vGIbRNEHU/h8vBiMSX8oQmARaTEDDpen0TnJ2UdMCA+g1MFptF0p03eB+02Bt1fE4cThNdlbaaJ3OA9seTFmkDkFLgWl8qWfBiiQ2+P5wF90fVMHs5DM8kZgimvACRASk+F4FJyYzujQRXFw2BBQwpzbBQgTEStDicCbN7mNy46Gzi58Q7iOts0UOVvPEtWO/x87z17kZPbMUAJyh1+AjXS4XY6qZbCGPbz8m9UQE5pRBaeEoaCacRyNsp7IXN/77JpU9qtJHsfyKrUKWUvUwOp1IC11SzTE7eExcbnqBzeVc0+gghDSTEx7uBMrBDfatJaLG3TDnWYxjXN0cGiwFLmyioRKxKRTX+ZRAmWi00snbkeTHZ++eGdhmR1l4qbzquLZRpMMm6twHAmKLeKeSepkuxBzkVBgLrfxtTci+Cv7rxTqW8kDYJgnsR/uVbjTRVWhM7fEfnnEjXBhJVUmmcNEl7IQwxtrOF8Qesb1K8VkFzQJTDVbkzpoW3rXCFi2PS+yfU9/xy7Ao7S299BDiAyqvXa2wmRBfY9RNu5kpX4GeeqDY+ee5EwEdweXCRGgpbeR60fX0t+xK9BjXYU4JkcqwpTYOcZ4VKlE6A/C6RkYkbMFac2wT8OURxKjZeKFku9MnHIxId6s0O2D93REivWeXpoDarPiElwqW5ujQGIVuEQMzuLU4ccP9wA8czfpQocCKeR26KfF3R8Mx8GzuXthhcOOZnWHtXF/7OQWuWFb6ZzkAcO0Z0/mKAccWcJz2rZJcQBG1DCpJk3OuOGs8HQo1uE5c9Q+sAOdsNHxjNAvpu8Mh18sPW8UOw19O//+/JBYIV5AfNjqlI4FKLYmwktttQveCXL+4L4Ov+7g4fBF7Jvij0jAiZMBTd5NsPBe+rXOdLASA2poDNOwP7g8JAyscLURBEXRQjBPlS6OJGE6QOj4JRk8RKY1egsboe2dvcl3+wcHDieDYehys7aPNkKNDoXNGTFg0TKD3ADq7kkQdGxM2KI7QU98z1zu7LlHsDjQgeKlUVuW2Iolh89lSJQIy16F/pX1Zob0S943koeUZi+5tHmuU3+Bqcis5Dpko8IrQrWPPkmpLSBGVNDt/kHh2PI6Zjs6hVj98sSgLAgZHCXy9ky383AphriTqJLKm44oNnL0YNGlz1h4lIkOF4JQcbqdkOkO3xRR4tSzeEoeQWZPm/t8LFXoncxOsJCGtcR9j/hT07DCuckmNUd6x1beKSeHl8uxf7YM35N9KrxNZI5pWE4nC+LGrrXX0wWp/2tv1roVAnAM8anT4aDnEMJEkh0cOk82AhYuc8sKFhZJcCoQWIfmxDOQkfhBoD3x2ILC/5R42dhGMlOY1gyTUqzZPukc+qb4DMtR5ZDLwNJyh5tLQpAMNWcGe3Mg7Rz5LZrpOt80msmB05D2ctwvZjXgxze3l7yYBDexMOzpNqUDN40+C5OSznez1nC32RElPmSMuwyda5sD9oGhh+qS/Bz8Q/E/GIy6bOBsZM/CJItwjIdohZhL8CcSleb1vGCCWY6PcKBr6fqO9zyVGTd3ie5vQpBErSmj3ChQNyif0YfWonpT7qSPHj9ypsk5HQbHLiePqKeFn+5O58XTnDY+ClxVOLkRZp5oB9flsH9A3GnJ2VZZDYYhwaNhXnEEhEkMzQNy+uzxPNlLYD5rN6c3iY1InzfZyz1JeXLsvV6HjiCXgnqAGFtdTy5Eh030FgyeI4XJnXlujG7YJjt5pDhmJ7CPCGqytqZ89m+EfpEPbyk8I+h77BlzcAycKsEGuFKjOYSUiYEsKXkatfPnYoqbiboeH8Q7bgaJ3KMTF4Fmi5MhmRrMGjl+o9nC+rCB0IoDz4jnhY+OG9+5GXCcE84AmdRz0Ut7/LhQFTgcS9x4ZzquEsDYWz5oc3AKWaDIMyzfbCV7mZ1y6Doh/0LcRwfPNRuOZbCVZZTiD6XCFBjuVex4Jif5EM/7j5C2l+zhsDLxXsqq7DZrGUTuM5KnsaE1S5XljWEdAgHcrFv5U5fEs9qm3Hvsj4FkojSx0/gJ3sLAEOJPeeRpznaf55PUfW4gE8hE86YhHMb5PkkkuK3nC3pD+rWRpCgcSwo7zWxuw4PAAN2705iPd4xJ45yG7b0VQ19enQnqXqqoQbN+sveO+WRb+1dpGFgEWrqqeRuYeqjfEK9heypdEMQ/AiYj+RW85SRtOC2Mj2yCHRyrx/eeHkfhWK5+cUjGSvccBjUbwUCJWYj8uVHQP17JPMSQ4lcRFxiHGm7RUMJrt/TJ2WNJSZizZEWAme26BEN01zGIM+5ZJRpB5KEtcOxBIBlxg/njuBKmlIxS0tFXJYAmsXshx06Zv30wruVcHPK+CY8qWd5N6IwvUDzMB9gwPLtTSSKUnXhx0WMp34lRgPpw9HCs5JxiIrq7+N6mcLacZ/Y9T649kd2wl5LPDpWlcNxTyc0e+TJsUKSmwOFvR6zEu3BeKtIDD4w4POVmMA7PBQIf3JBUGrbQiyup8UyPMIihxXmu9jQbI2vBMPb3gZa5w+/BPWpQMlkqE7SFfR8e9Jl/5WR+A50C6C6BEjFH3LkyoXHI5aNImPOFHDwrbDGbyjsMhhkLJXiUOOMNqcfRgcV3aV9wn3uaFA4yI+a1jSZxQkksUp4+UT3ETLLRdHAzOEFtMWQmL+aA2MET4qjoD/xbrgWFiji9PxjNkYmpcZzauRQuAm6k1yTddinWbFihb8lBRtt0nBBatZQcCYlJv6vR9skrjnwsTwB0YWVauNc+xKPHJ6zhlVc/dLuOY26iTfeQJ5BE08AxUUVAckWpqHYOy1hXfRWuS7KIPOZP3F6YSqvQXhwV0hMXgTOxoVTcNx1cps3pSQzlRwUJ5ZvpbXcPhu4oNIv/INTjxJkHvBci5Mqmh9DUDR8tpvtDve4POGrwGbHlzPcPWsZEL2pqS94zJx5xTs61fT178XBfAbpM+OQ7LCsLrCO7iH0VxrA8dMDBiweKG/6pmRERSSXnWZbkETNuuIu4L3QbDk8OXgAeHyKBFuRWego4uoPAueVjy919U8KTWOoHckv69FLfJJxIykvw1KBM4KqZ3Az80YORGasr+hZp343gBQYpLO5GoH52o5BweMmIW/YkF7XMxko/HfZteoq8H4Y14iVBcrhSYt0itAIoOUHu7G6EJoY3Kj4tDgrcY6xT6+CTOVjJ47p0n5OR1Iu1iMroXkCo/R5ES17v/FjGPNp6nBysRExQ/zbLonDbQu5ViCBJU4La2Hp3pk2s1DIJsOkw1VzuoRH7pT7bycMRQZCBixHOsqaOpQFWYofmobK0DzRzYkI5RbV++FRsTYEYO4vdjTYQHgvz2B32e4vM7Gg59HivSB0ZtduCQNpB/tKywriJMFDDXBzbdSOwcUSfgqtP5OJ3Qm0YZponWnmo4keEevZobLxmBTV7KeMXhmCO+zcn9HjmORNDFnNWzbDMuPOxWr7J3iQomIQEktBhODQpXuxJidEyQwoPahR5Cvtk4Esi7OklJi+nyzBD79o8owP7aaWAQuo2V6S17qWS4bMs7QGiV5cQ/FSvcoQHwbLYHZkVdIMbhf/LglxH/UrZGJGT7Q6hPdVhbEHHncRVGmxzRUg9ZzgiZ59NzlWZbw5eFMppXhnCiSX2CTmMVD3elMXbJct7/mDQOyWUMmhoWX+nY5vYyEa/HecfcR7ilVkW/WA9a9j03FnXb/TWiQ3IM6eIiKAwyZhGJef8CTMZNaFv5jA6wiKgY2Hyuq8tVK1vq9qbvROSaLgyTa+SEBhu3qCZa9aetj0y96RN0GdPJsMzJBURaeMIdJzlqCLsToWTC9YYdvtc8AYg0MZUTXJCei8E7M+iIVOu5+E5VmFLBIzg8GzhA9mHiB2xEysJuBHp41QaIjneaeYs2pwqhmIIphzxiiX1IrJlTTss5NZHd53eHE1RHGRYBKSwamPwJJKrgXdBvZdxz/sFPXpTKC87W2roMEmXF5RbDO1JPctLwgnr3RnAxiYB0eEItDRwvVWsRY+eWqg0rE7GDWOscR7vW8lNhzrK0EyI4mJxOMYMW8SOwzb4tXixXQoB4axUM0R0dwf9IVDW3qsC5wIn/jE1dSRJ4gQsHLxWdWIGLnOeIfzv3rfFrqJC+v0aezH75NnoPwc/6BioanibcpwDvSR3wOFuTpkJvyUwsORP5U3vCYV0s55xQaGnObjxA2xExQ6WnsI9S2OSho8z5uC2NhQLgUqcAYCXHLEej7BdqLmP9K40uprqRnQv89OydPu26i00Z4QN9XGlVP3muIDrG0ICBuCGG4tnLLOxTlwagmTHlMdw+KSeBalpmIR0Ao44nJPaQBm4MSzg1GYsW+P52SY6ajCiAoxkGYiuKAZ+ZJwJSsQqdxYjp/t7viChsKqv4aYGohaZmZ4tXYJuwbuqpftgSZkq11PITlgq2Weorj6rObVU68/he1yKHREIVHrhBdtOshH2FjW8Hu4256Hi9M2Gp9OH4yQOjkq1bZ5dYjo3sEyYFU2CJ8WmPvRh/vu7H37+/D8//dCAwQ/r0cLCzozSELy5REOae4iHQJ2wSCKP58Ck7bvienG3RnqIHiucHXb5215hYxCTaJR69fno0DmOzsu5F+bExgvXIQLFnlcT7ecWAOuhikFARAcCJqyXVuF/s4ADZTIBLoQEws4GZ8JMp++XwtWxI5KO9OMcmUtxOFp9EM5SxtEtcRb+zkRJUjpcqhQlNWdpEiNPBNEGrVdYcnfrRJXjt4SNgXHBbjeubMk9E/tBHFmrGkBLvS+OHpwKJ4BsOGDYEVmPQyXZX+xGvwxuKUvUCHe0+e3sVemM4i0mrCJLbxusoDO9HdgzzRJ4GDvM8+Bd7T09FqNaazqzlKPYJcVMZspxIAdp+ZEvgcNt2BiU+gTNWyaZTSYqoE+iZXSECGTCMk/NozDh4L7HkV1nNcoS8OdxaqRdn65JovZ3Pf46fFEGL3j+PpeK1yCR7SS6Uc5MBG+wVWp4AScyFaAR+84S81GiyZceSabHabcHDPLYN+FgCf5YB3IL0AtHgBDeWZ5IHH3DiGcksE+eixFeYtBcu0mQxCe8yqWNF07/nY6wbzhYX07Xy8auU1N4YkhOmpWSE/oO7qeTtomP7gIL92ztHWUEGlOcBVantWAC59zwsvhylpllkpNds7YlYi0fLQrczvo+qAMiZb10ViXPn4zQD6jTjk2SJ1uT9hUvingAezjwPucbZ6G/8BytrCid0IxlYl3SSXLXFIh0+J4MGuBaNUUWZAAEaSKgBDo8nKB1eFOc7Ztk4huX6h0ncGUst1P6ZdgBlNn48evv7d+kI5NAHjgduBo+6K/SkEFBTecCthH3jrO8fe4ZUmoeKMCB3DvZX3LwwXNwI++bmF6FfF0vFokfhQ+Rlsd07+dA8IbTLrSSSaCrJSZ3KbkZFrZm/fswMuNc8FpnqpMir+wvm/U82GvcgCoNj6dFa670iJiuMrPWLqlWxj7hDWhlvxKDObxHyxIIHJJwYx0OhkeDlwN1PGbFnChRrIfQmZjbXjKRCen+cSYdx21BAeHuIjDjpj2cH6JzcemxR7j3OM/r+fHW0OcnnzSLBHb9VQ7dHm5A+1XipCcXnFzYWB/bc5efzbyOAXYXgQdipPVX2dEuzMRwnaE49EfpmKc4Mns3Gf5tLJxVFQKezLKvtmOmDqVgCfXE845Rl3eBvc6KJVQ8/H/6Og+NFMdSMNzgGvrk84hADxefpCg94hcHJXLoc+cCODxrBdsWWttuwwgQrAgLLv3Eze5Kri/h1WNPgxzabK4WiNHviBpoKvJ04b+wFbP1/SSmMNKkujiNSowwd8Q0tQK5pGkSy2h8ijK+mTnO+lCo2b4pVXfqRbrEGgqb4waRJ/3NgpiHyi+dthDRpJCxFW8TmqGFn4qdxoEcofANskA8ofDKEztrMpU5DtqcYMjCJGGfEwlKx2SA+g/fD8sQTDjZznjX2RNILGg3kJH5SRbe4RDIyLS3qp0xYBaqIOjNN6qdY8UJj4zMh2b9Vfye62xZYtjYzrRMn7oFMh3AiU/1GzKVXI8tjSPtJ2EULIdhCq/PNKe/zLa50Avn5XRvmWWGxmnZ5yo+h0DdXeOEYVAWWSrRqP90OcIKZgtDudGIM5cy/Vl4RCKrWXo5fzpLfEd0HSpJ75tUUfAJ4duyiomnYy1mloxPl0uEn/ES9A43dl3SPsIlT7Z0QDwrQ0lH+Z1Lg7VvTxCJ6xgujrmkei7C8Urlkwi/CIoYc6cPGM2CsK0ceIHHgnejUNFE8o66IKUP1+JZN1CYIyFFI9nT5Yn1fpz8nmv9YCHH3ClbU+T7VKe03J7jVzsKjm4khKklsoM7CB1OsBlsibcyIoEm/6GDFGEpHdwP4JJGPNns5pB69iwkRpEDFS0OJMJwBvLpo1eM994H1+IyKT2xxbHDFZgjJwCHWhk3AHctxQfNAJNM8ImwZUHPpVUz4KgS28E3SgzVkv5oYNTXSXIIQGKOwa2o4EjL6NK3wLyNFMeiGo4bc5kkfOx5fmJIpccPfulI2Jyvx5ZBeJ9jvYhnIbWzYcOyVN/gurF5pI7hguGD9TKJiGayNRRmhBCc4Ly04IbVH9IijQpdPpa+CcScjLJDcwAfW8+4vXgo3OOW7Hp007NgCwu9HWa87YPDw9sMJQF3hwwGdfwqE7MRx8SOU98qw6SIzL3tlLla3F3J+drWGfN4UChZ/CRsI1v34sNB4Q1gM0N3oLL+Li/M0thFtyqwg8KIEmR6PrLDAI/wAe6eFKgkOrMTEwjLyVlx2Y1UnzDgkv39Q4PKdKXnkR/jC8jzVZY2UALXHG2R8safab9wx3MYbKS4i1am/ZC6D6Fpg2KJb+S0Her0PhDIUTlEcLzXC18Lsf9AyUtbOCHD4QFKdPhwhsW2UTWNDfYZ29FtPeHVsb8gjI07yKHDNSfyCn6na7458zZQICUMHIcVWIj5CBFiZLZpy8JDm2dS6uSUZ3s7nzgNv/VdUeosDW94iBme5Aa+FfwhxAo3Ez/Rmfycw91PYcIszp80IXjW7h3JdUv7hxlJodpWJDCgj1H/aMXICzH70qViGZiJmT3wnu0p5x12hkQB5DjoCR8hqYRxI+PdQPATg8vjnOw+JXe6k8Rf+EAcQ8//VtwaVoKZpmyZDi8/6aa/dhQlufucaysZXHKF+DF6oA1rcbRWdYG+Hm0f1yIuN3QoDV8bHrYCBQiZu5MpDVuRHgBeQ11l/o2VuCQwrXRTLef4jIJcEA6woL/KuRVVRzQiZHSF6cvB24YLyUKL9h6e6QsnhViytAncMUmYYdnrncPkQXDsWcW1XUsyx+sF4nB61wXngt8TQmq8oOsccPjBe9SGgEP3hE2x0KGxTysttxcvSXhm82uPSkm1ALv0xk//7e8//fJ+scjqfIfHJdo2eOt0CUacB2PPBipoddsLRafvifAVenX0JsvDwZ5CdReo3raX7LBlwozDedM8lpung/LKBXvdLU/DBFf2nJvhFHsiG/MYb3SS2MGGsHPThjo6GwhyYM4uDufTC6oW3oE9z/Yadr5b2N9Rm2LgRSgUTqvw3tmGSk1sAzXhpKudK3GSpR9pdXPnAC/Y/AFFEP7POFugT+2IZO2rKvtb86HIxDXcCsZvuNp5VCjK6XKsoeGbtJxCE0H6WI0iClR3ZP5K8YsfrIawZThRlmS0haBz7SGXkiTpgXpwf9rBzwUfRrgzd29XhkMvyIK89q0fC5QEgmWwlzuCh3CCvZv8BjhoVWhAWkHk7GwgmiF6b1SJXhArKDOK5DkLldVsjDndNDuj5QZ4YSYlOwqvp/1vMFN31gpisEuLw2C0e1jMEGuVe886MW9w6jRk9aMVDAeZ9CBpOBpHEiDklGkzMxqsuEVujbhgjqCaiJZNGrsdL1c4uRX71nNC5LXGvuGGTvRQZB1kpRv5YEEGR6PzIEvIW8Ys4R63CESe2c+ehH9jiSIdKtL/e1KQh9USISQip07MTbr6q0xKusk8Q8QLD9KYP0HcL6u5ow5w7FDDRJCtKY5yIMMu1gsXoyFea+i++nnNhsuRZECrDWwbiYSpuB7GSlaVmbNBgREOn2xNyjP8L0Tm+umKODaNhyVrfnAm2ca1tt5LOxALHMk2UljCytkZR3jcws+yfyaD8CCO8YdwyutdWg408r2x7TPEFX58YHqEiC8oiwJxuSz+Y61RToZeIC0lk3ZnHTyGTgtTQ2HwIsB9ZnWKAhtOa9t4aJa6gE23a5EqhdvTh5S+kIeU0G0YiNHvwgwMpyKZb4g9BLi6IrZf2DVS2JYb0mRHJVsEMQtkWZrn4t2uEbvu4CjkQV/CeYw4Jp45jF6IcSWRihSavk9f3x4MrkSejDmRnQgFpkCgqDozSlfIJ7E8FmFmfs4z42YF8cPscqfImEUDpHRLR+9GGqdJ7+oktIJmC+wYaVzEiVMdoPs/djAri0MEq+bU6xlt5Bkiqs42jq0jySLZeXu+6ljTkc5Z2Rkacgoiw5+ytilFhuczqXXWe4zlBHdfenv8TTp/SDPZ9SYLCWSXmD1kxwesFhIk4SUQ+DRULzm/lY9D+M7qnb42uUDTYWzLhXBu8jzUsA54bSj3ZcNvgjfklV3Y53fCJLW0Zav3cEnJlEQ6Edq+/oqJOb4FbHr2jqzh5TmnvQ1kgJ7tFbJmWDMca7gr37D/WE/bNItgejKpDFsf6i2SYcu+4f85XCqwwjRJWcgGx8l6M3nZonkCAzrYyf8RVB3XNyvWQpQuo3n2inQCHVG68Aq0s+pIKFamqjvTm+2EAmJ5tHCTPtsSEpubW5/uo7lO4k6SUp6IHsSeaq69IJwdGxZsRIji9VcjbF2YLFwIHNlZlyargkyQ4pPF89whe+b4mLMQLUzWfqHUrsI8kUk5afpUhhPZZenB0Xz1TYY8VLa4xjEe+caeFEMXZVThDk58puKDAz6ALTch2e4QLfFKYeAiaYhHr8Dxec/kqzBKQs8zapiv9+NZBSCP2Ge+5kk6uJJEnAisiUyEw0SFsKQ+vVT0F3KovQCwEhOXBa5hG3KZyQWCCGVm7uEzIeKFfAbO9/S5LOHT6mzR4FR2n8xE3A2u5J01ddeLDgfmLJGBNWq8SJAcG4kh3SggX7jkbK9SgqP9C5JmcWJKG00Ns8gMUkrnyGfRSmbtjkDlrRzPrjM7wueJeGEKOpFyI87mHaI3cyEj6sr79v64Ma3FYbO9eizmrcJ/oO5pLISEyqlJOQuDOL8BH8Jh7dPq2YhdWdrxfiTpScBiHvqOTwRL7jIoIjNahNscScICchqjBhBVigtSh9rdC5ZLkTF+FPtFZxHoPDrOq5Sj4Tq5Nqn8zEWvHLJHupFxCogiIz3/JEuiegoEr5tHfp5vlW8g4mZlr+IgKpZi6gzMb+xT5L0OZE3Oxw4Ri+zUiRMj+ELoujDoQjv0MWB0RccQ8Hlcjl6eUNZC5FdLDL9Aadcl6S3YPnqn7LhYGmK//eU9fXe8f0PkEG0VY9S5lVVwZsw7THLXP7a+Jc9TbvmqxFom9G1UtkNE70F4+Cee8PSQMhPoVfuT7ceQmboTpGS6eSwicdBHYxF4xBSQuM1KI7xnJvsB7tNmJQWiOVg96XAflroIYxm4bk5358hV7ZKB2cG6wgvd/nQsT8/ZB3i2DAMuUcRLlV4dBPM+jUiFHQmdh+00uVUlzb92slkSJSK0M7kDFqtkGzjgeJn0eLi9WI+ZoTTK38yGcGzkpLiQt2VBhanPQepzvmAiMq6z50kjZ8Q+KgoOy9GPWAainL4uuYMmhZwoYypdGHrTewBubNxlcOuxf63rbX9T/f1ND1aJEvhrdlJ6twm/DLaXqvf2R7DdY95PO+JBAK61P1SjknW4wl3fncvAEi8z0Quc2eUIqp/eXZBhpLD6egSPXrGTkY9EJ6MDBKszTc7pzoJd8XGcmHy4FMnnIaXW6JgYZpILpPe+JnHisLSWg07ekXRJBAv67voSGURyEpzQDumG0jHfiOMVx4juL9FCQrfBIJRF7dGCdnOse/QWSLfPBHIiFKxkme7fjdUxshGFEfNneNrmvgjC5+O1eNrZQjSsgDySK7M8hlsOvwXmZHBCnb6gjOOexLL04OhzkfO98w8lQ0LUBa93thoOA7TV6OqWDDZ7aUOdM5MDyy7hLTL0UJosy5bR7WRbaANxTIbBwoIpS1Tkbu9ZtEetzCqVJXuiY4uXf9DKpAUsQYgV2cuaw/xdBtGx4yMsxZ7YIm6S6YgHqqriJ5nP+0N0ZrnYicCmsNKqI9T6ydMdmFcTASyHlM8e0dPMa2VJJnC05Zjo/kLDMjFo7I5jJglP27rh9hcR58hSm5bu5TGcwpkPi4L2JMHW9PD+iJLRO+U4Y53bi1BEGGVdYPv5A5He0QMxJVUmoIucK56oPhO6rw3hEz9hwyNJze6ZPNlI+izvKPVFQ8i3AlpJU4DXZqFc4ke/hroPK7mlr6myroKXLexy7tk6ATWOkeAnTjt2ofI98gx8I9v7GFyMpnUZQ8+cqiNGhK790VM5NhLE3qJIDhiC09kExOnBvpGxLbb25DRxraVRrwjPU4RiyRy/wGSckOiWb2vIrgTUEvWRRpWMPBm4+o5qoTM/k1gxEo7QCczs/i2x1ELcT18a4rNMu/WXJNtpkGkmZel2fr/zRthGEWilPtudWrSyOGbLnCoAb+CBLvFEjcoc+I7OkBybYP3iUpqVkiXUe3noOX/3ZKX1SdfB5ylbQwJCnIjaMaGOdH/2sQj47sRjoZWiiqFHvQtVHoTWnUkx9vwh98AVtXso3HfOSupISnLOE95RZpKdNFlQ8fzH7Fe6rjciLGwUJPNRb0RIohwqNWHyMnKW6BHLFMWkzT07XWR4zPCMNL0mQxTZAj3TqeQedzwokz3t6NHIfeIHIBqn/M60VKpaOJKKKeG/zI1M9obDR5NZT5N3hXE0lALHDaZe4705ydh7vL5ZAOe///2nv/39cbHCuIAQ59jBvQhtEBZwvMxgmeSkQrqGPswR0AfntQiPbCFrT8sXsUTC+T7WjcHuQdqT3GDr3OQLTgwcSeDIjjDI3plKo1OMJ1W6fOLbi3s7xeL94Su0jUvj7E1mTBflL6JY2GgH5csRNyTo2utuLoW7ZSdZiYS8TPRW7R2AiAtdoAUOdiJjruh08ojoEdIj4GGT7TRXrBki6h2s9id6BMtxuKjaTtbYyYPhZvcEbj+zFvZxlsj765/hTVpn/EQZvZC2IuT5FCSIZOPEass3545hCq3Y7JBEzEDsK65+HCxafMGkHbV/yBdiZ4Jnv8TMXgvj6VpnINEgC9OcCL8mhHcvncgROglHhf6drVKWRHdCC+Okou/fIPS3Lw6nOoaB7At0PmSyyAxn4ANmtkvZjxv4ihDHDk4rHjwyT7CTf5IW0UlDUOHirObtrwNXWusTQnhNltU5olSwwTxn2f3xrE1hrcOlmatrNL15EZBlWZxOmB264fBJzWPgRVZGnCOZudQxXYHxRuGA4xXcd3DZElMhVk0oTZoUshn/2IaMp/cJqz7b4w6eLbHH1EwmEMlxGvIu43q1AKxICZTYXhnmBstxtFIuRJaNaqCQd5Che7DNSB6KncaxtRF80KdceL8sX6pN9JRDzBCRNqMzqAlgVZoKV5r13bPRqEKOg5eOBH+WKHAzIV444Vge0u7sb/X00XBal1lM8q4sK9auV+QvEZuqQ7r3mjiRm3VJRBHSwA5Ux4G9M1L0hJoN2jd3vml6qKjsyL/Air+fpHPQdthHguw6KtUdXHxysdSlUfImlWKSsVZqBFhExJzCbLwg6sPhYpYme5RaHF18Ivs4vlAYCTyLOeywflAiO1FC+eGs5t52RYQ2e1KJ2hh4CMl1MJ2wjJPcrRWZlukEN9Q8bYbxwyQb37phcL97oe4xpuYQKYLk4CPQgXiIqS3TKmy7TZyCF72bvxro18INkyp5ln4RGxRJHAT6TuQJZz9O7/29mmcPExtGfG7gbNo2BA6EjwyjDRHJsHDOD+pwugMJseZJ8oSefRfcCWc1m1GihG9k2MYSwgpqOziHbKpzdqn2ssfLkUumds0iQSyEwykljQ1vLyTmfVdMNqTE2SBFGYDEfg+I78Hb0bkeWLMXUooxCuv4MSGCS/flvJQ/ZLmDOAJJiFUFsSMkIDHLHD4C3iL8mRVUcmweCYzKSw1NWHdJ/tt9DPHxEsnOIm2TmwJ9r1l48TnOcPD+UOexZUTxX5Lk8hzpmPqYiHwkAngmdnZWyYghNkMyHpzzsKXHiYyLHa1/ejgQLLF/aHoBLDex76JPMReqM7ICcHDnoLY7XZBMj7rhSZQL1ZfpHc/YVlYnJ97dncmAUxEQALe5DVU8PVLGD3IQUwkmIUg7wXa0hOjRxrFhZpAf4DFYbWUOEAqhYeWzkPOzhabz/53bxEB4B+4TFLGUN0kuJNBzOOvCaig4FwFN19GeePRouNj05wb9krB24qlM6IAYaeIkl03HCp37JJ79NX4OfmLZYI7zFmaMhylQx7vv4QbT6it5Pm4AmcTwEIMmjhAZJkBKXNrXj5YjM2XUgi2xeZlhpk4eSSQZYbdKH1x/vpxhZXmAYNhjgACdlcw5vjtJ+VCHnex1t+fMh6gdqDcZH0InIowBczRjnlTFeS3yvxelFyx3niZKWHeFtRNKP3fuCRzdOwephaU1/OgdA5F0bpakyZNrGXUjbhWIGEv9OLY99Pfn4vS01D2YZg4NZoXdI4Pg3t+g/UnptmTCj17Te4LlBtsgef0jfcPRsQRtGdkFR9BfkRxKPlrJsSiA32/bKp2WLI8hOm3laLrBeOzCinhPe+y1LLv6SX/RBjElxqleaZCw62zZWwZIne0UQTIsmfbkKUcvsr+fA6lawJ9Yll8n9/0RK+Vl9HyZ7V4k+zKPvRoC6fbE6o72zANryq6zohl5GR0ayDU5/C02Lz4OXnwvBSf0NrZN0aOLQAoVT9w11H9DXolAod/I99mAouVorZxJ3DyyUYwrSfVl06QZuwkdEDkUSS9MhXK4lDVu0l1FSdnAbSWj6lC7cBE5t3KwEvVGku1GcTQnDkPrQcoCM65OpQDtw+50hq3+I6QCVyPgKo4eCgYLbCLk6LQ2co7nj6aafaON5fDoJQmDXfS1p8PpOeu+91olSa/W2UV/7Fo5NqmFhf5XKuQkXza0fVXy0bQPbCcYw0Dd0XOFpUHHSicnq03zTtH1INthcHHdeS1y4brAmnIGCbmGH4tcsOmWVLhRUhAx6I/icoZByh/IFJyETLamTkYptLqcxDzBzkfPz+a/2BphJXUaafjKhKORKpj4rsC+D614v7cPEob7yXtPiOmd8/x80YBM7CALQR/yBBS2YzLOmQPKsL59nKAgLNN2RdPt3xFLsQqTBqSP2wU9lRS37mTaJjS89lQcLoV36cQyrT8vuGV+jHhMDDthGsbAlYNTyBwF/e8w+TlwGDjju9oOfW2szfQvR3Pd0UMlytwOJriWycxsGcpCUOEalyjraGv2e7fSSlAnszge6e8Eo49XY4QoKeKjdeCWlfE1EmyzqzRClDPKi2y5Wki6/ohlYLPPwkVXGJlRh+SZIpYxPg/MhPtDi5WU3UkAH8TNYjPLLF3SDyGifzY8H59ZVvyiMtDhMuGmkl5FYoUmUsE1TXqeI/NARQYlFScHhSNzEPkREWD3SbPCk8W5pANHdbiU6rp2ZKH9yCQ0Zt7cHFuXHeRZysJavDmzMqgoaWR+48gsxEDWKgORJcEHp8XjDLdxXm9YGqLEDlCOhS0KjywN0JQkB4VOJPDUzZ9lEU3bR6CdOXMmDtI3HoFKJq24FG+PdoNgf5vjoOJmvskF5onwxBISw6mg8rGptSh2jf3+7Bg6xBzIOKYb8C/kFZuc8UI78jFsk2zNNB+DXUC4L7l/ymwfW4OiyR8ComQxljRrdxYbzgS2oY8ZaUAT1g/nUJHywcPZtSTE0Rv0EBOCyw6PJEoXVqTygDZFsfc9WbNZyzMyX4A23Y+BCgIyIbIqPRzFgxCOrWV+tukRZsAO+RVMTa4absMcQFaOnoyMB7OnSHg+ccugnWzPaN28SbD1c2DSYZxEu40T0EmufCu54rjZuV1ClcYC4xi27Q8Pq4F6Cprcs5JhsGRTkAl0bVIep76UAQE/3q5chTFGf1bIwipswpiyWBpZZVhaos6XK8t4auLIiI1NE6nMVB7ZnZV7rL3oe8VC7s5I2xXHzSGHNeJUxHNjoAh8WObOmSawUdFk73aNazGTMFL2bY5CgidkYNTEvCHklfGHytRw+Fg8AD2ubPD6O43oaIcRVcQau9KOHUBG2lI4f6k3QxNGKRBPR35kT/SHHLFlDl97wXcnjEvh7voyOMLE3YcsLGdAtYYQDq4n2/sYc7Kv6WMlrLFO6MmcLsrRcwPWy/qyl+nfbdJKOVoIumXha7pxQF54pCci6AMnAZGaaRnU9AaE63m9YK9pPd2jJ0w+ZzgSOOlsjfJef5YsiLlXEOTYQMUtZMgI1oMMwCPFjbh6R+LxK3lhbnn0uLTfSadmfDv/YXtoYICMUm8zbi3sLC9hjuxytJIzj3+4EBSuq5MV9CakdMzQ4zFNEvQhHwp/Mw+nb78WwQ86AdQhfiKVCPv0fJZLQUeSrrU9vxScs8amRwG1CPU+zp9tZYW4cCL7N6Nx3x9kmf4GRTEI3AkpZ3v2Kj5h9yGt8QDG7+XHpeDAFzcG87xIzuQB6nSLRej5y6Se+QNOJ+v5mSTWsbM78GlpBRQfABXlpMNNAaOHW5jJ86s0TAKygHZKvMdOyFJzFP44ZUc8evFEuA2OUpvR/SITj2we9MDCjED4cwk6leLQ2mfBbMAvH5SAMh30DUVobozJylCw1wlMdj1gFshBxPRzsZ1GwjFuLUwEdwqlw+1iKUZTKiyIwK3HffZtrCXHUiYZUtbP7pF1JiEpPaGxWKZGJyXG0q3MfGjSkWTH95O+3TpOtM0nXurmVuIlcnDUmRM7kiKlr9kZSfCZumbFpdHmoep2+Fgs4o4MDjtmhc6g0MGVeRYCWIBRLa5XeMLRQ60PLphNgjIyQpzgWiWQLGCFFE/jtB28H9PfNurkCuoM7QeW40FCO6NtdfXg7bLMLnVUza30SJwlmTCqViiEFRpeH6sMrZn26KkYyacwp0m/WBZdEu/0gJjj3EYONiuuLmttHywQVJfzGAhLFkLii4gpksnokTYlannipEDEKVJQ/HnWkm4yvTzZhUJEEN/4pYljqUdvaczE5DeSIobGbIscmp5XOjL0eGDcfr8UWwLD5D6WyMJHkthPeIRM6GFRbE62OdY1kZo92wkA7tVg8oxORvJbipFTEB5B54frBbqQffxXvsko7IXoQMDZwpShdH5/xASwn8xPbI74qJVqQ8fscKoNXI04B46ciJjsiV7R1cJQwHHsOtGMlIeJ7dwUXV6IQd5LJtIMsFVvTI9jr3imTZwsJvCC7nNI/K697vzVoyB2Z3GW0+rpzhgyB1BxwhMmI4oRBy4elhgzyXYXzmKOs+aUu4BD2ltXJJFrH0cobS5cZFOaWwLTF7hCxD8nkifLsDPfCER6FvzYEeGsCUhBMRpWCD8M4+2m3j0zu55mwcdlVOX71+OIRiY8Oy05DjDCEexJJaLKcVqvFC1gvJjC0lEFmxcMpAtndagPOOOE6SVG4gkklzG0OM5Mw1EfPRPPbbFzUBeLDayszDFFpGcmyngZdn58z4g4hUrr/AtGBu+QLWa2bxMdK+xJszGrHr4iU7I6NUDQXBar2tFg4KibLC0DzLvOg9u9ZF6xdI5OAlMcg1BBkj1ZyDE8HNXGOXS0FC1cHTObZBQT/OJKG9GqzzfPqqObmYejgyUrzcZoZoQI2yAtVLBtjgK5USo74RvM8aiCxR45go91qnqQ/kI/54fgzJJQYAGbHb0ch20z5dW5gNmoyOqDmx47ASHkZoKVaZMGjlaChs/wikf5V3g3CeItk4fAEdYxfurwKgeZNq8XkM4vi52KvxLq8Tgrf/14/v3Lb793vfVGkc2F2Vits/ictO6zHDDg3RKKWW3EfYzfZen5wA/rErnhJkafk3kqjzG5WVs0Q9/osenlaBsNabknFbNMb8P/IxIxNEhBJLI5vOFB+vjt2UuEbY2ptV7UBsCOZRZRSqMAp6e0UmS8Mwr6U7pyWOCzpJuoMhq79vlrmRyL9D8n98HBIfJ3BiYc2NNh0nx7o33L0hMHLfVw0b7l1TkaMpJJvc9JYh4DR9U2d8njzf19qXN/84tn8oBNePaNFA9kFKhzWEVg9QWHqab2sX0hXoKo2aovYGwm/Xn9cEKlsRsWmxGxOzTY62Lsa6zFznGCiXwjYYl92X8XBkH3GTIGi/llKpFtOSBaC22mx70WNg07q84HN5sjECx5Nn2vGJA5gUGz0r65KDcglwea0Pe6lFNBM2vYA+YkiT628fXXamUur6mJg0K+GBRP/viOLiEkk9mfBbpgpQJMFLHpcN6j0EaCsrgY/NbDaanNBp1aJFZp4gb/WLWLM/84Q2X2IN8I4qbjEPvAmCTtQCv/2dGzOiZqUh4ttpaNgqQh8CTqaK3yHJUjGHuYbqbC9i03mZSq9QGNJc2hxnZgHilVSeaBM/gw+eu9WB0B1qUMwkm2W5FXHgerVftx1jjZtTCaW6nINofN3TmiJ495uUlwRVFGYI2B3AxiLVEJaTKpHS8WSOY0WT5o79LcKenbIeMk3N68mrePdQhXhiuZ5lFLxJ4UspCP3mehV4DdGpwa7ltXfsg1WHH0HIdkxF6m4rnmCCxopnRK44W1mCgb3m5Luji2yrHk4qW5AlcXv01abKFjP8lJMFdWSo+EOcCDDZMLujpKLoiZrxAHs/m32GEOOyJyakC7hFCKpKBGyUGkbTzVj6pwWSpifhIGWWGAipqAES3aGkeUuvFEjUKnME2Bs9OYuQ0hLHW8nsTKiS2Ckx36pKrH7nXo0apNxncGtYVzbqS3megX8rYXZSM+EAXbLIxbJryygywyZxVHTkxUzsSRdW3yXgcIDAghzGRKkkkWxD4jaumoDdbhk9cO230tlRNlaehS6RecRTNWV9kaltpU8+jJRIHwZK2ZHW79A77Qsp09MyUQ+4iB0q4B+zBGgn9/C7iSmcPdrQBFAlmS/EBfInJqQ+CSXalQPvRQCJXMmpUV3GgMdtKe8U4EaadMrjODnMjU09mZxGotkUVbaQdDbhAnkpGoHZXJs9NGqszeksd4jsU9v8wrlkQPk5YaxLrT5fBF3O0O36J3QiLfiTriKBoSjyV32vj0Tt8RvkFXK7bQkAeXvfiIXDq9syeHe/IP/VTb/SMbioUU2pQCRjKwOgTJcnQfVYs0PZKgMRExctigzKVocXSoIzOWFM6g2kvSg/LA/Xzg8LAmxlEpZSSDskyMJQ1zb/OSmg3xdfaDrCkZYy0z2qOnHEaWJSrL/E0jwHfCm8JJv3aZyPyRAiaxDgcUhkFJL2Qz2DAdSRdICE5nr1NSHvjDTBs+ZHF9bFEhJ3aQ6kGo0uY0uR0l85kXRf7UpYeUE+SkEZPOnQQBLO7iadgblNfpeTu5ME4u5ChssSlhmqzrWi2byIhA3MDi/1BcJax9WQkxeOoICqvKXxETS+PYyHYM+y6MhdjEbUhfCQ8eMqlvtQ8pjNkrx9iAFXc/f9ixyy1M740sP5yD4ZYxFVHQtm8oYT/WdKR1JR3T5LxlwZrhgM5bgvsY7w9pn2NtYu4P7WEy31Vmg2F/JtUzt59js9d2h+29wNENblLJs5pAOpuMpxDgQSSQsngdFHHgWgtJAN7QlDGCmZ1sBhFnHNwesoGcW5g+4JrlWsQYzn5/QTpCW5LOcLSjkSWAzfccQymcZ48oK3ZKkDSO4S5O1APKChaFs+9kRGIdJyAx/fcQx5Lqg3zOk/UaRpNYOF53W3rx92gzyCagzvNNOLUJyhnhG6635zyys7Qs+YRIE1ZMGuS/BAcRRehKm78rLLkE306erb2guVRcYDkydYoov2AW+lEcGzLhQj9M7+hwOb8m7+l3kknYEOua2pwUnCXWTomQ6R3f7ngx+G2INWPvmua0Uqp0aLnOXuQ450UrVUd9o4keK4GG1tgG2Azs82T7whyG6Nmmza65tUSxfSpIW5PyToIptnAp8zh8AM6OSG9Izj5SCC3CW4dZkYCY5BmLJFLh0LIOyTtMCiROGYTyxkXvmWdeuxoemg6k/u0XXmx3dvWM1TxKbjUuyU95ojpKoy/miDW4tG50HH/baxfGStpbIg3abCidjUYZJo7HqA7c50lEwNU40M2kwSLBjBIZ+rSTEsHMPa0t4fs9lJElgQCV3qcS70IuaAiBNLAJXqqza4f70TUrd8pV6hwt//si3G5KaAQTIwOA2gjbw6xKotsWY9VjG2QCGvE/ts8AFUYAnGzCm1rccPBQwjZL+rrSGkUdg2JH5Yp9p8H2slTydUyRPyr5C3ydI8ZmkaFQV+c0u0whU469XUqYxyuRb2twMrHfVAwzvBSCcjiTS8A9cAasTqs+XswY7Zx0zCUGdoRA4zX/XKp/j4wgH57XLLQzC6xHKHSJ3x2j68WUJyZAlML00Q4ldgixzTzS4XcPdsgTOu+JvMArh1yWn13LrOTY4mWTRgiKnuP8OKZKEa3lm18IG8D8v4C7hYeTgx7I4zRYJqgq7OzL8ScngdllhYWTwZ3ZjDxHtUjwEd0I3Y6MHEEIUKCm9BrYja1BwwEVPDqxsXNi+f66MO7GmVRmD+oxTvv2rvGyesZG+AxNb2j9Mls3XFZa6tdsomfI6MiNkjqhRqTKqK5HS39g+x1HMMY+MCdJviDRkiQz2rDIWcH2k8JeQAmXHkGCsIicI+EIY4W38gASJBYo4EpXjumBRlt+FyItrYlK0FacNAgPAsd25pJZdcB/zZ04+WibiTZWXJt0GhLLPtBCBORxSGHP4J9oEgHIcSZGbBAc5qA5exqOfu2dtUJHxunBdgI094+V4As+APpfGkm70pRUZqUj7Xlg763AbvbyZ31ysF86dmt5TldnFwPe/Ob5wnjFCSY5ONRJJpqOFnhhKrhz5p7vfNOSS2OHM/bpcSLHh6eI/eWMWvvqxCBJIRI+sA2N8Aveg8dxgLG2a3li95i8dpPsiGk1RBBBzCG+C+0Fy8deg4VO/1igHDtPAETvKhPy76zDGq10wSTOAzdnEAJZyZbpZbPjjlhUCDPO1kOmhjgMDs9VtTqxfywoszkSVNA/sRryiXb1ycdycGTclNYjVXyQ802mUvIJhXJbkwIx8cYRksspd05/dCXII8bDe20akrZmqHBy6pap7L4h3cCFDTPlfQ5Sd0qJzuKs7mYzYPxI/xYbRu2PHCxDJIXOeKF5YB8fWfJ9h3snjv2J4eH4f7x0vOcH/CWzJI+GnYE+ye8SFVzxRwy1XAl+IrYMoZSwsFlhbXFK6NDHnSPohJrt7vTxWswa9t41RGmwYBw9kOHN9LIOwytDIa8NAbuloDbhOU9ewCTzqZQ6KUid3bGxp+zIh44EHoX4K46hMOznwH9cOOJvnhWraji+rvGIH1wE5jMcop4xi4OVLjo3zDKz8zZjbcekKfTU0vfz2z9++uXL9z//+q/HtQLj81keujGU5Sz52esIT56hJM5p7fWTbz0ppAMOeY5cJ6ip8Azm1LFdxBrw3jC50aOevSon+yshsRMT9tIoqMh+mjjMm62QzP6XyWPdn3OzfWLolnoYlRLzw0Z726Iw+OHB4xI891deF8LvUyn0XD+DP85PJ5BxzESo7INY5i0/7B19GEvclzCe4+NvtpJkqST6tkbUaPHzh6En6miabaN+EfDQWetpoyCYDZgj88jK/P68syDuFoJVjtgmo6yZqp2tFJw2Nb1Ud7hSTHFJ8r5wNA7HjowJK8LIDBtnk33kGN4v5tkiM5lAoMKYdWV5OvXWyMjKB5kXzXsxnZxM6QPpfQeiwxj6FD5idzKg0zn3gQMXYfaCPWx9TWQCnqihBlAnc8DC4d7mqzG1XB4wL9vbGN7oFd4ZyF86wWMbj4WDXj3JnFOtKyP+e5dA2kZd1MPIbnpOYdWOcZLccH4b56eM1qy9PHxLxGU31KAgDRznK47aCgkhC0d2kI3dmeOpL1gsV14JOygDyMOSZicpUTgcMpPLnM7ztvMS+1DZySMK5TEnaBFckxiOREWMGOZvsmGHDMVlFJbY18PyqlESC5hO2Atof3+aFeS4WPi6C3eYjBCPHIbcXcBGq8mQbA7i2YsJa0kHwLBUrGJWaYOe/CRZ4KDwdTuLfD18KmxmyZ1szXJbZzN1r9OSbOCRsu2dWhOmXdZ4GvpYGCoJT7Uy07NPJmAt1LCwxNFxzDzsFTebQfLKi31jXUupDjr2M3M4AZzc0PhRj16PBJw4aX4Ms3Myd5bUF2NEF2wocXH2nIpZUAqBlmTSHkcOfywPYwKJC8JdrikvuYbdYznuE1wrSdAXGZ1FgU5C21vhWCnL4SNttPXhQpxipcS7xA5GM8rujSkvEj/itWh7tO2cMZOWGfSEIUKfW52rFDlHhlMmu8U8XorjUhd+D+Ke6Bp01gaWJtk6bXRGzYGy5JA5mKkwaauJxoKGnQMIeBZImebwpNO9OdosDqYz5CeRRpCCJ3A6nVs42fFpDkIdw8OPH4t4WNtJccj1IpoNsaLpXR4So5iFHugwRiGdDiEbYcywb50FS4mN78jzhzhEYcxH72gswcJpjJV5ESwcGRFGs0ESleXZIxrOeMQSYwue7J7x82IMcNyCTpKsgiTgoDB3OluCayXCiue4BAqNAEq38H/CmYePwgYUKRv5N8k0w95QcmIEphgfk2n4I2N7Ug0jjInzVzkyilm4Yf6ZTiMLGGnsewzB4hvTyF1FHDhujigH66aTm2QGL6fKayMRB2YUZpynn3C0GZ4k53MeGtuwSEGX1NxDuRAoZd/MlXv/VGxK45Bsidws9S69XhIdTrofmfduiV8YZDFHj+XYPgrTP+jFHVxmNhWQyakzq9Czp+WejRvf5j9Z6d/hYZ7pLytsdlihI4DyzRNwUnUAxFHZwwqgaSWhFRXwgFaSCrdh4Zh+MJsIH08TdA62iOBfRwqHh9OEG5el2YOxIMJ0/dlAL2K0t9Kd4aA+hAG96mUllQZHq2oTy36vCZqh9wQfXL7JkJEgNV94fqUsFMhLsZyKcLQZlqigOUmdIwLKpLuw5A3G8+Diyx/d0eNYwqTTJMZiBp1gkqjzvUkaTaQppHSSJLT3mVppnbbYaroArHpEAQmJZgx0xdx5AzrXIrlMcJOt3TBBWuIkKyDBkGRFzHQMj3YJu8pgugNVm16MSjAYBfKKyMfbB9aU7Rs6YgNNx9ilRlVF8us6G7cE3Ab31tql0KNBnBCDOxYYyGEb3gVxVEbCa84kO567/zRx5iSjwL+LJRekE/spqo6Io3InI2XqxLhH/ihDRTa/s3WleX7ww+mPQB03//nWoF24aKME/SZnweZfOlPkKsCzrncIMTxTeGydzYLM0l9lu0GJZfC43DlQgeRNc7Qs7h9B5G7O50xHb0A4S9SmPCFWJjs8Q9GW8YNU2ZbqmNw+sU9RAAyZWQbyPHu6X8TzGz9qMT0kU1r8o4As9gkGEJPU0eHr0ADjduKsjeIdfIv76q67nXaPVGEIDnhWmkPJvnwGYqSRHcTmfC7cyPyAkjt4sEjapzKy/AIXZb4PJl2bhNjHBle0mpHmO9qwQE4PvFjvRRWXn1RgC3mW3FcEBT4Pb3S/GJuAwtq0K+eazKqI50pngeH95Ge8D8vc3O1iji4Qniuw1QF6i370bOSNbQqgY7uK68zLh3tWSEmhfVRkVJCGTHopuUVMiaXnzCLWSm/5VpalTTuaWXnJ3Wb21EE9G9dn6jErR9b8h9HAu1csJCpQJDufQKzSAHRBybIBlxmydfrUeyXLtdxCKxjYJmNJEzt4yuoNWgIXsvjeuW6P3jARDwuFJaV08h8yL8o++aEXpTLLov2YAb4PILgUy5RwAWqDg/KLGa/hONdM2oltFjSMT4P04GinWAXUjtyGVSFUypZJu8M2U456Nc1ROFmLXWJjZpVj3w8hAZ7/Xca5kTiD9GOTZ/eoEz+SRSiyFau5zUxkRyOdMwu9daPt1A6Po8cifm8W3dq1xnHkACoziAxbF0H5oJQeybCzIq04oaLihJIBrNEXN8Ja+No1yMy0dPRQEFBQ8BxcJdpLnKbghqtECmIXR1/jQUTDlagaEA/07jiZJaYT+ZjKjOQCg5HyZ7Ml2GKfODOsEYbJNKzIo5C1JwTHqvB+j8Lx0VFoY3InW38vl7DQb0gv27kUbJHJP7nPJDtKB0glsCpzt5UukMK+hc54VW+ItoXOXUs6u/cj7BwGpd+tlrxjPsZz3nprTKN7QIJaV3utJxw9kyMAzi7gFXo59GqhYpr9IO3EBM6fPZdlZWkh/GB/P+n3iTXjIJMSpZlihvQHp5MEMAwXzagDvpBwhMTIGuywkwJqqLVXHVegoxhzasfUy4wcZ8pCNvloZTBkhCbE8YdE4npCt2vBzJN/NoxyD75o2A4En0xagOHfS5N6fsOp/FaHJk6iI9FZG+VFEkITZSa2belhaFX64RDpw2jizUJeqG1qS/lCeA0EtgwxlbwepJB60/PhQrzosFNtGzgpgTxtZMruafYs0QMJFrszvVfqHILGdMNMxQk1G/QfW4RHOcQW4abloGd7zBjCtVhiLeSjF/0moP0H6oTA+26VfWsfGEQCq2QuQG0TvNj3grtCJ3LQ++Md2SNi60qkv/UW2PLFiGY2gJB5SFxoE0bDbYhv6NQPDlUUrj4c9dEaSkpWeraTck+6oAkPJ/+ml+T8fucj/EjCqCeYtbWnNjh872dg0hVBLdUoo6n8JvdSuDeVcSapXB9zL6zzsIjG4V7YuvmjCK0JbfKOCW7GVzQBkDQkJCD2m+M4NkQusxfgcCvoAUNHt2YEOTpMgeO2IuYJrY9CPP20UP8ddBxzBAbLia5vGfOAHKDCoYhjVJM0H9AujzmJ+31lTQ17MkjyhKKKhXgEH70eTQJzIomx0+H8HYlVrCTBnxPG6DxzpErwDZEpHGLEZeOMDY/xER7kmDDi1CVD6/2Q06CbieNDigBBTDj9WbJ8xTk0m4RhLK82KmBJauFoMKApsfnQb9JyTKYmmV9E1788JlIqcwVQVBxcFPQ3YchpriXxQyoputg1LuSehk2xXjE9B6Jkd30qMHlUGa3LjFRczMiZyR0j0+LMwjJwuBZ8wNzhqJ7eK5G0LAz1onZgH2tiNtGom7HVA6Re8cwGj7mo2ETIC6c1Ku6EZJzkU9w1nDwsRV8cbpwZrRvsWsUDzLkeUjYKHCPWD2ILs97rusC8fIbqGF4hx7Q7u4zwTAIeckZbL+PRUuTqZvZjTr0nXor1cc6caaUxnn3SpAxCv5PFAmOHgUMi6oYM83aOWGM8DpvpZk/b4YEwJMbSFigrf/HwXevIYOJf72z6faj5v7N7rJfqBAnx8ByxmRxPldiBIc4wOQvXyWz79/M88ES5j8Qh4cQ4WMX2gRQyDx7ngrX3ejJOhys5mpFRe6dfTRITEllO+giZN0nypNirE0drUdUvJPCuCqH0HB0QpDKGn5q+xqGxYg2DfBChR8Fk3SKgmAVZmeXQwuS45qUPtp2HahI9QdM7xOokP4EAheYTPlF6pNU/2HWE0nikiQIK7EUzNKhYRtiEkhDDcwgqrFHnmv0GVE7k8GEoOxubwy4oYH63cn6jNHrCsjHAG4y9h45jg7KsHi0bLF0nvO6tro5ZZ9hYIzwe9kH7wsuwLEvQceW47VX7yk2sUvYe3OlkVMDaSi/BAMFTrrN98walcidrx8QKHDw7ZzBwF9YxaTzLLPsOTqJAyLTVHPKRqFg8YyfjgN0ybeyVj1LC4SATfDmANQto8iB1YBmFcQcbZz/r2SbXqIVGuHNEy8ZONXgCdMJa2c4Z2pI4YklvhYhBmTjWAGIcSa/tqbat/Q5Ho08xYe2YutKWNr6JGY7EseNmA63TddjaxM3tga4wNRFSMCYyS+aZKknGGKyDALbvJ+2Lhv5Za3OT0bTw8DjRCIqp6SpPnvnIBpWlyf29CGnNOGMijqQK26iZBFa1Dm0gnmQZxemDvD/XYi8bh9i3kgZZ7gr7s3xtwxURT5ERRynV89GGZSZoJhRYWqENuRVGax/tcDQLmP0goSFtj2OkrtQ1CBSvGro44V8mS9LjwdqsRNWVmfBsZKsvVXh6HJ4rtfo15Mreh7XB5XAtonNKGn3ihm5kWrmyBTAnwRLhuXIp9jeHUHdGUNMSs6eGI/eW2cWcakAvnK5imyjyoI4I3JMwio3/7NBd1BGPk4BfgpyBqZJI7R2l7tiYgjhGx7jVwWEZUiKoMqYpvIH2eLrahPpRyuYR2kMwGXtqOY+PtUX9VXitdbDoV2nCIlUQBNzKIY7pDph/84HtC1VYi+E0jinmHGKKuAEB1yAhd8Kcg1fqs0DC4VLsdMAzlNpSqPRdBf0wyxe34NmpHMc8urRPdnEptu6rByVUcGTHwnXILSJzwpY54cTHL5jYuOhhtaMcMrqNNsJ1MHPsEz7B9hLbB3Ds9WAQQL+yamSZLVxhoRn5tHmAWQxQZPlq0CAdPtZQSVLk5mRv98DFz/AyfpC7Cax6BRI05N5tKpnKgv/JcQxf4uKJ2jX3a7W/QVyL0MzqRuKctSDWHSesWejQ4U4to1WOliokZ6h57SEgAzRPg+8kufSv4QfmxyaC7UuS+cDUycBMHJtl9EG++Da7hQN6A73LuM692y7GHySsqrs/5L2Aj+G1HB+JbOPoDr+OM9+YoCATl0cnJLfaERzOwescWBcEmMzCW3GTuH1vgAIJd/9/ys40V5ZdOa9z8e86G8km2cxBczAEWYYEy5Jg2B6/YwUZJLOKrH0MC8Z7993NymSyieZr5LCXcNN0w5wHmEwltJU06J9RRrU9Ppiku8E4xlaQEXX9h7q+uvlIuMK+ngKkuy8ZCK+GLLdyURyiDdy8SJYAz0R+5cK58hq42+3UO4DWphmI8K9MDfH/gCBwnzn6qTHnTyg91zsClSiXwIXyjyKB6g3gxuV0IZT5q29HCRwNya8rer/qdi4PAgJRNk1dHGS2b3ANczcuUQqkg+jLPFfug+t60MY+7r2oNtGS2wC4bp2lCJLxQd7S3kVC2SIS5cRDdYyx5GaQCyt3D11V8tPLMlpth1kFYHENEd/Tc8lsLBiJxkZAxbwOV+gI6DxOBvIhKGYsebvh8lFVN+RG7t3yxCaAHqe3wnnTKvYda4Y8sN6e7kvHKjcArZPVxMls/9J5rCiBYwmWzL0QGqRNiyS1Is8k1uO6Uev0OBkA+8EAhYYhXg3JAWGE0t2JlNLBm3Osdh3YdJp94N9DE0BD0FLdRGOqBVNKk0m+zf1lHCUf1WClRRXT9IvRp4yUtTs3tfoOI2kPJXHWtqreH7BYSrEPVl2UM48OkIS7Awl8nCygSUY5APDgZLeAPocY2FMLiPcICg4W3t9QTRgaqLisrm4nCYgTgJQcyya+gZ63m472JxCiZEnAw9Dn7AfGDZAJGpidqBK+4zA7FI+20XvkSmfPTWWLpICUQf1o8PFr7ZzW0yPJoSNbLpj6PVi9G9ycc6a+SscgPaOhz12JuajHTNSbhqSjPiEzNXxY0Fak0bjmX5t3C7ASpqZqVJSzR7XIKyms6fk5VDQaN+34aouxqWapRAX4JSZrWeBjd9GuNMCAPw4liVA1CkWmGSJbWLKBqeEawcrU1IPIY/xJu1IOBGPoaRkZSHeSj5Cac4eP2NzLjsXt+yyAH7Wxards0V4reTisjjpkB9PNhMpk2Q/u31B98+RMqS37wt8NFMYEhvlXpU8h/8Ztfh6nkTInxCQCELUCZ8Q7vgHLPZU45DnKL/saHgBcmSH6jABNAF2MlI1vlkqvoPSvdyHF3dRnVvpUmNdQ5VJ0yJCFU1vmK5Hph6xKnfvbEWws0DIzENE/zLC/5AFapVyOHkBcclz0Y+n4lljryJceFvF/6AkhE1f98FhLeoqDOutxwmn6PdF+WXyiscROdVbh5LjI4E1wte97fLsVdahVQeDVUFZ18I1UwQVzxfRQM9k/lTz8NVrBqEk4Cj+4PqJaJDEozvULdOD0EVfuRCOLwDaTf5gbT+jlE1HjDPTcaSQg7fLx5EbVDDKA/q5kv2XcZnLzs9rufv4dJx3NU8+/iLerHg/yD5KVyGUv69mQ+k8dnijq0vPDRLktBFXyBp3fO2cuq1xQmibT+4eCm1dlCw8RLnVGJIMcpc6X3B8/1vA7yqmopvSdmpBD7BQdYJyYJzoz8onqS1jLePhjboNSuIvBev5V5ZVuCB0Saja4KhOf0Y4w7P++00ifl3KCHPPd6ISqpntIXCABjv5o6iLm9TRbaTUAuDXcomvjs7mr6z0I+STeC+t1/4bgZW+EjdRZitQGWk008Z6iwoweJCuuo18OB3yK4qP6FJQG6aaitwQNJPS9wHgKGuhfUkKvjY7VsISqigcTvR0zL9lWqKVOLOFpQSCZhLNFx9Ap0YqYeYbviuyApFtz8zwqh8dSBQCMqlqHBAa4RCxlCg5EhCXkfw3G7v0y75EmcB2SguomATint1skBlFJl9gLioeTL6rxSl4Q1nQI1PDZD3177EtwFBhgstPCevQtnMKMEATp2AeUoWWVl2kIeVrqaMoSe/Y8G2TVVZ9gXFgn1JovIyWengnHouFZmhHYgNqaB/CTaiP4rGkQsB8JzTZ8H60xquYDuCTGIXsn9zO6I27hJB7WOsrkPtxTAhfbZAKJoRuo/yTodK12b5+zFX4095v9YZyGQgH12c3EM2eMjDUkhQ+I3kjhhbqL4WKV/lFBiC9na4XhYiy1U5uSoUDpl46X1koMAlecV64D2mi9YXIbF4H0zx2IWbrEJxJfdz1F+BUB/4VBKtUwck03/HHaWQaLEh8yw7JhLj/ULfSVubymduFp3ilk56uT1VkPAFRJoIbIGuVVR1EqN/Dzl/XgKVvErq1ckSKQMR+mn0lFjfbaC+tIsiQRHDJf9MQ7J3pm7atmpQMi1Hcbv+z0gjCBAw47zaBXJVSIhuR474L6FFg5Bq+y4C6370cqz3JWMr5GIAlu8iCAsEZv0GPmYFWOTyX3TbmnEKvMuxJk8PPpo3vVGVzQk4fHUhXvRT309cerErqE4qOfoh6m/fA/zLn/WdUIGAapB9DTnVpxcfNTBsrTLetwYCHKEPNUAqZATiS4MAUQTs4K4ezqsaeHwlW8AGfUSXESjdCdSaGbwlF1JFOQsNCSguM8oRQk8X5vfzUM9UWJZEpMvlJU3eEn7WTzXOCjOr6xBWs3mB3CmNaLoQGQEY94uiN/Hg3o8d2oNhp2UE39uHSGS6Esq4B72qAjHZ5Jof1XgrDTJAjlCxYWUDKhUZo6CWTCbZqApw+IzxeCUd1tW41CU1q0TpI62SxUztNDyaJbk15VLpQjgGycV37dktXLkRd2wmbrQBKQOYjvHXbpUNlAJb5fEASm1f0MTP63m4uKhGS0EmSokadiYuTx3D31l14JqGkZ8JrjYz0aIyrPIRcpaIQBFlB8hk9vEvOfk07rqcxu1N3cR0jPXTZtRq1bIArjVj+JbXTlFAkm+Ytpsb9Yj54Se0ZOVIJUScapvLLrc/rSFo/qBT7scDmvaBJfOSBj3MNaiCDIP0CnSbTGD0cyYCqJdrIZjVKnDriX8JJtFcjJGui03gM2un+sC7PaAOGv87EpLQAI774UFF0pv6HX3st/B+4O6vLwvO5iDUpK3u4BsJK5h/EnWfHa9Pp4KpJHjuNiuCV5QUqAZXXCCcTN584NEqYV8J/EvoqHkiWKdDWtig5Ah/FLPdmnp6n52wplpLwIusRXcy2VCDR0tYCX7GpKnU9T5M9tI0NJ+JXBznZ1hkj1M6B46Ep7poBqVIxo5C+2hB+LAHQykMspMI1aDHX3MDzbk5ff89PNqhxeT+LVTMm+i9NTJJRbZqgrEXSADwXGvuqubkZCynF15gKeK6EeeDAjCkvyRmBavh5W6BbLJpPFNBrgQf0NczHpdnW5VQ/1KceznykkqCEyVWPgayZT1/K1RFXhZwioX4cbXtWU5UTxdz/6ibGBld3ENDS8mrO9RMXFdTPa7V4JxINI/snR308W2iTyZ4N55HDHdojKDlXm41BcwNkSXZkpbgNjMKoYuSxzcMD318ZpkBMcSGseZmg0dP20F9W8KZLOjdPhVEEJKjaahq5DpN8N5U0OAIn02cKUVx3yzA9Lw8/3k7+7qTLLpsHgW/VMqAVNmIVHQeAhV/sXfQ59npV0xBPSM5LfujvDSQs3JFAmhr5fX6BBk9XCVIqvand1YaVzEsKkNW1Vf3pX+eUJDfZQ8LhPR5W9SyDJqxe3ssF3Qw17t+Yxj8k1dc0JGVPT3AsRj0Y0Pw3kVeu0dIdBADJUxWHNdBeORP0HLZ2OrdufM1nFQKZJX49oJULoFfdORRm1i+M25KC70YoeOp+RBrIHJBEb50rPMNyW7s6GP8w4jB1kkmtz1VHtIOQJpgSugp/ypLkcqo+YmsZFwKswVPFTM495KnD7/fXo0W7eDrQsvkZNTiYiMOED7CY5pxteTnUD30L/3xY8/m4PEb/QBCNBjgbNLhOyNXLVy6tf3xDDXFG0byamVqFrdbB7abCSeyUfUq9a+MO7Uq+Y/RuYlLjBL9cRlQY4ePE7mg48h4SHNQ/hHLg63DrG7wytF32/e1ltrmmsBRD0jqhzBK+Vw6KHWZl+JwHdD2esk330Hog+ZZdAFG65lsN6May3j+Qm8ceg+KcwWQaKUIQb3V8TQhYKPQ77encDfJOoW+03n6aK/g9mCg2yq1saPYHpeyAnlZxhJW1ESddxwA0Mre3Gg5UNIBdibf5Q3WDd0Y+Li5Lt5yFKaY+aSfCmBAvNMNFKwvFREZqo3M99cYz8qN4HlDyL6dn90UZDHINr/E3mIQHiG5H/Y7JgVsW8glX0eMdXRxJXbRqXphx1r9aJm1UFcHkmhPoJ1UrXuZHnyB2L0GgdRvbbeUdMXL54gPKiMaNXbFEBVRxbHZR2uNIdBoP39HZytfmVNIAcC3wXSQc6aF0SORUoTmmjYbEOJWkbNVWr3chQVO4TXfKO/WghqZtPtX9BifWwwg13MmMcSN43lYLhTYNJgex2n0yT9jDrQXXrcXLrSpkeE6RI4ttPp6wghDgwTKe9HBTDMQ15kawgGKYI1sw9izwV+eyQEDomAuEHGKucSmZTJWEbmjexB/2sUKSxqO3XulYtPtc7PEz4KKZIppExfM9HC5oSHWVK8846PBhFLJlQbwhOdRJQTa17QQ3Cl+6yFmcbhqC1p7mWby5lQPM1N6lV1+BBMNuemf32ufA7RxGqS/A5XjJiWDSklDEkkKv1KbT18RlxdLtWw2R4HBXYiMS62suRbaiaMFOm+TAQOi8zfnqhHuCIAYwFpDAjqPsPGfXdQJEf8/dQvQhKjAZua773clSDBJB37HHXdij3g6OJrCqTtJAoC8X7Ya6gWbhXpfxJU96vK4dB3y0HrkUw+lwcDH4y0CWMJDUf2I1jfOTQxLx0IVmhEGsLUKbZbKpZDZ5+phJ8zpVIGQydk8zsN+Df62YHLwx0DW8vpx2QhSy/ey5Vw82Tb0l2iPr4nU3Rk+wwQmG0vX+Y+4BdpOQJnUHsghrzLXvgFdRmeOm4n6bea/lrrCbihqAiqvKKDlWuprFOIDy6f8fJuvwziVC/H3eH1V8AqC6sr9i7l+e6WKBlOgzjtFlCSy/yf41SJTvh+r0iGWhtyY18ZfO6kpQX+N9UFZPc7lbmfb6s7n14yYtONf2J2v2BZcYkJvWqTdSk02KnxJRsrhtf31G7vSG6Xn6mFnxxyTqrxRZtkCOJ9sBwL8NpKG5fd0bilyYrlKebKZIe2HL3XAQTdnlSioVuU6ycc3xxieIS2mVNcVAx3YjpySyE7kAidx5qFvk3AQO5nKFMZVVIbRDYP/yjuhTAo0oQ4lP6y46HRViY99E5orKLHI9cUb39oe1pmbnHmntfJwx0g1SYTjk0ayGh56G4lzgASmsmpPNAHlWHEdcWqvlqlGCfsLXX6iRgbu8QKokRV6jB01LW621cY/JtSGMVtleecIePje67IaMkqp2WqoJT2ETS7IzKP8FCUyLQ4r9rUTJWTsP2lfNafhcVtuLNsEZyvvvnF8SRhwZ/LyhXvUIwoMOSp236l5w/4DRM/O+8kWQ0+nmyALuqsc6UhGPNIFuP6pvmzLh9D0Eh/TdPNjZpxXLzZPaKadvKQU19Obn88HfejOTxWJOVMqD4pCmLHbq6JXFjjaz/OJTsYCxCY7f/VP7QSrySJXWjGdkzwFM0ISMhpoqqpbXY/7A47iGVqTlRyw/edIE/tx7NGMkPlCOggJw/QfF1ckQkk7eVPEbF4AfD/1DYh3TF9ovTo1tuXXXkvIfNG9V4eKePDvfn0oK/hUsCYHyt4WaCDABH3nXUpUL1wugx7oM4UFwy2RClzRStfUIwLCYOLHkLMKFg+PHDXgakLFNADbXDHf6oLicvJt8r6NElp8MP8+dXT8TNUByxsu58x8VxBwH8NHwPpGWAE/KhH2XPz5mCsSJTeZfJYiFbrIvQVd8388o+vR+VbxQIzQ1Na/6VnkYdtquy5GnWmTXxAc3LYBeKpWYscb/0MpCVXpu8B94vJO7Dx+2du3EoT8nIZI6DlAYdUh3aFmU5hHkvCd+voQF1SNo9nQGY4/0koNgJcE4O5AkrlGiUl3EgpNMpq/XoFctyhmTi21NR76XP39ewFrc9qaAbPIF9sw0fPJxFZUN2jBhVWeSCkMC8mixT1gqovGxyswLwL//8j//tbSD6T4P63tYZLdSr255VbXN+eKJuT+hb5aIkeMsNcKapFTbV3hvBjFUrQfpULT+9IIInEsV0JloGbSBnKp81ZBOpiPqvBZr/2r48XGe4w65FdK0cBJ6oA4dlcBCYfllp+9UQ4TIT0AxGYAvWHw6t8hHBe2MO1Rsu+3dkMC2t19QU2xCwjnniGtUjXcVTjKrpth8R7y44u6PQDBNH5iSbgDKXED3ofD020scSxUdAAmZTV+wnRRxSUaRaZMZvt/VuHAT5hvlyX1WyzntiqvWbtvbyxvNvHQnHiTIw7E5bcGgTXH1oxKumFIc7vhm4VjxPamxFdacs4dnnVkcVEuPhvZv+iuZCDIJxQSEc1MAKK1H81aYapFxF6Lzk60u1XsahT+oolyuqDiDLpWYxftqX6faZme8p7WMwWYtldES8kiV4pu5JCExX85BrtNndaSh5kXovTHIMzKYIOfWlinR+vu+vHgMyEs5JoC+6jDt6fbQX42ViB7JO5ViWXdTrx4ebSEdClbzD8lUeTVZKbWX2jnNC3fPXFgRj0Z92i2IfqgJ5AUrK1oRc9A0np46YqCHeOKVr0w9VnYTddFefzu3lFpG/08uxBWMs5fZWSUXYBwBTpzDLIzqVbBv0p/27IZgAznWw3F6qUTwxJg0kDHZBbjIrbB7Pd09TYBG/TLReA7KuviszygJFPBKsy8Ll2ZzJVPQkkr0RMOqorUzrwDQMOCKwxesU/uPG9oq1TbietbZ5P1flx1OXSUyqqeMREjP5+/36RD31WuBfCnYkqIRskdWTIanda0ixFcy/QDA9WvdyikreHNoVDAKXpT4knKI2nD1q4ubz9DdqMZ5FhDBaD7AQZACQ7qy13WxpqQ/hxftAJ+1eGlmFkf9iSgy4HZDKILBDx1l7wMc3nlDYxsRHZo1eesNeyPURvLLdJEvulZT9Q6FHQItbTi7tzNICVXjbAiXOCO25K62t+vebEW+VsoQbHf6DuLE5XUrsixDHhKTsNyWoK7/Kj9JUyuAJ7oGOSBTefyv2eqf9TVTeL4QvqoIjMqQXI/hV7YPHr1e1jAK28Y7d9KzAiPQqlyfPU4GxvDwHPLbHs5Cx+WrIq8tGlZPOqDOuBRSQ7bM2NqinYmsll3UXrzgAolFVwWMYzy8FqsqEV+gNAzorRymoacn2hk769v3Q4CCe7vgQNRIH0B5xZMgtlYqwldZuy18VzRhIw/7cRZGziioUztVklJzcpE/ro0H4vrpggkW8ajt+rinUKJ30mlBydEFo6/Rk/Dhx9NOBvhbVRA7UoSkjdzUFxQzyb92TzOH3D8XMOoqAWvluSSjCMmg3mwClxF0/HzKym4+AEhTq3urohRQqWhPIqHRL71ZTIo2sX0vHDhaX+kX4ts7kcKAfWonxTUiWw4HnlJ3vznGzU4ECNSDpApgOT4kA+tx152xt8BI5yR1b05l4zlioLadekuT0K2gdyTOm1O5xNDFZZxNxeXysC6YR7oH9rEGiz60gnEiUYBwofxzoplJTTbSgcWYj6n9TB90DR32ACf/i5mBo1pQcrrWDuDURx0kxW582aYNooa/sTyAZi2qBd/RzDdmOtV7olSI6pKQvC4pvs16dMvLwLGhRL1BpRDAHZOJqSFuSelOt/tZSYDwEKyUNNkwr0RyItUnDa8KeF6GoJRfb+MkpopF0Z9SUAmIfSLsOuwh2OInVb0IVDAaVc3iRFD0cC92zMjjkcmhiWNKtZA4NIhnKc/Ghg95RSgDDgK3FcA/1NBC4tQ4W3qncK6PJOsvTYDYDMUeeG97prYYD2Dhz/08ZjfNY8neFOIrCdwum6eV7k5jFVi3jUuaH6+1+HyBJT3e/c0H8Sx130ejocbGyTOnzLeyr7XQVxb5BHGtC3QlNGL+IxmutCe07ecOH7tpvGwpZeYCyoWlOu9YlLTditGENeuo3nW3OHKp4Mop6JDS/CuqiSwrJKSd5eOr3eTm8Kcp+lKt6MK8MFGoctHFCc49ArlK2qetW6eE4lNy08nka/OVWafOCgpZkg420kYNSEUyObbe9ixKRQh62jQqBQueTD9iJPwpQkM8aHuqGu2nib+RUkl0kIT6IcvVJnWp8eDpoef8a0q/7nY38Bq3T1OXyqAfISWBuABqFYQgQXHePHzCA7Vi002cG1Vz9ZF3KR+1OwUkLvxJo94Tn9AEVpBowcCh9YaLrgCqQLNa7izRd1JfikAA5Xrqy/1GD9drPVFSJnjiIpk2VwDtxkn/ZPUB2AJUPbTxwS+i/ZT8628oSoNxVwwIm3T4Sh7gvlkFhuOtp3ctIEt+ocZoOhsLedzkbh3aJXDbJNkVLIiPSA9nMiV6Rejuduo5uP2a3DIf+jzkv0EyV+xp2fK3DzCSgZUn517AM+0dTYOnF37VsQAHeKDsMWKGMBatMMaNuwahu5gzsk0rRxdb3ka+I57R81yHu+IqtmDzoEKc5g3x+Ae3q0GS5OWisdSv3xrhXUdo0jLdPAyUU+9KwQaEpW7hCOJ+TXEvtoEdxcDiBnIa6cQi6k2kvvACjezRbS5cieEmu/XPlh5rNx0JNP/jXytrrFkk46Oo1n+8Jj4db7Sc+S0f693/+p//xHAjb4kJzX7Hh6oB1wQa9zc+aaFy+aEDGKkys8vvxR5cDuxck+ItWminNwTO+R+lKT3Y4Ot/wnyjU3tq7piXYVgG0hRiRh+plDRWCmqX743UDXiZwmNBAdwBacVZNAITM0OOVOdayf2YIn6+HdAh3QTAPNpZmpBA3zi+ag6ue6Dl2wxub8zej865xvIKYqfvf1WiH9OKu3wgW8u84HimXceU7lM2W5AKkSkCpYNSqDkcycGfPCh0oP4R+sL4O2LZq20Sip59HoeVzpkhXEkisphnNSZ/0ajGasRyrHkkJ4JiL89jnfcM9jAJUGYaDhF0VjvFksXrqPytE5dAdYTS03wvwSoWBvxSgCB0vDk0b+E3yeul7yKApiUdvIeoiDWTWMqKf7kP3K3OrhtHz2u8b0M7AZVIXX8xoAWf4lPAhmoqfnAZKjVwtPj7HSXgq52rtAk47WagVnFlnfVDRS8jKts7ZoWHptJsmFzE6ZRqAArp1SGiYTgOk3KTqecWge/E46bhmFVlWvSUJEMUDmIzdHwACEBlDfEYfny+o9rdc0C25J3bPT4Jghm6E/uQK8v8cyCFWOoD2SQWD9MipCDBLDoTWJLCnmofm1WmqLg/IHfwgUtIKkZYQbZjZyS1zIYd+LdZex6EuOIoRjRjtScFXc1SCihF+WVHG1fanlaC2Q3R7ruaKemssBPooT1iXhN+ItMf4/RJtlVV8oa8mONaOvYIP0WXHevS6HeY7n8aS771aAIB9p7t8g+BqiGTJMeUixTH7+q6k6bAvkHAYVQk0bgrRows3knzGZ5H7SwWtV0PMz8mKyPIge2KhEOTF2XZTWWg5rk7dLORclXohe1UnU+s9ylCtJgOuXMffmaXo7ePmDZwvdrpPpGgdwHy27oDkuvIsdXqbnm4+Sd85/mUHu9Ya0Kp1QAh0CM3jpCdB4FTm275gwDANzVyTSlRaKHbxccHwwH640B410vBhLO52TvJL27hZAZ9eHVKsevKKhQR1KjqfA1nayJXdXgtesgB0WJ6PUPMVVU/+ct256gvwCkFd8r447DVbh4zvNqUpbvalX6xktm/KULIyV7RNYCYlvh54ZPmYKk7UJVbOWbMM5jnouhgnFm6YIILKiK6D+xU9l+XeMqOX01CIYBF65Gb9hKw3DEMPlEpRP7oJwfKNk+awBxX+MoVJwAZSm6dNkHyvBOakesdTn223Cz3IgjotBfX1subk1az10qWonLy2gzezLqclhbSuj6We7JXYVk73xhKV20YlQpJffRU/nwiaHXuiHdwa9Mcbs/BZOweyKxNpaj+HZ0IXI0NJNfqS1ksXzUGtEiVKEOX60urG8SmtwqrKnOUi7b2jS3VTgkJtrseK2nw7Bw4Q2mZwvYqmWBtAZR2tm1vtXI5BswgruxQCNNpDuwJVR1dICWvLT5xS7yhUkOkkc+PbPlRSxa9YcpM7oTdAh26xmVAWC/puwch858FQS5LNkZupAnCYh8Um5ELXZa0snP18vRvLo3taWqm+PAF/HrYyd1YjwYFMKYeFAIWuO4Jzfas8UyS3hZXRak2KypUQpE3UCY/JWMBprmKhuXKY4dUsbWUqAtckF307+ZwSi71kuDE2TEaR4SKe7MOVnegKk8oHhvl946AAPnzKlDSmBH56DLk50MiRgLa8i0Mi8DAOQs3TwZEozbkLrOJIxAHgD3LHt5e70ObmJlXukG9gaMJga2FKFgj9t9Elz4/kIfxNjQXiApagMykIya5wGgt+RQ3txuHONCSThwVD+DtvZvn2RMQPFtP7MBhCAM2e6rVKr4HmPKUq8YvO4CF7z/OYHOEbgfJbNe/tV3V4PmIY7a2iUNXw1Lrxp8dC+EJOWpnZZrSslYBVm42ICvONmtwXzjIjOTl7cISDIxJUCqvgGjbYzkpPIP31v/lKgT8o6vJMNZTIHmVPLjw6Z1cvliPZWSIm0Y1ecZwsKszUI7pBk2ZbMivO9yooYUwllF3ynC+PJqmD56Q04CpURHK/q6tjtM23mA2f5p5NgzVqDs32LNFIBRnVvfxcg+VSZ7BjYg6ktf92AI7Cf0VvDfuv2nTuIIZi6Ssxr+uwaFUKetxd759SBpHZwFuqqkBG0dMqYeBuTjk0H91Td2Z7C+pQGok69UJoI01jTbX24yicEtSnC1Wl3WRGY6upJ8UaUWadqplaMw5laHKeXu/W2r8EEz01Vei9HC4rtoRm4yI+so+QqyL2S8DBTdGRikyUa5mitG3qiM3HxV2dF67QbmlV0hs51oOcwAElK7ido2OuoRbLFMzwCGvOYyG47JCsDLQm6HjRPSu+DOaH5M0y9fLsYxtsZ74gg5uMfgMaLmdNkKYY80sCPfiL7luYVuBsatmlk6hAvSQCG1O2iH1ZSeiWlgbo7olkNSYuPO1bhDYUwOO5B9u6GhH2KfcqukRld9zXpd5QfY1eYSgoQSisf7NGi5rEyjFJPbRd82icSPRgtkmSXOa/wHzJ1U1snU0a3muZcJG21UgUQZNF6fj4UBrX+amQJmvIyeU+1HyIslGL90/9vrfPBxcPj0t6Sphn8v0yBlqmmKwTpTeYLPVuV7QvWmX9fhctwQZCs+83Swl8v+tvvl9WxQNI5t14QvegPFa2Ky30p0pDvyGeRqLGHPIoSmm+CwTJmwZjbMtKspJQFzOM3Viec7xrU8eWAnIdDlZhW+tMlIH9DyNBmUFG1CE0CcgSUQ/ZxAP09LqL6gD7b+jnzEWwwK5UDzzKMTNVAb0KFy2PeEhH6PhiDdYaf+qkDvy3evNworh3QXV8gCTP1xbCNF4VSmqTLO3rAfKnOcZL/PGJMvp8SY+okqz2rCLjrZpWZiNcQbPqJebRCZ1vuTtDQQ/T9QQFh2QfBQZley2ovFdQnU4zPDw2NxiL9undOy7qPyo7mQQ49sZuBrKRps5P2e5C2JAZCZfSnJORL5OPsJL+tF4Yr370nyRHk5589KVkCzYxi3bRUz/pRiWKxubks3p9PA0V8AWQxZSUiac7B62lKejRduGA6h1nSse6Jjgt2C6MpvJuh8Ovu5CuIu5wU2BR82ZSQeAgjbQsgbiKe4+k+IANllmG6D4MH1pbV96ti+epuTBK3laIP4XKSILizjhsC9T8GqRTNkmyrOXQ9R7cVWJ0Q8D0k2mXO6WqVC+mNkPAATUK+fzNhfjUH0lqoIj6bFDqNQagFTaFbOdsbSoUqZn6DtU7jeTU+Jg8XhMY0hLIkXlsjgbOcPFRfv54L3dpkRAEvARht95+q8woK4CprnLErLHLbhcnhFdQmfWNYu15qEQAkoYACD0bubWfbikfT3WRJ0na2RTNI2o0k6VAC0k1egaGN+/fDekjAAJVVQPvhscPq4BHbop86SEL+jlOogCXm81Ak82nNm8GA8rLlEw1hwcQ5sM4EK80jrncFPGDnpgJ5ePRE4yA+m4wpV1MfW+MiKKsQoFcK3Nq5UzVF5Mx0OQMUB9SmanuxXoaCko1TUQ6nD62Ow8AqsmJUEJt8cEQsjoP5T3lH+TQ6Fq0sHNRrWiCEX8RazCYGsnjEq8RrGQOFcWbYZMJK002AEDNXyCB6AbJY0zRBaqfSNbecXB08wVA1XmTgtudAkjsoD49bNxY3wQKo7CIVRa9oQFk2K5v7W1e0wLFw/SV43bK/ujjyMHmLa89DCMhOaXhG9nodPV0W15j6nLLQakU1Kf71efahFVXkVttHp2vmx4zNc5FKCwTunYiyRcHWnJeSkGDSk0mxVU+kAQKC02T9b/dd/FH/bXlOJXdhV6L3L9KqBkwGAomKslYrOl2MF+CdSF/QxKlsYhmCwjRBWPBlLbIs6ylrCWOkwdNuzJpbtZukqB3ZkGB3qa4XeW/3pl0GgvN3WD6/QXlSOosJkOp/lkRBnNXJjoZF6p8JdCy7jROf4Zqf4dl6EPV1PjzD7TRVq0Ws5cL3zt9GmgwvCN3yRDXkXV1/TzYmPuZZwmpYEB3U2qHHgz2Ymo7bSif4mhiHIZiJolKMIW91TVG5k9WkGtCTjBVkzw7N1paFO73r4ghOV3l2GyAVJBGUse0cvlpZFRZhcFSwf2DYf0DTLWzNgHJB9XQrP1B6FADIpmkobJd8Lx8nEJEiJgkLvjSbaC8lruQfH2ULT/HwakXcVrtXHllt6brms4vgULa4EKeGq9YtVK0zkN6j8puxpqq2gH+yiDK0gLD2DwRDb5M1XpozVOAg/E/JQNkJAl8wlPM9WMczHLwPG3KbS0xrvl5W0FJWznVR2EWMqkbQS9Ln6AjQm2g792huxnipktDlmX/epQACcg7EKvRZq8p/23FqfA7Bgqha1k5SXkXLRUCHRzua3gFR4V5XWur5fD9EOEhC+pIQcUCszDlzqrmOpHUZjE948QPgR1VfMzT8bqCF5OlaQ13mm6wA7+UwCVNJbXmsjRyDDKlBYBeyJ0cK6sAW5P70b34HKhw/F738IoltJODaaDViqZ45d1m/p0rQyAlPw8aFqxpD6TkLhml/NY//opKVo4ldX2LtVq5hqLZNAhHGSz5gbg+kfGUqABmN1voW1oJx9SF86U6wV3k0m0DA0aRMyJNYXnUOBFXDGlI71CcfpeK/BiHW+emiKvoSafXCkatw41JlrXqd5QuD3Su5uOS4uhQ5DRALfKg2Mw3IGrXuuGydrkJu35u3gOj6wdtI1mhGCEpRqg0jY1Rs87agnqYqHy8LGDkQKZoJtqVO6dMqmfU7KU8hIE2o4RZZu075SZzLLnjSTR7Gb2IU6ddXSOQNDXWSlubci9JwDKLuLcuzuFGtu+Qq5vVBYe1NchjW6H+oTTQqoDeVLxOI6mifF2oyVoDlFPzmuU2GltTsfmIxVGq4LTnQiBeS37T8blvv1+7HzIUZTtJCCl8K6NAQzzZKd5bl16eS0fP5YEY3AyGDlBdlGMQjr2xH5CEv6u4ZOQoYg3DK277DSVbwfR5GgFq/4Oj1Pd62yvgfSgBfl4nftNbw+sJB9MypDoVULWYriDTft1qimPovD0Gh+uK7rfMTHO+ahDwsub46r6NA581W/e9+58QFUdutletJgz/Kwyva4nKbnRU/aMXtu34IRuBH9mgYKuShaNFfQ/vIfmEHz6fHzOPsDpmscZCJwmB8lDg/LRkO2uweF8Pf5jPgS7wrHIA966S5nwSyIx2QFKcJimot2RiMxAOh1U9IgeOWfegQ259qCLqCk3L5G0XaGORXxMvfrfVTp912YWcDaMZeVjrOpRTfaAOvOm5UVi0s9UfnqEarfgkFHHpJqQAbPYFbSy3ugL+5R68flT8tyBbpJUoPLsUVSAroQ4X3yBLwfkv3g1YLKNHgypDr0HJJZbhkcnhahmbjrNUT86D0ZxHmMFKwjwUOjUBr2dnakAAr50blNLdzoFZ68k+VjlglExQyJfjrx88ISqFNK9mCR+HA88FsCx0VQZuBoJgyYxcJzBAl6cvci/t2ucKhTaMGM5CKlErFiR4AHf1vPElMfVfHO6Xti0fQri4SgCxvvH47jv5SigZuNH+2z2WZ5SZl5fCvexA/87kPaPlhGX56rD1PlCWI9iB82zFkrv1tRedRxBLUN/T82zZnFSy1HHoonLerI091zxZ85BFbAFomd2Q7ZwTxeIBJJe9Lj3e7V6FqnrMsQhDbt9N8lVocHKXdt1exqEtNrT+WtQRw0O14jmMU8nMNC2bfcvWUecd7VFgnp7yVQ5HjQPkJgvQO+Mc6q0gr1evOsZRzPY1FGMO46A1BugYyBP2KKoXB4R3kLPlCvxZ4UkfY2B5hkhDS5od65BOYzEP3drKwO+o7+fceMAhsKbM36UZuMoSSRI03l2QQJvzWKJ1ByK/G4gW1orWquqkGweNwDcR6Ts9BeHfh4EOuIBmFQjmcfR0cn24brid6A2tUj27zeqB6IS0KFK/1EDu4lAZ7oToibB3KOUdC8pqPUJEZ5YK3Lv5bv3+BqwAZ0o8MbTKdy9XtRUbqQBTSe2l5CRHazL9SUp/BGPDPWLz8dmT/I7srkZAaW8msZdc58G+5SsQsC7t9e2r6f6W1DU1Fq0ywJArQBy1s+60PLMwtHYfjrwZxoHJqXj1a+EAlEF7MU0JwyQhpmu2L/tFNL0BeeSk2kUN7CjHcm3dnNZFB5b5K6CCcoK8WZodw3Z3LxpPFgR8v7njj9YtrqFxw00kNxjhUzfbgTfHRWTAms0kMYpcZNPHlHVcobJOUX8JmuCoj/14mCKCtNF+apvW2F+Urm6/MDR2DxIrsJnp1Yth/SUH/5wGLRMu8NV7NwzJeAyj8am8Nt2o2F+0wyOgFGwXyqnNAh0GijheAeh8dEYvLD4zhGtwBznOjDgUDwMhSwlMHQSaakwXFUEdqnEtJVzTidMjSSabaaa2Y69t1jjlRmjeJ8KGKT62H4gKM5DmDjS8dbaphcrF3sSLZfX4n0H72E421CqQeDAWAL9p7I9DxYL/BEhKJ3Y4E+yGSUjnVqhqjlO2o8T8NXX1b1hTaGCEpcj0Xq7oZ5JVK1rnEs9JQypRmA+r3oXe+bk3GE4vWdWOBr0sdoa6+eCGWozKGxVrxEE9egCfw6CgBJM5XL4FappwyUNdAHp9w2TpPtn9LfdpGvyX2PbGoxqk0phxLS/uxoH3fcfhV60rEZz3ZT4Rsc90ePJoNpFZwm/lySD1bGIHekACXI3aAx5kspisvbY97zNg1sTb2Omuju2STkzJQlmNqsTZ48dtVEUI7YjBu1lPQ8onxJWdGzgSTU/vh5bV5u1kLEkFsOwOgcpuVYb65esU+ZSDGm+Ey6LsVL6MBhgjGskTjU0YGAvh4iVBrkQi+d2ddzuW7BW52OJYDBL/wncZWCV5ywJJy9ytvo9245NUJBNqTKr2aCv+Xwv9EZ5W8FPhfzsY3YAb5dULFbAmAlZpYkxrJjTwJDIuazdrO1Yi8qeBrSxUp3Azhi9XM02TgPTSdpxZXHxmEdC4CiQ4NfK6med5SBCYXLobk3aa+89K4JnY7a65W2pHbppDSPj7g12i3Ae/faZatC8ZvRIaSpcKHQoxcmhQrzSxjm1ORtyFQ/Uww5VBgJpci82swmpcbb9yOGHBTAAlzXKmN9kZhdUQvch16nuOiBpdvE3oMeyfBxVXqhPKfEd2Fgtf2bO1Gw8iD11/ZATorPeho67jwDG8WhzYRHU8vMvaiM9OG/Or+sP+tQo24qGHuCqSeD1yHU1YZX7rOeGQUchnEUZqduQqExcd39vIOvJSuGh80ShT0U+Klt1e6lZ5GixZZj75kjvmg1Xxfhoiv3fJuSv5JLQ1r3aTCaX1rqsLG1pZ8UerGvC/EvAAqGyIGy2rDk+N1ttski1uPyOVVoR8GDmvHLYM4AHkk03BwdbXfHAB3l+kyjbHbXPS+ri1vBxKMrWxb2HY/Gl1SP58mqq6VnT0VMUPvX9VZl1VJ28PJln2yrXM7Me8KNwYra1eYYwts8Rp2SxKWTAcY1d+lGPfn0iOhjg6R6HtbaTg/WW+V5kNJv9jNWXz3TCIwmNHCsXIt0Gc9wZJ0iZUZJSuNJ32D4PgDL7ave2s7j+EdxK/XkYeDHjrYcZq8JT9F8sgvW7+NjbKEylFYlEHo6gEPFpgCNSWHrr9SPR21plWZB8AtdtozXp8o3I6+IuHo1StIiHMd60DBFBQBHHEvV3TXM4vzN2olIUvTkIwXTKRMRX+gigb1kLYVLhQjYCNAoN83/C4VT4HCnKvAGxtyPGoCu3cc8PwSDLnQrH4e2mfAxSUxbByja9O2XRqHdPYkTLtsDAKufOUBn+fdhXWqnSLY8M4vbD45QbNBrZ4SZ5HfhCN2+z3z8QFjVZ8VFlYOc20O7tSPl4BJORwajmUPBwVPJkMBDlCVyjAy3muH5UouLUS/lUXgpEwi6T9QasnN7GDIerRqt4q53WFAXY4jSRLjr5f8F3k91JzrAVS3drRd/eJOiRSbSTCLEPZtKFQ0rh7dNd7h5yFi63bfqSwuHZ2ceQ4JdA7vv7XoVxLXeU6Mr3tJka1Wpn3lPMXAQYdSpIK+fAS2EMj0/CwXnq9DEWkO/zeHGUosHgditfs0zheYpgVqta1GCwHd34qXKuHqrzTFg/lq4UA0sCUv/A2lAtZAxQbnw2yhruEiwsbvIEKfqHwMBQqfgWLTepOXQM3+OGDpG0ZjoSYzkVCHadKWn71rKWjXEocENPSFxUhelli8v1QgQp3aL2NNhQyW6bjLiOFvx2pALuBC4T8s46Encdsq7Su2rA1Pk95xD6UJEZhOq2adi+wRS2BTWny80RFDERLrxr1spxcOkNzzXrkiwrNYSjoNrS/u7B5M1KGkCxjdoxgVtc3WXcdIri503UguSh9xyRyw1w/Wo5x7CNNJFSrIpu436GaTvBIRizLskkZ6BPdi/BbaAWD8M4g/3giWUv4aA4RXoJ2khgumy4QQvDPPSYreDLtPwaKFGDlmRpqB4FBmhaAHdB9042Im0+5zITlcOWpQYJsE7ndfGpeN6DhHQjt0ftUvmIumn4fXWUg2XNRyZnYZdG50aFah2HYokD/PJXJjgOx/embuK69B3OE/zSSNu1aOV/MhK/LFG5CFo5pVGtGn/OlUjZ4hTviFm0aaH89z7r6/utlyA90HK8WVKhkE2L0pYyQBX/2MgXSTisKCt81Ln9VpMVwRV3bO35J/j/5xfykzW1GgrcSgqnbv3SqPJIJAw8NyjBZuy0clibZthwgvlVC1SqCPuHKGkFoLX8NgQmXPPltqF20HxWwTMAVa8d06ouBxnsYaX2+mPwkfXUJ4dAxDa0aktziUaT9EPcuofk+EjrG4GFoPOhfSj5Iz/lSnkzfiFlpmesZ9/ZiSJ2B5boa6KO5znmOX3mArquDSAbC0Q988FNFgnGQLolh6JglhcmRg9ceAcgHI5eoT8eRjwfy0Lnl01u3E6EfyV6QabBnVLXwL55SOgpl2KAOuBEJNZB0wCx9A2lkLfhRrDAlh7J/Go5UZ46ruoAILcNifMX9dq1tkNMjyWIFNnvr7aWOBPOA1O5DpQC1+I1tJ5r2npzrFtwiPxHeJWku9ebdqBhsmIROLUvl5MUEu6mS/gGpg0yCXFZWtoXuQTtsMC0Ob4kyUSIlUag1ejkJK5QFbwU4uL5ZSn7MO7pCw5eeLgvgXUlzpnWRhOIO7ajY4sYDdJahkHy5/TiBnPq5Bwkyhig1eZQ84DNW/dxxyFKB2mqNg4aYkw+atL3QDMBLhob81C/7HEhuE+TNldXI5Mrbgbqucp6bkWdouOrru7E1oBWne6WDHUnpUZ/jVU3WOoHamprWhw2coFTInm8yX1WLKQ8zUADU8t8mZ3L74ejmoxOqVqVg+7FT4dksSa2qkol6TvzineIUsrrYDzilDtKFCsVcGWSk+OOe+iibceQYQltA4ggtgkBKu9J0IpK1o1ozX4QnGIWGA02cHDpngeTUhBATy9yYcIcRlAmXSGdh/Ff9UHSuR0tdblkVYR7+z/77xsUJGn/QbrB69ck2gkYrpKWIrIHcWuEsScpIxNgT2vpSqy01qJPzqOl7aBUMKZjwDS9EHfPifLNafpsqeU9lgTULeo0r0zW74rtIFyk1ckp5dglHMpwaoEPBijRO0RX3ADpuw5vACc4OHQr8jk9xu0aS6/xKKtzP/vPnMPKoEamLTkWGOxhQ1hxEL/mXZAW46wssJ+Cm62mwdoCRPs2YYa16oNb6tMD6HCQQ20IlUu/T1s6SDY/DVGnK+6DL7+YveJ0fBrOHYeueVUqM1mp2vXajDfFpP7nf85AmEh1zb0gFCo2AS5Dr7A7y3G33PVqRhwd6iFcxw3VUiBRvnYoqD15HrqiOgbTdNVpEVfeUD9MBFSfvBZFxmGTyDUn8Yvcl14MDntkQ/mCgyuNUv1KFPwYqAE2Wwg+GKBJdT9f1Vt+4Hst4F/NHObjoFRPPUpNtEr0P1murm8uBaIfR/lKMP0wqthR3Y+ZidObSormoBKx7cDTPADq6uTRZqLJqeaZoHolAQ4Oe6ZGvme3Q7d7OOFrORLLA31qEpm2Sp5Gq5qO3K2cmNOPQb8YSswkzt3QUAIP1933rRbm7x3D7/aEk0S5rr8cESA9JPhBv62THVwBX2aPMoc70Md38maNMYm2i1x9ok/SSJauwalXAhYb5snTwMNa7exJFIEArE+zYcNqr9cTx6yUQXLmLCSrdWBMSOAHJrEHp2F/vHYv9YBUMguTE8J3UJg2QFEpMdmfLJdKAvh0ssyoH/MNzqIjrhxxgXZYJ6hv3tg9z9hv5zQ8B7sOMVRTWOsyQ2pZkahH26YhutGNVp5/Hdj3IOPMgzHf3Q5KbyLhKceB1vtc81Q2IUnPXWIi95pnvBSxqiB05xL5Et1mBYwsQl6hNYq1ae3u5V5XylLPdnlLsBoxQRrFNITJoDw/IIYolWWVLQ2/11cMjQe6WTz1MVZvDnbxHNYc4uEZJPa8Wn5XdimIwpHP01lSqEXcdqve9IKTgPdKdWKc+1v4F81MKSC9NjB2WvqU2rbs1wuGCAWrhqdtdLU/r40iI6ZuPkmtNtUonO54Y6AyDpHfoZqZe0YwkMlP3X+13ca766rDWnCHkWUovGLRPdwOv9+bK0rbw8mrlL+BNmHsUipZumNxxsSfkpwbeRlEGCQquX1DEby9b+GKUSrrjsVa+FuuplkX7v6jIFvJ+2c4AVDqujHXqF9kcgzcOeFc8jARUypLCtiAQzEBCzySPNDD078LPHy+H6QUa8s5cNYHaFPDEJbTugWovhi90M0bRDCkOorHeWhmiZVP2VwnHikv59WV56jik1rd5JoF8kNeTlTCA1qpJkJCAXhLCzUC4zNZh2wb538ld3Mvc2j2W4PXdl/BzHAyJSzFlW73WZeol5DU3xayx6FdVc/xc4wSNhn7+ujf9K4BEd1rneXeqFHWnxqZkHFGKI0I6oxteKcv3CV39MhpRbsCYyLrHiHzJcND+5Fznc2JciSNaWMuDH6sSz6W4eiXHRP9oFtGgfN/x500u5/P+rDx8vCeJgWNKAUPe1FK1AjaZcFskAuMghdhptRCike+I5PitKYAV2vWz+LQcYiBW7hVm+zzqtSAPNB2zmrIBDmLP/Gc36VWRSzHVgW2kQ4cT9EDLFZUSJ4gxrNnpyWRZgua53EAt0tROmjiamzfqlKAWvp7FFQLlbblHaTTI2y/4T1Wgm85epwakilLKfLkBm0TK6+lE3AR4pkvu9utBZfYyP5Z4Ay6VGbPTQRNXAEAxNJ3PA4z/+oG6Ad9c5sMp5Qa2aKUmYrwZiRyUufbdxR4jZCoNtFa7rySUH495YDG/Ai0P+FMthTjZLeolpHj0tK97yIIBViWSHkI+21Ho2KRBLffN25qbfVQGYDF/KPlu1qO6ZfqFFl5aWH5DDRkYFQr7tHCNfLerxWAHSkMqwRhu3TxiugXyzCfzv4Z0anMqGd6A5CSWEN4gRnJxTYW3CY2cLibv1En3qsYEVK5E4EwYAn8N7xXSQ9D5YxiANPcUCwVtiQzINGlTeSqJf5/qRLvJ1oALhboWPDDZUenciwlcJwLG9MC7fqxGByoiD+p609dHsfFhxVPx/sm/gl0xIPBJNQRyE1ytoO0qPk39CFDOxEDTb6cKG7wFkpXb2c3xNLRCm1hHOtr54CucFzcGmgva6AN0kyY3BcFua5LH1e3wH55jVRbbuMDZbmXxqa9aJpILVV7oOmHaMFFG8UNi5q43+kLOFzwYEJ/YpZSxJZEzD2G3Fk9uv5qH7XcNeTLXlG1lRiG0296ll7rac+4/GLw9Wiomvi5Rzv2wi1WaU5FbZWjmbl+uwqSf9ucanUwBGkVgYyDhcGc805xwDEd+5E6tzZGbLkrvBud78Iol6mryD9v5CT8aaV/m+tQi7kvi3QGwioNW/J0G1MbKxGuN2t4ibnm+YVFU/i7kbiOVeVCUNhTTbhBrYxU/Lbk3I0GZkws2mUIz11FYueRKS5T41od4tnBmIAyYwElG02aQfwa3ewh1IFC4Jv77cSp20fKRXKNIc9hSzLncxFFTL7CC6JaZyLzKqSEBxNXrXeqMofTjq+jFKycbrGS51qw3tkVAeL52XSlIuiAvKi9os3clmyY68b3G4HUXyXaw8lWX6km+V3mUD9AlJ1L5ZpHDUEihyR/1JrB+NwkDOoK33blddKKc42QGogZQoKk3hhMDSXiU4rR8N8WJrzqcDHXjY4IYWAv9sbpDgvOyDrz6r0p05EwMLu5PytiIB3HelW2v+Kl3+HfrW7JOHHCyUS5aXafQJwiyLhrsD4qqRJlWetyeS6i2UhcybIFH9wnDwG5V0Gr8WXu09gn24xBq3yDpgKld8sWBMkCjHZ7pgZYRArKP5udulm7FHDmSQOKqFro74IRDfZjsq5kRf2PRMBb4xUBLpRMPQlPVHnVsIPto3V1L0Wo/lDwLHNWiIm4RNm8kcupsn9CMVfAANO+R/UypQAvKqA0qghHArH2xWTgIri9OyoyhDAOJsJr5GIN4wlRrflBRh+YiR4Ph7DfjcAASeqThBqyHgFx3pugxVJF+YQYylKwMn/GM0fWmNcsrLC6VJo30TXfGg6z3EPVTN0rRI85RLpPJN9S+qUGMo+owlsTvHvRcK9Bo7Iaq8Ex3YGM155gvi+gmCKj3QvPQWvND+eHvas1evglmtbf25RSewfLDp1DugYYTQr0B/fv7WFKSUTy2m2GgwKhYy5+7td14KY361PhkDPlZNL27axc6X3KnzV/W8g10fOfOSRJGnFghXKinBCuVkCTF0fXStB2DHBMHPU81nnOSb7BGQMuo8s0qwIq5DvRHjuN8BvjpOGgbz+6ALz8yRjDSWmAgdV+bOPv9QBmq/EIF10KJpESzWqw4uimZcphujUgl7+8AsBZI3qgrdFQNKjXAssZ5sh8GJb9qxWz0cosCkNwo3t3gBt5UhT+GkUvBwNL+VjoDIqlybaTcJkyjCP/EhHxOTllvPXYBfL5rGBPpQiwRRWffOxeH55EvTAfMK0FMhT9CjXmSEVVkY+hLH/ZF5n69SOuvWV7B1hy04t1h503987eoFh4xsPfhpA0Nr6LEbQGEaX8OjeHzSIicDb80hU7IYvHUQjTTu9UUm3Ty+tYmpGgo3yPEGXqqy53njEvRAp2ea0059d2XY6hMID4gwb7LZ8ha6pxrlbL8BYnls4afQ0oA+zNFm40ADjW2+L5dPweJ6Gh2ZSVVUvNcot3IsF9nDtOAL1drgXYAM6oTeloHTg7ku1tLcRQ13eU7faGM6ECFl7ZOa7sX07V6JzfV5d/uReUq0cYarCOCGTCnU2DEZJflalOjp8PnZyh5AAwkrULKUFeZ8WQ01eU01vdhKNDhi1IEKp18JD/DPoXPJqqjDXqyn3F5kFlXa61TD9g8Nkc2WhtEGWW+7XYYuMIXiK96axevqF55Yr20Fqyiywar8t4Okt48OVA4vxb8VK+uEgwO3+jD9LA8JMWwLatlWmLry8heWDSWX1ncHgA5Ke1SiKDbuqTCKrsuPygrstrhdh6N8Pn2U2lJT6UHqkheEZq9zMU3TQiGooR4WZdHxQvltLhUJk4jEzp3w0dwj16h1i//iiy8gZzAzqH65ZwyNwfn4j2VjTcPRB/zNv0j1UeSrZ7CEo8QXheJKcNR+0m1wyVwHIqhepTA4Hb9oGvVSDeT07xfTGpELQvH6oVYQshz5SH5Y44QxfgB+4kmlEcByFqgjcw6qWZaidIazqMt9X5gM0yRI7SfXa2ggTvkZAmar8R3pgkjJQTfJH6BHNDELq606PGaq8Tsmh4HKrIdJHnMvXnASB63LW8tlm4q8dslicD7rFhwkYBQnkum66EuiuzbM4BhJKZxcaCf1ecugzRt+njNqyuVNyfwj3EkmI2j216bSSua6cPVD18sSFLhbASABwbwyCUKRVKrOkOa2DCyU4bQxH6c26EfPvg6YB0RA5Ll0ohGL0loEeD3gyWwz60rAI1Qh1OjV+JLxaw3T+8b+Crya2l0avYPRTEHJyY7MP6o7BuQQZPIfsk6pzL9y32r1JvhEo6jCMdtlr8ZThByR1I9QMKwTKGkzSEZIOsW9Ip7B6jR/CT8CLO4Zp5K3+UXGYoa4oCOtAsXfNlUR++WSt8vXEYK5QEHJU2Sh5L1fRcTX9SH+k1wj7FQnqpdrj+0Mimyo6lTDb05Kv2y7Rgq42MSm+FKi3KRYwzZ2C5mqfRw9tkNtPiMXq2OpNLyM6+F4XVXEy7cXSeBzAVa2FQU1bwN99EhX/yS/a0SFF88Z8nz0dbzKAh0i3OlQspntBT0FVqnOoVv9GG+rgwiF4h8LKhEuocho1/R0Eq3RuEs2EXccL80CfsxTegtReUiQ4SsQ4ii+8elbJ/u8FTs4YvoHaJ0RRIOE8jFYlvp7WO2jyGKDqUM7SsumWlenSTUxaGuaM/Nt4MTG6FTtQqgPICHEivZae9T6pzfEnjc5emO93FMMZYnhEP3qndL1BNWDZGaQr7Z2n0hsrZhCgDWYuwlxrkXCIhZ2v2yfxVTdksgaY6d7f4dNQ4tS6ufnemxnZ8p8PkNX+6VtoB5o1wA5v+Nm66cOykZUmG3xGUgCjimOHBjJg+N4Sb06X6/4JPYl/EcN6MVyvVzdQPJ5ngkMY2jetilnxPx4ric90+T1DFO5sjPYICKOXKlekO8olL7Zi/tpCCuBTCGq0MCsHL3ezWxTSZCjxjk0kDbvprsK4+1yaWl4sQ4FCKcOVE3ZKf/4i6kgwAnm7ZpVd1761Azbdmpp3HRtMy3ZxtNaQi+UDDxMdCi7SK/02scMiQGpifKGcMQBcIhorAeFAYPxWWRvsNB+b2z/f7BlB/IjE5Qi5bn5Zzz85Z0vweUbSRgL1fTOWwjIZ4brPZshqS/bQ4vAQQBp9Xk0Ml9YxxkmsLIK58FdRhGvhQpVddD45PJbXkj3ttLuHRHZu9vP4rn35yhUsW1M+Ct3np9VYFy0IbcEdgArh2T5WI3T1Rst1xfd6WM1/4RCocYwX7t2qIUwjHmfAOSNaUAueIlsHVD06Toor9XfNTnp4dpE1x3uuZy5CqUQ1H2r49WR0pqk+jCmm19DqW2qbU0TH5CCoe2AzdO6dIv2BYiRuvXEPfIWkKPB23a0bhob/n0ZpSDhGbMEBncP1pBOqK4zpxAV0W+n8cgqCkMZ7mhVJLuXY79H57D4HnPR6wT/XVJ2jspylrgjg/BwNPRRrtWkoKpoKjtH69+BJboRHiL38zBGSUb1/gasuCV3b4IMbLOSh41s73WqVKOkOutjQH2Up1r2c55CHop10OSz/pr/T7A9Zkyc7JD/ij8N00XW4IA5ZMtmODDg0l6Gmpndug7epBFD6sj/M+LPGLtwoz1/GD8rzeIzUYVwmtF6cjFovKWYlzDJ+E8FPGLvEynKDSZYUR+r9xPCrm3f+Zltf+GirdA7MzY+H+AwMj9QCGswexVUkhuzzRsgXYLnf47HjLTRE/pAqi4m3D8S64ZqpULNWU75/TfHWn/Vaoa6eHxJRMis2ZPAA1Zdv33aIC2MnqVUwFf1jSOYxJXmDGFzI0EOf5pUvU5kNzeBUE/dRC7VXxATip5LzmmemkGyQf5D5ezHGU/Eg7QE0yqIFw+FmxaCbyQnZAQKmPKEwyGGw+zJCdsgtI2rDEq7r+FanBt0gZZdfpqGG4P2xWAHw1WVKFh/Ol2ydpmL5ooXqCPLln23XUxDh+OzyRn0rA0A4SXaSvHasUZLjyZsZG57tYkkUTGRbO3bzQfdEuP22xyZLl3vMnhWLl/1EVoJkm8W0kA34aDXqAUakzgYwkdDjWdO5mAJnuiLFaXJ+GfiJnu5SKpu42YUUXnpqLW0W7LP1jKTwCI6g8DMsQ9rSyyf5uROGnpoDSEOnr+EwuvUqqwyNduzXa6JYjMpZh5nLwGGGwUh3s7Vc3q5SjwPnwIhO8uz0TkXq5sOKt2syOCDcO1y5An1f6cVfHdGyYkFEcnhalCJBqjMTcKh3JAIDp43V/83PXuVqHw1oMr1HZkJTUpAZty0Lyccwuk98k/1/h6GA02vJIW1527pzoVC0pW1iQAbteTXCILgByjlopgbB0YM1ikCU+31ZLx43ki2iIxmtoAUmB0+QwumyWLQxfDTXDPfnpATfspGQvmHkT4hamRStNQp1g9UvfgIu26T220gh52gPut8mipCZZfi3j1Zj0yBCbmMXatALJl7ozZBpbpkvgbYkTtwhSnp4FOeS/e2IXUKy7Kq1oRylah2cMUGIc2jIwCvLI0FVw8ap1l/i9Z3UiuLbn44bMjmM/PJBPrRE4DWmpshUGFXtCSPxaYdRAk2242GZd2gskh89XTSb0e60/XrTw5XoZOFQTr3bBRSK0hIDTR8tpd+KVR2dp/GemsRvrpUrzyLgO0oaDyMurWuzWIjzaEks53bUq3NKxMyyG/JBT/GR5056eh0CApe+71BmY4cvJM9jqz478Qq4MaoYPdhVUiH/yP+iACdwrd/UhyHOBmozpyeinAlcUkVAut6UAaK/dWK5mDt5A45pvLF6PceBPAB1L8MVODyucUA1ErJtqF4YvilKp8o+YuWU3rcFKPhC5FzcmsPJKDeHp8IeQnk/nBVdj43Oby82YZjzFf+AodYhSQk7IoupYrso6LJpOEwfKJsQd504f53OKcm8iUXBLnIOVCX4t6wvhDQFHsBXxzF3eDj3VT8FQCtWiiGy+++YV0nkmay/mVQTN+RcbToyfe6u4a6jIGW+K6R6BAJSLrSvZNifgQvlQkFtCml2BJiyy0lsw9LaMKNuTT4mEAWN+SetZ+tTtV5wyjWZ6VfVS580zI8DSQ3Lq3+QQBy/4JfuHdy4VKH7K4yQDZfy908Jln+X89akpeVeeQd9DL1708iGf2q7ndnIYC5IPrlmWIt+QpbiqdN/mkIVez7/szDCiq6YZxF2Wqj2BeFiPlubow3o4PxFsM9Hwr00tccufZ+L058MObYs77NoPhk6H65T7fzreKxD2g4mraEaczjTutIbV+kZOhNL08XUXQ+cFrNUiunM7I1fkvtjac6FCMRrbPLE3d2QaOyor/a74b+/ojwwS+s/a1df1pN13+KqTeZ9UgYemv39thEoXwYQP7Am4kR62cA2aygkvahxDuxzASyVFxrma/Clkz5AUz3lSi72ct62OYh1W4kxAQWzwETLMF+R4UO6wCwymV7RpirKfngwOo5eFkXmPPYtdCQ8OimK0zikqpujyonJr+SlK9yCX1jPxuteBjY03+DlOK5MZXixwjqCVIItWQG7J2sNOYDqiH90NkB43wrrUQtOCAiWXCW7wDgCWtxRj3CRp/X5G48tFnGGStW04yHAshglDsDxIXAR9M9wOu94yhYf3DCBr15psKHXm+7PSmOtzoUBS8v4QMqh4Q/GR3aIJ4UTiopnIiVyuQhjCN1/fvBdELAb7eWEKfgqD6MpUXr/I7XJ35zIaED3TJo8wzG1YlLbUJq1fKAHTlITV7+mhQ8vyCp8TzQX5/FHNy0zB/0178eCIqQUMbqxFHJJ+Q6b+7bodXhcJYrm8zJPGFHIDJF9P/beesbLRoQotFKzsZYqEFxYeRkN2AhNI7tHw14BIBPZBWPYRZh3PNGOlUlIuQ0K4S7GbU6o6cmBBi3MjrJFiXUH3yknbPpbEPFabe9EhadlQssRsybhwDvlMKTsU00FPYAMl1ZjxIvpyzE88U/YAAP+RTP58oFqgQ96AwIFGmPSDzgGjL207/0zCAhWZFChV7B20I1G1XAkGs23fw7D6AjEErwaPGQGGAUs9DQY+EfqEN7pdSVN8rSIFXCx9lHWFtlcIgEqL5cNGatfBtO8/qPsFl5MaVjRoAWBGz4VZLMyhK8848DEVzcMYInBs/GHcQR3RjV3rh8kOyQ/rBvZmkiKmNs0O7R3/Y8k5RZ4lGUGKCw5OO8PMYtY9Hy1TRHnAycSNIq84B53/0U7JsH7NF2tV4Ogx4b9dHwMGiywC8bhXZeEA93p9IFo3cM3JcNFEw2R/YnS+pq4TdHr/nbFYERxECxuJ+H3AaQMiedYRCXLvRm5YnGo4rR/83n2hGJlUqBmfUu1yCikAN2HYj9Rn46gYyOp0t6IDKdVuGtIVaa0Stht3DoBSc60S+HRbYzXWe/GSvEcxBdvGjTiQZmRrYfiNvRyyr6JF6u5ZubLCJRe/GcJV1Cud8mNnurwVUvR0eY10h86V2Xjg39NtFVhcqa+MMPbXJNARJUJpVeexWJgC9Oiz5hm88vgb1WFyJNDNl6ZjIuEqz4TwyKoNYEzJsqV3t53Rrqtvb0O6ixBdousU89NSTKkCbVOXezutjVSUVj5PTpUkMtgbsFaGE2ZEp35OU955BzW4TySwjUC0L2q5eiTQlFC8SEPeKiw/qFi1bbIXf7l5VPnjM5nHZdGFQWhuEvSpRDHioh8fY5xNB2b99Q1qFpmZH2mzFv1eK6olmaL/DKJR6vNHq6WWqJTr7tgt9815ymC3Ctvv34voOEwHisKGRyMSDgW/XsCzN/NPN8b6uTSRXYewNx2uH3A56n9l80vWCaMm+P9/oCmCjctcw0e71B6YtdOzFNZeCCpeogWdOI4ELna7NCgOS27tc8xq7U6uPfmtqYPxGNX5EFcgHJi8n5TXzfA9Ajb5Od0oLp3ni9adJ9d1BTqA8J8MHRhZi7gYcObwfLUx3DwcBkmiyTD6VvKD8g1J+aE/5377dHZBqj6UjC3k/CfUkZbm6x21S89NrKeLthuFsQn28IVpVOR5xDziFRjGA6Iqpils9Pd/n+62x+6I6SclhyI2oHnZUWEQ6ys5GGBiZ9uNQ9SZHxBA99L6a6tPc7FtX+2fbls8YCh2vOqyNuZ3AFY14J+vtFN8vg81IvlDRGSVSQrLEhZzNXB2M+UWju/Wn9qUPGShw0vCnfb7JNugHVmf+gK9QtfAc5Wir55WEixHTXbrrtlKMuCpjr3nLhJMBrmtpP+HYmEVoRVX3rpbcA3WdkcvcRel+z2zjc6CEgrXvgby6+taH31h7oLAYzOzHyYhlp27jKEtSeUFyZaCgps0OeV96Jp0heGCr4BsO0GVS5ZD1kTcc7D6HM+NUJDf4xr/8678/9giYAazoevP55ptV9QOXKxsrmaIbzfdm+XEVyfl+mVGkRjgewJZshY7hRRNOo8jwRSk6qlRSqHWAflRHj15jV8WGwUk1KoBdWa7I93kGXI716WLVQuMdTAWucVoiSrj2vIcDm4FgO5i4etA0g3zKNMGcLEU5HelLDDHZ/UAs4KFOQwvLqWIRMZaJb/lLsQAQDptX9ONgA4F00VsmVw6kzOk1vigwY41MMYLDDbXbkV4sJso/Q7eArBH+IK3znoWjMc05PTQqN28gI4GkWB8XF2lkWeQ8bqiAl6Ph55qr86zYv6+6+1KNLyyTuggDHVBHgp6j4dllMio4lPBEQSyzQUWV4yUojYYpXWYDaC+YOcTCoV6PH5aZDZOKEdVXiFZ8p3lExXWGReR1s1Bvyp+LbT2R2w+RDbCkhjZ8SSyqDT/3EPX6uKVuhH9rxr5n+MPxTBFopSdUkckpICvC0DaKp5Gqysw3LYKilyZ5R7y6OHdRH0xZ6nKRueurkySD0cPrIgGAui4SlEXHIjS0eXiTr9sNRtGZELKLkNMIA8OYuKcuIzZSiQoAgM+FemRi6QpezjWPk9jI4rTg5Q19ryAAVpGwcYiBbt2IWaiUNMATNwQrwW/KS43NwYa8p9ls2C5mbnC5QGNrfId21MhULdm6zNjPUJA8vpoe027AfpqfSPEPHrHKrXM9P471zcvhr+sHm0sfCrHTadGs0S+i2MOw6zASvgFDhMO9YC3Lfbm8Tdup1Ea6ZejHsYVhC4gQcnNEYh7HFtZcKGEE3tNH+9mKV3S0MAHHDzpLC4rjJY/xcy8V9+3XoUqKTvE89/8QgzpEMFKwIPBWWNgTV/7+gZougiRvtxaKQBOrG/s9Uk7ZMD/3N4oKY9R4Uf7vUZmuX5RiF5AcHeEEamI59j4HIlEfzkkEAAnQlt4K8nQqx+eRjw2QYlZAwefBEaiaJgCO7fs1vaOwYJx13clHrP4bQ0UJ7XJ/LO03xCv9lR+ty4ydUb6NaHJ8KLnnKA13kHviXMQqluahrgtor3KHyp6pDwX53VgBNtNsTeg1ju7lwClEhZWiHFq6oecJViqjRa2iL4sTra+1nuPbljfz0NNyCJQ64Cflpu300pbe6jskS5Mua+2c+H2UIuMknBRkVfcjsNBlRUHDdCZkgcGsNbmy80RlzAdH5a0tz2toFGjZmWQzDsXQbQDGQMgPD+sjuVZlp0uCAfetO6p6BGQk74zOoK7HhwLlKPdqbICXqg5+cihbH01myWED7b9lcag2ys/LYgp2FPDdqM9O7zjl0kvYez91Zz9WesQGxctB2qTl6guDabcy1CQBhwV7TXft8n4s3kqhvsGVt/W8HovotMr3qgrTuYL9LLUiPFn68UAntpBKmIRfA8aGYqYdp6nIExLfkFq0pAcuWTVX6MPcM8nYfmfA06A70yiTNhTY/DbkIhByPSd8S+f89qS+f4CGl9QfwWtMpe710SIacJqPPGP/SJyAsuRSL96rD/GKk5M5B8sAfLoJ8+3XHUK4flE2V49bFG8nrVTbSxMmvXsc1H8kvVqsd/4Q4LEPJNAx+9wblED92hO6CUaQDSP07OIxgHIXp1d5HP+zKJx8jkD5oTuEsG/A/cO6y6rBoWeZR0RSvpY8cSuvvC9bOFn4KbNuZcmXddWiuiHnuy5bNLPGz0p2NIndL1W7B1Y6xToBtMjWjJNdvf8ouEhIpIf7t6ZI2tCG9eqH8fFLbsbWsFhvmI8tnGUpcZ0MQW618k3ogpl3kISSmZVrLLCd2fumZszQjzeW6ybipRmGQ+St6acsvevyZwlBGWhCxfSBbhUwBWAy8rlE8VHOqnKdP7yMI2sEjH+ns1FlnEglPdYT5XE5ceKXI1THqXT86UsWfS8+n4RksWtTepXxGPLKh7KqktXklJ2VIadtCL8oBavlOM5TNXSF/sNIkPDiZaoI6laHv5NEd1DC9Rqj7vNgg2+PoIIdpWTFaTDGMBOSNFIWV2eIyEJ1hM1TIfdwejCWXCujlo9c9I9i/ybbROFzi7fmIYZF5rzQfR96MqolzicPoyULfz8MP/l94fgGiuQX70flfeLqJrPiOjmSPonM+KCa/12fBDlcSeonbAF3xqy2f2YgJYuOFm2eesj7R5QtomgXbRaoVgHgFLKp0qtvtOIXpYL9CsO95lp5yLIkSWEXDRxtocOmrl9IZTcO5XLb4/wbGoG72cCszUHIsvKIA5BxeDV8spe6cROEjYvRGO+m3obXkBk/vBwYCoh6vS6lurkeNqb59YBp1+LuVy/TpBvjGhLLCF5rQxZppk7ZfclVCoD3tgbtqWuacDqXnweZU5UukNmdNJ9T7IVb7QXF6S+/B/cxUiW5iUOG4eKDAu0tXXU+RF3x/mtZWgeiRuW8oQQxx72A29P1b0f/rdFHmUJx+5kiT4O2372VMH5MMMCSaQJGVRoJskYfeNzPkXCw8wPZGqmuAPMHzzmdRiSxxlv9HtzurhL0dj4k4nFZnXW44oEykCcYsj53p3+MyPf0WJnLrvCTTf+MtShnWLytPyTpf/wxucN9AJYoHbGgrk7FpdSKWPJ6zkkIkH/8jNe3B19S/2cHE0iJoQDDb8UWD9OSqg5J1/0OhfpYBo6PJ68wKfhKsAgUqM3rWHbdz/17aoq8Ce5miI41zTEg45lAbnH/heJ5hS+NU4Yhk5XvZP6oDgecWWKgf+7lBmLrDfHIwzMh4VEW9RyZKqD56PRdJqH1CmztJ/XiY6IgHHNpWuXydSEIRS8o9AKb+otiYUboVhfpmY/vB9XLXUgB1E46ZmXGVfs2KdRp8YjfzZSMg510rYM1T3NzinPqVeYzPd8JmjvNE23zhcZPUI95tpy+A0aBnB6KxKm3cw8PVUFfpNCYXM1EMBuJoUsgA4oq1xUfkoq7k1N1ZXG5NRqTfMCI0prMr7HgmiVpGV6H+2WFpheAjFEi/aOmhNdCltTdB7CsDC+J7feT5YiklgT7V0MQQtpCP3D4YmjGQQV13Dr7RyrKHstWjuRSl6gKnH9rM4HUc0qm+qqulNQ5L2O/W1obWLViBp1Ut8uHXcDHGld3oEU+4YWsFR3PwcnSMG+azO/XEt57ci6O/J4zJVGsDR1MRqAGMuDdMm83FGp4/Jvd+gnZjOWc1QDjW9oLrwVupOsMmarijjcFdTn07wbQlUOLjFHGyV9YZUmrDHJnGwIX5akh9tpqQBTB3hG67090a9Xf4AAFCxyA2hnlAFNGkPfKetPfRqLcj0S8KmdJZ3JTJ8NMRc7q1FGj1KBlkXtTDcrvxRbqAbR+lPopudij2AKyHRqfElCcs1/FDGoJXf7gGKbRnVwZ/UloR7JoTL/p8PwZTWwUyLr2AloGkdUzie7JKWULx13dpdsdSZUpuTIY8hqtZSx84sjkAm3mOJx0D7U+hvLEaS50VhAJOK4e0+/NQ6Uh2Sk9Yj6OJGfwKkyApLMcZnUEWHgiXgNjst2UgOwX/1V19g1DZDRixFVK+qpwmFB2kG1UTfr1RUmiIgBvBbOodS3vSymrBNT7F8tqYHmpQlYzE5G1WxApqSH0ZudNxjy7vqdxUMgq3epT2XGK17uGZk4kVbxX0ezTHYGMZUWhNvaiI5JpBYrD1GGBqC+HTnH5rAQLJBrA9TVk2hGjRIkz9xKU13UdHl3cz0GAfypTvx2ilLPjkm9EvWYopMrVfs/O5cei1mQWde5qul2VAoqnXmgQMon8ufoQU1ZYSj6MxCkqZ4DrmmioTsh/ke8Fv4eEQyYNOO1Nu2lWIz8XNfDBEIZql1e5dckUq4mdex2JsvQQiDoOJd944W+1rFuum0vum9pEqnxS2Z2h771f37Kxb/gqfV1G5PcQlZXpNkyxdqG+yCuk8q7RHxUpQpG1Y9bp7GNvIfsmfLNu4IcCdrizRaN6WEnycysevoJS8E36xJ1HIjX2FnHpYpL8HUpF18XQfeKWJt1xn1QqiSUPySlNjl26vAHv9LilIco/6hpg2/Uk6/CRhOIjsNb0CfRbtemhJvU+5VQwSpjcqBeVbf9ERikLbyFHufcuaoR8UPUKdIBGHzfYDbvx0hUup8EV7XfBWWOZ3oRSdFYrmbnRD5WzE9wiBLp/ftlRU9AZ0j3kfVn5iEjCVy9qbidfy9qzh+mUW6JMr0KgoghqyPc1XyVtxd7f3NtlFGyFPNdwexoF0VEBTcZ/xrQaAs9QQTs8TgqrRZW6jiFaMAN/ZSjkvNQK9Kv8xz/3aX/9l//+H//xv/t/sVGrLHarT3OvAl40DFrH/ty6v1aRgPctkfFsBTXp+wJ9qZNcaV+/3f/yHVQVY9zPe2i0DIXmpL+scw01iaTL36l3ZNTUDGzlKFcenqk3txAgk085qy+yJuT50jzqT3FHVjsGCReGfDUuPVhDI0SmSS5HbeUGAQVIOr37ejIOL+46HQ12HRHCrciZ2jT60cUq+MpI9KBcvtNAEnLJ2jd7Bq4flxdIiZNtQm97QaVvFiYDwa3pkiVqXvaDnL3Zh4SqEg2y0qej+faJ5D/Qrm5GlPR1qLkA/ynDGpZyrzMFycO5k5UIDbi3szvp91SsFhaSHG1vYFKdIXKs7clgFNHiADRRsyJ6DCu4gkK7LKr61OXZvCAM6DoVpKGRy9G84vNgpMvL3sPE9TQSla/+xSlNwF3AOOYe1o0NpgTd/fpuAppVcVBe0uCpiLNQ6b9H11gOKNTd7ucq/5x4OcavUVny9JZCRXjA1CvBYhU0uy/30CLdP9UtM7Ao32AeLgd7GN5iDaU51SQPRwoYI9n7w5ENzn1FPHmaU6s1LLILZXg/HuYdLBGHSNUjBfhvQeSh2FqTQDRCWM6mXH4aJ4NSc8YjgkJX5avnzjUiOweizeq3Ov1hpDcTGVJo4BxTUZI6tnwCWR39gjnNuEcKQF6jw4SV79w7JtiMyNrFCj3qE+bfbgQdLefFd09FIHGZMJTBSxLLipvSUNb5m0EfqRmQ24geLZFtK2MhX+4hKvRwZX/8AYEw3wi9A39owg/+cVHjHSSuDC61bcPJMCE92y0X1E4ym2GfgMhnBI+1cs03I7FRp73tSxHxsi/zTKBVSBn8U+xOw4xkc7SMRO4u50uXv3mxlcq12m/S9gyL7t2u1MdJRBsLdoNKrKqhk1oR1aSQm6Khg6wx+YLWXdtOdqBdKn8XGswx6lKADtDBnY4snGi+lDUR+LoSAsgBImzjc7vCtcO5ULXjXLWyXXz4BpLKwJoWPVHYteUJAuOQvlGAkGgRhYztnAci5JDzeEOPsrAcwSjUNEsmJP3kf5GP6Ra222YkwijTYAxaXlObKueM9+QrImhvLtq7V+MV6Ev1zI2qCRzcPAUMUAWjBDSo6b/OOy6wrHeTaCJAk/9CdmUfk/IfDNDvBbescpBxNlyZIXUwK6nVqb3ehjfW6Ma/3y4vTKDdcvtqTTpxFU3ePhZIsiqsQLC/wCL1G7lBr+7b9gL6IkEwvPE2QUrmkah9mqWf3o174k5G2NLgU2YnTXH7l3wbwlhDYR2/I1XSEGERtLoZs6LWYXfHHyU9vuRqhE6q/P37Lz7jPWJsPZyhHCwCMknFceLiG1tPT8eVL3/aOUDMGdiyeHecR9AeRRyGyV9GQnHKTVu/tl7Tkv2+kJKksBRi56P++qJo38KF8o3Koev1Bkc8U07tW5nY23FxsKZvFBIsznVaxKUi6s0AXA5BpbZ9V+tG30fiDzlTh3oPIjryPVIxi3mA9HcpebTl9nOW1LIxD2EdavrZP7yNZG9QI3ZPgYqPZ2IkemldTeSl2rkXRgvdzVzORjzE5ZzLHd55GIcaWxiMeAVTIkchbxR6GE/1FtwMmDYtIf9+7HCno3ZSYvMe41imeQVOzbVgLCUNsO9vntLq8wRQS46wpkLPTvDM8Aic2RrIK1SKFfjE/MXDEWvFaW1MYxLdODkRtXCnFwuCdDU8aMEfp7+OtOpt/glqLejq0gaEDUqn8imD9HEsqu2qvGurB0FckO0kD1RNjJZGpITjfqmElP2cIb2lnKIeLaEMcgGeMcCjnN0kLmGyFw+Lg6aHtX6pnuJQmTwe1iZxSoznEceIR1Q6PU+LTOmo32QSvUBMgRJtB/cmN/W5d2CmymVgmzVycklcScYkO1yFAhS2fS+Se/E0lEc1Y7h6gNsPELEkluGaDhqLuFWt7jQQTOBBJYrA7TFfLQ1aQuoa1VhghIB/JxPAwBIIdW4Ij/gHjsNF49WSOrgzBO3o+TRzqv11i25dGCAgr8T+hNNjMhzwS3mh1/ccVluWZQYxLwXlECiaMsuryTTK0xp6ertnMgB2OeKdlYexGQjglszu9SXz/eOn2M3pXEYDr0BCNR1t1GTMRAMLMMfFY+3/dHgaVLi9v8zbG3V1JDWsk+8VdYxYS/BL0LWZnyIDgFjuXgmIqJnsPtOFKl0dAtSlHB4H4dU6u/wSGsGjKauPXsK/YBhVbOuPDBSMs6+f6w+l+0KDJxiJFmyS+n58o+nk5jlnvt7w51BZRorhpuQA7UabDIHWkTcU6H6/lHf5fZpwBSe04Z/4ylrpqkDGFJDx+3mOEQvSjkNYC/dBbomIDasaqkmUW4GjmZvR8V2hIU7lDVVmV2vr7oqVX0pWDI20NxwRP74j5OCp1RbUeh6ew8rGu5umyFPXe/NICfiv2UIhTiyfViIvNp/16+4fleuVA7K933aFFuX1yBLsRDHl3qmUazATMqVgZFl7rWJynw7QohZz0+qAGg1yOSgl+naD4oMsS8s9yOabZ5IAxg3Foqo4eAS7ylCoiRmM+6KreqqHqFNA9VMd3qvjkrZWGzWFiA+RQgkdraG8fz+J7y6QUnapaRRKwzBV8+fT4BGz7REWnoaSKNQtfUNCCwnRmLsu1EiAxRbzqJ1pD2q7prTB0TUt20M5lCdrGPZ8vB8Gs2G0/vdlEEZKq0i0Q4B7sBFcQyqUd7Pfpc/jAIRRNMMRSK6pB1uOwq2WczysbZfsR2f5jogSwalFdAhpdmLML8AahkgoK9x3D7szR9Hw0FYwk0KtKSDWL3I3Gco0VYKBaJWvoj5vqHD38g1uQxLDXmbmva/ooSgYUalTQ6PUBsJi3kQoMXZDDWSpQJ8GQi3KVZM7jUotLrhYGP2rUuSiH3I1cdh8GGnaDGqOp8cajhk9UNXzGte4HAwZcFq8Fdyo7/9aolkA5MBawpQk6IGCBO60rm0FtahFbplSN9rkczK9cbDimnoYNazcERb1NJQkWtio6NHScOYV4Px0MkHBHyeRfC3s2s1IIBEXjUZasF7ObQluvWnPuaKo1zQhQqex4qD757bEfcLD6x4GWnCtKQr0GO7XLh2D4s3mQudJIVaiNRvDqGleFQETzUrk7uwAKsghOxrcAK/kKXifGYjLQVu/VKgYZNqoU5mn3sLb0T1S/nbSwBmBHWN9xuNQSGWnrsj8UsesyCmWTHfmVhO4gW7ZZvlIfssQ+GGm7gtA85vura9mFUFlJP+uFMVYSEJJaNRYBi9wjDi/Jsl7e77utao66Zwf/e+bMBud1kT2WB90OSg6ED4QaZZL3Y2fxTFCfrh3iplA2Zhx/dmgvuEyM10R7/gGfOMh3Qa9AT8Kf/XoLbdO2qL0d7hMi9p75MU2DzoUTtg0g7QSr7U1xnFDM+z0VOAK+OOudEythLZE985AxRvHAf+mufN+aJdLa174WygKiUeaBj8DXvtQuTg8EphtyNXmi/5SG3SslYMbJUgwKJPyvK//qna8nDsDJK6xJ7oMsBNcP6EcgS8Sb4N5uT1D3M9QDyOk0opOmBAwhUFI3FJXa6j3DUFMgneL6WG9YKZgv+euFvdXVROCDGg7ze/H4VKb7kK0vPJE0KIXwJEu8w/2qaKFeJifG0Nxc6RXNp9MgARSV1bVi/xSeguieLTUFGN+Gkkm+U4tLuTKTqo3OhJllLhkB0o8VjqG5RgrMliMgyNBfK5knYI1SWd2BuRQarkHbmq/KNF4XaNATY8iEcqwCFaFGK7y8v0+cur8mYrBmfQwA10tiazV0eQsK8gSjhrrYSQ6M6ZHJrNeFN1cri5S41R7+FoMyPNxp2Azy1zZLRa4BaYDLytVEc+LTMZxKFpAhutJCCaVoZKhS0qtz8JUGjt9PiqbEit1wQnN+Dz59wBKNbAq/Tc3zB62wZIMFaa/cAXhXpeTCNaEHAfZPSzrvl7aXtvq8iCui/7+UY71wz5UkV1uqBuPbv/nw8lvyxXYCta6uGApg0TpAjFeO5+RNnuDyu114wu6l7dLRq6vGm1RJ5RF4ttTvSKUMU6uvsf2IyHEcOEQZ5wnhN487MdBFKYoKNu9dvXGbZkSlsDdj4B2BqOTcKN+UBBCUJuPBKrazWrqYSDv6doNECQiKcjA1iEDQ4WPUmdGrEY1s/enVYAmIPGUaR+DslHlR1ltvvGZZRmw+KYc+P6RJGtNS80N3qhngzjLsAB2+en3vs8uNLg2UyCWNPWhjCWnKQ7JLVyxQpmB037zhR/4+BO0xvWCatQiR34DpL6aB9KB6wvGXiKQHKfDr9q814mxVToqPaBym1He4c2oRt8DZfRqOqipeGMUxJds8J90u/iIVv7p3/7x//7rP/3b3IH9GccG5ISkmTV88egggZwyH5ZWjcG3pZbus3h4RApGYWhL0tu9qIuYjoGSXDGueNQpPycfwSxZThP6B/8ff80pcZ2JiKHpmZ/k9onowSKUkszJFttYyTtWaSinsF15wmwR8K9HFhZkSwsdTR/wYLe8pWxq8gZZLnJlPrVDP04GuLTy5Xy/fpEK4yrEscP3ZhLLPuDCHXr4kQ7vWe9hz6pnOcyJOLmdlLHlbPDfWX7AXsm3qnFLG5d1pXRrA/SmiALPTd/wVzBDGzbkQeN6IZn3FCDBAwVmnes0xe1rcr2jvl5MINErPgPqEBJ8ekmSUKUbfRpjYezXGLowKQ+v56pEkKiGla7Bt7DvJaEfOraPs6ttpefespHztcQSnsr/dPDTT6FJRZp+Gad7O5HQLmJEJBW6u1G3bE53txydnm4ebaY77EEzyA/mxa++MHPkeA56KoecOmgG2LQGF9lPmwxE/o9Ae+/WU9CRuE9C5q6oQYqNk+lQjTw8ERFSz43U86aiCjhH0tJxhCwwwovjQMZqbhAl8m6HHUZMXV8LnEWZqcDp1bhbR2c5cDCTB4bRyNCqGwqI5ezHK8NgazkhcmQU6vqFiRf1MuQX8UOkJn1v64XrWBJ83gMAqLcghJnsu/2X6ngCKx0WLtujJiliZWji+FdEjSpNUCSXh3YurBO3D0L4LZnFsSEAX60GTpq6+TIVY/dBZEIKB89M8wlSreOCra8EVU0ER+v9cpvV/PUQzVqXGdKfXtGdmPQO7A3um3SARr90nwki2hmX21P18Ck7W4rTKjhOVQKeyeDH+9G0fTzUH98gtOAfOzy7SblK8PDV7QwlW/pYdSp708AnVA69LSTBEgxgebwHGGwzEl6PfmbMCKA+jEuUMn8/TAN+jR6ymuPUXO1V4WtdFB4G/gSaD/CYga8th0mTDzaoIZqkKKKdYLk2zL8cpYhHL5i2vzqRC1jNuddQw8WV716ErBK+QxSZOi9w+4SwUsPdwWU0553Ks12+WuEpAula3Bh3hzrKHzTga6f8NgqlHJez7ZFV7saMOU8flL50GOQ5ua3/OIIbye5n5UQJbXd4I8b99lFxAjGd1RYAqg60nM9d2aaodbNsjxkY7PZUberYJtas7VkPVTPc8JSR5JLMulKXkK1Xm0rN/iisP1OvkE9ILJBXg0y5w38IgW7DvpzGGfnupSIgqMB2MGmDeVzfnPr4ezlyw+j0cLvLQd5ai2NVEB0ZgWh7I1dV1bDypOswA6dKmDPDkKnhRPIPC9NfPh4js5HMDdmRlN0oLQxUGfK2qin1MCX8i4HDYMAoogE4x4I9r92hiQguu2k0//ERNERLyNV2T0ssF25k4qcXMNRAnEsv10UhdjsSN3gJY4bgb+1nBq4+3VoDS1mJI0aD9HlrH8+MqoZU2Ta2V3nTQA9OPukQBvGgXmUl1KHUdHpfCeKW+7513DE0p3DdxR2wH3xL3X57SPkBN1xWdBEBz8+5DHh2pZO0gNK3B1t1ikkaTVCPhHUBgzsxpU3wDZdDTMCL9bo3Q6Hn6IfcBrrq8lIRIru2oGSRFBrUJu10itAZCWB5Mu1YwH9ru4vrGF7DOw9x80i4WRqMkaqQ0mwqbhlqtaOynw+c8GmaEEseaalkoWDIHwAISpcgGYoF6KdZktQnTw0yGekminIDJKBlgUTF0Wo+h4GAC3R2gKrFUblZjE1J2AAbqGdqh04cRlJa0yiXK+pWYqgVwkyBYbFw6QnRsjLX0Txp49CUqJQq4fOZtHATRXJLkeW0DOSjcM4MDQ2U2C5N7LtQiCRqRel4aYWM/3qe0VRf4KwqqkE5D3po7wXLqo+Iolzpobe0mTxqZWkhpNNRXZCOLQt08r3dyrj4uBbgKoZoViFZjdvl0FgRYHLqqANkzHsRymUsvlXy0eJglZMFDNNVziBrKo2QCe7ttMNT0egZrgMF+uNKi+Dk4eifll9flobcPLevw/koamk1AOX0plgoCRJQ0Wpl9L0MVEUkUALD6dUNTwxKZqV83Cr5Hgio7P4IL/jEwZaR3nTdfMYeERqsK41uEZAGYVv1JshxoMWsHUEBVKJr135vsruIQtCnfljY7T7fNDfVEon6ZdSCmYzKpFBLG5Y/p2JaJYtBjblfCoq5BMgB/LoT2VQeUkIvswIJ7/KQDr2hCshPrjl5/gd6BbOvq0IaUNi5/aoWOS9vNnl/qvZYpp0KeUElmJ943e3WCnrDjgYdtM0flXQxEc/cjRPhqFlCeZoKOUp9LwvoEwRqfzeSKtaOYh0vPreHLOj//Od//vP/+q//+L/+5+M6hhuVpokNJ1UA7Vmsj6FdFpoGAJfcUoDevDWcKtlgpir3B7ZaWUD0agek9qXhYfP5a9DAO8dpwV4RiiDSR5NIEw7JPm6t4chR1Sjw++0HKwgZL9NNRV3BocncuMxew8H6MGndfRNKvfIwDXYPepQrYUSVOGLFH/dFQ5Uh5AaRYNFqgMBSEADEEVNrE43mlNB5SPdkDX+cc1D45Yoaci1N/inA+exMhST5t0qsP+nZm7nJwyKyqaeAlyrd1badmEHffRxVevQ+FtYyWsFLd4C9XurJdQ2nvNYMJM2Vff2oTu3HAwSD7EgwJZYbf/jFKxpVBDk36cYbRHX7mpGwZZGbV4QZzU4U7pW2cCsjv9fF/zqHiT+LnIoqTtBYWm3UdaNiKfJwV/vLjRq5+WdVNcod6BGW7UJRcn1jM+Ouker/1caSSMHX2Z/7w7IlopwcePk0Pw8t+Y99j6TsQzuBCZXPMs1zCQzlMMZPpHdMDwPVpYWjXQogTKNbJc/itb4VU2pgoNMwhrQxjTb+utCg7XQ4+LcS/T6LFZ8bHVXp656a1rR5JfIAYt3FZuhEFpV2cYvQ18cj3YhyX3Z7cQxSg6wS54TReHIAG+6lb3EaKQ+tJO3kUN5GoNswv3SelZQrqyOd+bYa3OZFA+ClXj6BrpI9JbkK+p7w7coRGIdz673417z+SBhQkKgZKv1eU7FIflbLFwnJ2loDYejwNagF5inWU4gvGt0Bz5Xu93J6vbTWvZBn04aX7D3trMEnpi10X8ObbXtcQN5eRDMkWyHKkw0yJbNon3hOC7OROTwQy3IKnKjors+LLSeaQArvukuXz/W/9alqUnEC5Hz7Wc/Kgk2AkTHa90yXRKSLtdf26QizIbdZqMgNiwzW5QzhEoDdjqNiv2GgmtUhTYXUGgTOuLQ6bmpPGE1Zx/sYc8Mvk9i6Wovw5UhPrqX85BQJJrMph40ieLeoogrLN01mlkfow6GhuzqjhAsJpYdHzv4eSuplJgGhkdMQrCdoLJ3Nn5SDjQj/0zttM+WES374psNRU8AL1lwNVwKbHbnsEMIZVFQVeDAoUY62lGoyDy91WRQRL72Hk8dv9xky2NS6qmkLS1rgIobdg/ZKWQSM1xi6nJaFTOzigK0OeDVSK7NvmbBFdKdceBkpy0GbrG8giSUlADkx5BTtChCeQP6azsb7QDChYOVvS8e9agtCGRyr9SVZ9c+Kcdh3cyqMqIe7tsodSFJm9UR1HvhBfDRhypwna+37xpaIm5PKsOpagYrg7e9spSQtCjH7je5zWB1YghgPXkvugPsLPo13l0PTmxVszyi3bofKynxcqveoZFdaZ90oRHKRG6zKABy58/6mEIWaDFmadsZRziBnKyZorp54xtoKf1kEzXL1LUJYQHzxDC9DNeFq+rb6IiQlaqa+PThI2oq8lbnZ6XbEO8jIkl7lMFlmo6rwl8/oMVvpfJFbD23CUT/8j1X3DtKFX3RU/mbcesttNsgEgGuQqUYZv5MVA4btpL1d/XyP5KsAC9CBM9olmuUyU4u1ujYN4IJbCasc1gyqkCWNFaJBFLKnwUoMXjNM5ICSARDu41j3dOFrqEv5evBV47JrJQ4BHtSbcttdKxMT5W6Z7EvaRTJXdahVvoJixbrm83n/Z7jU0U3FClj6NFxqNDoderkSYQxZyfKXXxMG1rCJqyocfwOsGbJNiv6WtEdibdNy//VgkVuceL4Tk2QTU4j0sGSsgiDbOiFa/yj2/HpfZPWStgOOw0Hdz2QZNm0gxpVZCJCGJFxGyywctl0dlsKt4AcwqF7DYqs/4JRWCn83oUhroNoxUC5Bth0pNjbBHcmJrJJkUWUgzv92ZMpjYdllP7K0hhYKwrA4nOb7N5BPLar4OQSANRAL3ELjieS0YDnVYWL8d9+HgR/CzhA65chfFA2afxEtlNUc8y/e3k1cUIO1s5wW1Q7QQwiTj39yjq9klnBbNAoKqx4oe0E1vpOwZY+T6PvpfXmcy14y/gOpKoJr7PJbQc+JgFiE+0pjqVohGgTkWxt/QS6pVTIazUQIKU/cx8oZUYxIwtOLmDw8KCOQ6ygfFb56yuNnH6VHTNY5QGdnWq/aXGfh3/9/VBNYU+6ejC7qfhoTrNI78KKO4nBVhfz9dKx98eUWqUMSI/6RLH6jLx7GkV2hPO5OdY0Uey9Z65KHNkIuxpNcFwPafPpUVPOncY6CC+ATjBhWMYWSPkqw+BR6/9tZY5d3CoNSGr0yL6ZKGDweYmLJbXx/+tOz1msoZdxNQZX4cPIAsDisiiZbVdb3m6YiOrK4KtK5QXEw3hNBEshA3aLZvL3NKuHTKFvJifADUo40rBEwM+1ZuRQjEgDnj1qxPU+TyKKJIKK+cTE9pU6RsRAyv4vTWDR5Fm0d8p1bZi70nC41ja84KvenJYunS4aE218O3Qaatebv3Nim9d1y5nOYuHa8Co0C1bBc+UDpfoqV+dNQxl1oigvYb8lMB/OMkmckXrtGg/zcpKoc3dfge8SXar7fboJD5Tz5cQv0bb80UUfNaVErU89LeBf56hq4nkg4PI2tdgPxP46JimCi6V8P9g5oBI+coxFi3cfJKRtC8nR6YcB88+PkVGNuljjJlww5flX2jMUcbenJ/RYWwbfW0RjGiefvvDLtGMkhnCPXZx4O1y85SJBPdA/V7MP3YcvfadD88bJEuHgBQ9AWkm9/xQdJeje1yKvMBf/S8lYAT2nOAXJmIuYtY3f83OEdwRTMWE/fEbnjOsTLZQ1m5M3MZPBbfl4pcnVAWmf80tv/f82d2Y4eSZKdX4Xg9c9EhO/euhzMCwjQlTAgWGRWFdVsZiFJ9iKh3132ma/BPzwy60qam+nKyvL08MXclmPnGDtgUNqVkmeE/WpiCXR7Y6cF0B/Q6mqpVq3obqrCkGfW2QvfF5wtxMWuV7cwuzFE1CdauK4ZXfl4nsMhI/vz/BjqAONQATiHPlOampTltzykSmlqMDxbOB0OeN+g1N4puSbEJFu6W3wWoJW95XlVoNLBkG0erZ0wQ8jM9jQkp6wKKec/1XjByLL8VN7zSFEZ3N5Yr4B4f9TmZnjZcpKYhzSCGQAIg8BIsUFwfNEzXytyl+sH4nSrzkipOUxvRCEgANMJoVmrwJzFHzoUbbm2unc7r6kHZmz2xulp6L+bs4qLb0QoWq7z0M8ARdXgyuQd8SYRD5/pc0/feEXpkJ3pZFEAcNAe7xD5SnYZkYLpBvX88IL4waB2IVq6sBAzCS0Fqjoobu9sL3+iqMzwEsN4sfF75/9TlBdYtEpBqPx74oxcs4foUOyCpf6rgEdo0VCy7AI7uJke5VokY/XkLEcinzEyt6w9aEwmiS7URjy9KdGua2CIMyeJoYDrTbBHcNEe/kfxC2rMA+/QAVe2mpXYR9/FesigyS2AuKu262RNzsnLK4/H1Bp+NtJPyivyvuB6uIFa0zz3Pl6v6+Mmf6yPpuTP8mn02nTR9pujJ2Ww7L9wfGVhKFLV9lQ4lxgiAMvhMZhIde/vJCBced04Q0WwGgSynHY36UjJkd0OZH8X5qJQQO17p3VDjYEWu36fxDeJ6unmM2+Jln5yx8TSyk/qDjz4QV0LMq4Ul6wff5VGpfo+4DmikKZUAj0Vi0sUwd1vUzvCiWkBdhVa8VsL4gBLs4EvuNwD1bijF0CMYm0dW47lQNvunRzzHZrIqFy4riqrq+vtaCPwV6sLVLAX395B7yP/c+vWBcEtGvTyCAcuR8uIHPtSCpYQRH7gpqRIKbkQNO6dvOf8jkAmM5gYqZVapZfx0TXGY7HtIISmmHG5aKB4t847qtyo8laHqY3K8X7tgCRfer9kNIe6WA8I0fIWm1BLW5q5lzN9SM9c3je6pWhR7009u1al6MyXfdEkkL6RNoOPr33dq1UD/hNNx4PB6dT74QsBonsAaBs7a8xqpAzJaQ8k9MJi/jufkbaMQyhPo7BrJvh+JNBa24QyKLQgPNldPVorChSBe8PIaij0dGKT4nFKyyg+Zae1z+J55YdD6nlxJoiU7OR5ERpu0DpvsedbvQrEhQOlxmsfVvBLYnh6GRS6YEO+oHXWyDoQfIvXfyyxnn01cNdC7lzobKj1S4jevUSlCkOH9pBKP/1qkNFDdZyvBhTMm92E32FVoVQUKyZgPVSnwdtLZ4L8dhX8KLif7KCZ2uOsPXd6pQhkGjO2Opik1NHsEMdeOU5vdtMusxl9dP/Yc7J9O40lm5joMIVRsKrVSpSeYcxrOtLxclY0EJohdMs9DzSkt7fNKTTA92TpyjVyDzOmEBEY1Aty9bmq+5zuRFVeedSUAHwb3LJKAzW3JJYXwS7bdOaJQp+ifMjl2dujthLIjoYqqQ7HKE0FucqymHM3AGLpgJqyLV0YWZ2KiQeD9BQdea7JLMTV2okzGKZkZ1DM9AzRpOveIgHcpKhXI1HF7Dx4ATi7d1O1vbBDp58oXc++TX5hSA8RivN60BzROftvTruI5J5VWJm7eAEcZDq5092oF77DkgSliopQKUIXzrAQ44XKgg7l6A9stBGUcsQPiIjxVEg0ZL8H7dPzswACLnbYU0lVOiroFcGiAHaoemTdWda83EJPp5ZpXaWapngwe2vJKly6ePPuQDm0mhXUYra5e1FLQ2HuSVLEMdOprpS9dwh5Q9hluFGRgT84hIjNIEOIAqW41OPvyoitnwbSLurJiGJVmTCZCggDsJStOXO1GvLnzdZ0DrQzX5HgzrdGABkcdiFzaKE6scGU6YLsRFPSuyGJJxc1bk3bXTyR8OBmQ31xDD13NA5KY+UpJV8wkX7IAwsoISLlkaO7eGFhkTpwKPPI48t1dXpwNKSb6F+esGb3Fw6k71T729WwBzRcpiRTUGKf3oF6dYQy2AnXsnma3hOvBpxReb7ERdm01chttWXsfCtVEXGiyAHC5bPvspuK591ekhrWFgVyyb1+gNmVdzhalIiKnB0eJU3MZp+oThf7GIAETOQMJGfzkAxnXp5ieM5XBKxlHHm+a2sTILGA7Cn2WuIWbdhQGTp5x0K+RGIzFgVxR8K6AMM5Rjgi4p7Wii5Js0l3e5mq0T5xO+llwfIFjs63WVkNDezIAy0IQeUci9OHonJhPlLflOMeatmbVHxAoc4Ee3ibT4eSv+1k26rAMbR+YoGNOGpdOQ+WtigfeNSTuTtXEZIUdKULH+1NeVINEI/SCyZGzzx0FuClPxSV1tFV+6SIDgOadcq9lf5FJztR470/43iQ1uLLmuN2E6darOaRyxMBK0vJdK7ULA6uHsqRciNulhd/tGLteDZyOFwVo7JptX5DdkJLau821SAHtdSSEAp07aXw5TihcReWr5EthTbTx55xRPcxj7t0ETjGoiSdujysWlLrNPWgWDHVeeRZs63dfvmBuB+xn24m5nCR9saio9Dpg2T84tjK9NE07Hk60PDi3/ohNovkDCoItkfx55MCnTJDkG/KTLx1ab6bg8/jjpVgcRaoWqOA2JTY9PCS5JSJVpVX2Q8w5D+TE6wHRB/FtQ4nZ4GbzsTJWixLsW94Xi4Z6mdDAwt3TZ4BiWYbp7hmy4j8tyPe5/5pSyplKhMxFTtEq7ZSUzZvSF5JuHZ/Eip/7R1NqiScNLgrRPU4val121HJRGVxvK1XL6dsqNlNlQPhv6V0tdFNYFopMyAxO5LAa1ihHnXIHUxnd4iqDD6U4DBP6C8dYF3nY2XiKXkbfZXN0wdUdnsoSxTBJdqVt5lS7f4YZyV076GssnOJr2HcRGfPbTsQfpycEjQ8ZbGIgcodJVkhR6y3e7qbVSXkHOyhPntvyOmxHwR7BaYK1zsiPehKGcR1aAKSwKDVN5ez8vREDbSBAdZxeANJp2bypWkGM5+OBUf1tvV2bOiuyHTKz5r6XWbRxXofNetOFp1AcfxFmD5oJKDU1vqD0dmJ7kgB/dprkJU3SR4FU5FzBk0JWQJTg+bqKhszOpkvfeXMQxAHexMZOpsb964mAS2E9ZY05kQjdra53MYGLlen8YFKb57ysgahYiNxa6v1L3ekvutQCsuznobiuvavyne5o2Lw2VZklNsbOY7EFMqX3TwiT0jpNWJvbXGnlo2EoaPsbbbaDkJLNlTY1WPOheB+YjFe2FtGarX44r2iyCFTsC3el60DYbWPKth658BUZzfpx6ssJbj0HlmrA05mkQbJmbLqbrFoBiTcAGRWQhqvify8+9qIhUiOYT1TY7FeDcQzHAZi1tIaJLbQhcZ6K5salQDmCE89XTB7IGgDrbJTuRqc0zh+FkIXs8jOXdwmoAL7DGvUBMiRS4qi+KwFtzTd1CrAQpjOhvlODq88iLRKdPFS6+W+2cbzeD0cd8RxZKsYoHnA4fU5N8DbbYe5YmKyWG2J/FfBD2c5wHIU44T1UycrVMqOVRzFQHJSt64RojeBJgtk8ZT4GOSsldMr96L2GK2mlJBZ6XwBEhlEL6HBxMAOKCIdspv3wxCyJSxA3UF1CsgYbqZ2OSl6TElctlgp01ZDYejBy9TsPghOtNpCHjy1qO5BrtGIOs+LtZSegfGIH1WRJAY92gwDmytQLxV5hS1aZQrTikxDh0qgbroCzK4CkOJpdK5QLXUr+YGz1SV/EZbCfwJbltihqj6aFS9OJb+mE+T5RNwDactQbPri+UR3wSGH3KT+VKWmUduqihlKX3ucqGTPR6EFrWOTyEGAHJQ3uTpWcnt4XrdBxrW+PYSskEZ2alTuol7F7vep+zO/fatjDywmdz0oig0sjDwrqcMIxU0OD4PO/8p/p+qRyL93pTA0p1BhDql3sSHwJDtsOpXtxXgU2aCo6/hlZOflWrgeZVNylH+MWjkmLl28dBgYmftoUTKGK9gaZrRmo23BKV8nu2Uk2W4xL6GyUN4QdtYmgKZxY0ophJgnT994v/qGom2OQx2MO468j0fgtbaFgaChdtkqoatZodUzRM4JXD1uXmt/K7hxS0Q680UsF97BhWb3RtCH5Bu6v75JQ948yPQhQXnRvq7DgScZhLLUtMhOiiu32Uq8voOaSROJ/uI2wfOOIoBX+YgdXwyNDyjPgsryKSqOJnQIPIbWzNmiOe7a8AzcrmT/cm8I+CDpU6QLYElTsdjrkcTkVJQBHQrgHXsBvSlcUE0KDR0XVkMRP7uOGCzfB5dGd9jh0AVH3NvrliMFnIBUy4a7vNDmQDm1a4uwtpBUTcOXzauhCjAOmingEbExGxqYFQEFURDaHX5uzl8eDgm45Cz0tD3uXyL9v3edOIdaUex8FOmFw5uI9G0pfkFwoRgS182hOMybsq0dU6Ln5hZkjPEhN4Yv5d+X/47LITdC2SUIx2Rva1vWCgzMWLh3rsfTVEbQiJDIwlAd806zouhUpxdymWr4BiEEVLGzxplK+2XVtDaTtMO9DaJ7z8YpXwCbMYx4O3X8Ktsul/bhAEG/Wi7yw6PXDdoBWcAwuBRUocohRt6Uma42Ewhe0zxWXzEoHlN+ODq9vWpwdpxZSpfjJSBio3+RLJD8M3p1xZWF1V4CWXDthozo4p46fH8P0W0xOhZY7y5zbaVmwooNEcLDJbh/miiJ94wcIC4Zx3NjG4BQT1xAy6olHc1qJEN3gZiw8oCpdlZLbiiiEa4UT33cXkgrMRBwXGs6sueddkmNHjHVM6RKljoFwZ9JS0PS54YuOtVUWmbETuXOrVgEhN1QGFmQ6zFYz7KWTgiUDMOU1wSrACPpbirlSV59NpZowqpixTKVoZpZcqqnitXNadds4HInMuCZ0T7gd5Wrzl1aMjAUPB898eJWk+JvTWTsKCVZAzVQr67vCB0BT++SRedjcUThVe9oSE3YwunZ/UmjIawjr1krbatlh/PCTFSDeFTQAASofQ0lpJsqJAUsXMkM5NW0ZGvk7h3oEaGXsPtggKGdTlxm0zChFzYIyjRouzsExEIA7XY/ZSPgTqRiMxeyFibDo5hbU/Qqea+0i+If51RLCko6HdGGio3MZPWlYWIgsMrDLQeTdJaMpjlzpZzbDy0cp+O4zm6Ev2Eh64NlB8eoSEtp2C7T61rqcTVWQoB1a0J5ileMYp/FynaCXA80AzDnrKS+WC/uH+xWppOpqQ67rLM8aio4oooCpF57HLmIEXnVelWKpBK6bL6rQAA7Bn0dzOj/Xg1kprqfdhioYp+Y/I5JVQolH3sS6/ITTZj7NNXS2lnEQgbbj9Cxy+HsgaFUy90RJGULIG7FAZKJucK2tfpMMjD1CABcgKhvIzBooEQuw4bMeG6oGnfuGDAUD1nL7ROcBDjyGj2NPC9QEMs7Wps+7QtLRguiGPxGiBNJP+1pmHdldz4Qnq+veFB+HTtIgBy+LdJSLTXMM04sLXeo6AwsjxjZZcd1KnZZGU3kKgTxgapcjgtFksY2DoHL78woGQ0HQ06tjObCKDwBQuHS5xomn4OhlOyfFEbLeSoXpFwaOf2d50GO8gOQiKOe9CtfYRhGDblnU7gRb2J5oGgKeUi+U3mSKKIKz50TAJSR5po10sYBnp8qrL3rwzkExFYfLCF01x8Sqxbl0KB51vXJ5BVwDyH8xHh3ekJUtJo6foVJq3gCmpVdV4zqtThHYRC6nz/msLm7UCUkNStFY6flYxotu6JR5BCZvVGqrb4QJkbXuZwox6AzCTS8EQYYQiw75RBXySlUqOmRaEJGKGBqzL6hv6wFWVowONyV/LLe0N8/fP10N1QzLKUYHxBOnFppVOGUmTackVlOysuC5k5HA46SBOXUtMY1l1BuM63ucbWJYsq6fA5vb3wY5l/LmwZJjL0zzIXVwkfZ+N6xJQYbSqZNNj632p+4hrSr5G1mH3v9VRoq1GW9sP70oIt1CaqorCyqdIpvBTKymmiakRj6TnkzCJ4l0jzw/l1YokjrGHwtBeqGwY3wyvVYFlMnLx2uZGkaXZ3/pD0DLQsKJxnsB4OthI3xkPzn3FsVLicmNxIdeFNJUqGm49lKE8pHGcp3hEovNId0rOgGJVZUQuSJ6kpC7Eh8cEQT31uw9ADmYS+MPUp1Q7++3cBq5CpMWyiaeu9EWBZ3ElRCZttSZYmnG8/yeGq+QNOghE8S4Vednwsq5V0Fini/e8JXdVfBnQ21PXkIgIKVBNhV5yzDdcWw4vYwPmQe8pNCgFvYmmRvG39QXH6nzL4Kv2jopZpUBLPWqbqBxYQjSzMY9c63kRb+HXWKUKkSAW3LhTUTeQfpdjuIQS62MneBYa3yIl8MEoQiQCqJ1sARNrF6xqtqh0pkd5cFuRMkO4YOImGwgTNw/OBq3bkpUwc3LXu7b9tajMb2QB7bpEo3tlx3MvSdG07V0RIsXblR5wARcrkHFc2c3V/urHL1rvFNGn26fXfobjZplfAn4O/9C4L48rEHDGXyqZxPzKXi7EX4IV3CrXlhk1e+/dLIpjwolL36TZb1Q9LEQRf2MhgAcYiJ6BHC4wyDSn07tS4B86zc9kOl8GdzT0b0+fHO/KNaLnfHVZ4drA5yxnJFGyuS3HiIY72YWVeaev6UqwYpgnHt6dvB0/dmArJ9tKmAnAk11j7stg48srpjyNy5o4viHuWBmlXwZJll8ala1rrV+c0ljIKRpVJVR+U9NQf0lfjPkSqhWIYZZHu+U0Ct4UsYcCgtNfP+zHpBOzmDoQd4/prKWIAxtB9176SQEdtR76FKfUa4wby7yg0xUoKJxB/kQ3AdR8+1UdVQ6vW18PAi5STjEkK2jEkJZICA8PYUpDQztAcW1tUMZ/gw/ySGeaaSD+yCHKH0YgZFx5KLKiahFiHYFdpXZ6yIL8nrLjm9sFamFOnd3iVftUtBPIlOZaDy5nILaedUrtxTMqsyEgTHTaUAEURHnWfbKgJVyZ9VwzRttdfdrcYiG9HZJlRjMNJf3PlLrIoF2u3IR3tn+symeNDRPIH3bJGLT/PB25UdXFwcMzWHnK5WBqAUGgcGIEjYpm1vJ795srEDaHRl9wAZ7STGK2WhorZkHDkpoVEMB/SHuhLeFXLDKCqhK5o3Rbp9IPaimjmJ+xqk8k+hVgxWUyKVoXiHKh8akq1E55XDJW8dxnL56YDLJ4YhA3g9zqUIi9p22CvgtD5J9zusirHozzZojtV8wEyMbDmcvWNkFWgZFf5wyl6Vga7r0zEkTmBXhpgdTSJtbX7ZgDAimMVBA4M8ZZheT5V+htW8KeieFyIYaZS5vE4NFL/vKCKQFEmpmPYqdfGa6XXpDK1tBMavtVu1IpTraNlvItQrKwIODaB5uZ1iRWxUwqMwep0scuYuYU5D1ww62wNwRYxW9XdhUO36AhSovGpGgMcYPuvykGH8xLS1yw+RGAkTFFQLLYpYGHp0eiEmXd0vKKuNfEDpqfQcTznEselHq5ghLPYhTA/f2TfiWlKTbngqFLwmEUL57Ki8rck0OuPz/DBDQZU2oFmw+ssndwZ5uQ4Ky5TdqOQci0mhcix71Fn7yMtjJEfT1g1Rd+TLtnwFgIToaEeGq9lX3UIx+XlWd3CIp4qH02KKq2002u2GbmQF+mASTTiIKyVVu/aduycv50btLLl2xB2wXzm2E+FCgKuKAv6mz+m+GsmpKtzWWJuD+CpUyeoOlrY8XKvO5nZ1uGD/zmKlt0olrzx1NOs3tVnlUgc+NdyGP4Pg5Q8Anul0KZpgy3N6UpMsI9jwf250+r+GklUJgzk+vqVDUsG2u4m65mo5xIiJoe0Er2HnLbNDmeXmYzg2IFyeoCHtw8sCtlYin4QdIV/Oj+BCmHiSz+NXRspIbjddJAXfAFw2Yxm3AP57yGydxypnDJOMTzvfYM8kVyWOtDibTflXMeHmrkhwf0ItBcVoho/p/MOBCF/fWKPyj8e+v3vrgFD6xBAC13BkayYmPkdeAp9/2wcd9etCNGU44W0OVehIs6WwP4TOrCnG4sHPmLDVRPeJ8xcSAgCtkEN0r40AU/W/5JExA+1z/+ZaehhhR8gV8fiuNNFvTR1S7zhnNVVbsV0xX8h45Lf7/dKXf1J/JOfgnAqhmKh2bDUt8H/jHoELdGEgQnRSlizuK7gD5BcPfKVowpkZrIZtRVcVavl9wkrcnzf3ACXLAH+ocAkM+K7r2PIWTYH9ahOVxy64juUk+t9pxAutUVTMFkrScsz2ocu+uPyyrGjrpnb/ccI0BS9zq9UxoIo7Sg487FrhWqy9oyAlmx1boOWgoqahyobKmEVkkvaRmFp/ZDow4kko4RXbsJVQUe8rGg7imdh9PN1nk5Ij2kVeCS+hwhYL1wS/8g0RNLInvjb4rHYwH1ruOVmUSYswcdGVRErM9tTm1cnyD7BGwGTXuEVkYrIDU6vUTWwIBTjfkrHmcjjXhZSNVvrp+gt+TDfC9DZT3Z5/JoKWtpl+BQTCd0oucRAEW3ldHETxrVR4vokIYcpB8p1r2Ci09wBchDQZ/4JvV19hNSugvbm3YGAD6c2jEVPF5KjzPEydhvVa358HwB8HbsLg6R42Q/NIDASYBN+cr+ttrCYfUFXrJJOQirIUjOSVA2i1Pt5MUEuNdsTvJWPfv9Mqfmmwz/vlUIf0vna/ZzdqENo2wYFNPYt3+VnAKPzorjRIyG0Qv4s/Ty+0HAvST71Gs6ivykgQNNnBdRU0Uub+d1MoX/owEP1rowAp5kwelWFiqBOqKWD0ssVkW9f4sJYj0RTZeZs0ooDXftB1FCTZ7nsx8cW8JHUMC3yr5qATVitD2tgCFyTgQJTU+3C1A6R0Bz4fagSETSn12q3IPNwMalipS7OsdgDGaHp/ejYb/tVNjqjrmiokEzipqdEHrVYNZcF97yqiQBcCBGqqPbRTesKnn5I2q4FAl/leQSLnvzl9dSpMUDXGxZvp2pHrkeS2NI5OWiZkmRKiflUvgi4W4nY4eKtC+8uhP1Ve3zGL1K30BaQvrNLCGeWFEasoXtiaAJmRSLKYWBeN0F8mlmD/bs2Ijr4IFPPSrHpw/6lRke3R9oZ7akpDfkip4Oj1ZvA1NoNhYFAH6lqgluQKzTZ3ZGoaAXR/o9//M95qVFkH0xU+SSsQak+yfUYdnSH+el7DYiR2fqu16UyLFP3a2XWpWVJ2LzLHoYg5ZYfeWboJZD5zcZqM0T4c6qtwiVScSfUScgu8ylv2UFTfFEvrVmholyu/V691h5tr3YrmVPnoznVp6aOflEvWJwRKN29GU7CCIaCNifUgI7xosg8vSezsIN8a5kXvuTh18gTnyjHl6Xeeah2XdZEE0EFe01ihOYRax8oLL4D4xx3Ttsh/JbhGkJnraA/q79TuTW4MhbddNVMkoG36v4urSWF7VEPlATiwJu4qCinHtUMj0ssPgGYI8t6lwAPt6tCcjKZsCRfC7KyvPpSuN+O7EdM8Xx4sX5T9aB2XqG0g4MsE+52ch2vpoZKq5d02E/YgKO2lP2hSrE6FmFo3Kbo5p41NSPE25mQHv59s+LFH4ewjoVHy7a1WaCUUr3toLvCNQt4GT2BSdtFXmG4oLnKa6jPawTPXuZWJwUwtx+cwQsOT5GYRYi2zHppJPbXHDq+6vANZ5Wh6o4X6QSF3IWTFiMa7TbhfNOX47/K6yh5u3NTKJ3fJogPb0wWrXHIGtj4zTXvwhLRFNbXk0tLBp1YE5gq3YJSbn368reLM4IMV38JXznmvMRYxRED+eg0zZqSZg0WCLAoWKCXLSa9K5R6EZ4QJdxJnWS47Ylau0XXR8ya2MckaV4IpuVuQ9g289qpIiWpATRUht+MbIrjGp3CjiQtei6FLxzNT9RvaM151BMHop+6V48IckpHLCck72KizCsAsQxRaxWS5iIE+vempuj6gB1ZXca4BsczNKsTunoJKqGTNq0/0QLxH6QS3eNJx1h+B3/qpDHhucLQmMTHg4L3evd7Qakgo/WJPDsjp0fYBkzrcTmILu9KCeGNQI3OhZnmEu6/UJKmcyyajcXtnlMqgkzPrvIhrNjPaWNYzs8rWI9avNmeo1zSzzyqdxz7N1Cwntku00oFGcoEiDHBTzUHWK6iAvLP+JTiL1Y42O7iexeJl6sq91okDq/Tsx6LT2cSgVW5H1ugzZEGelE9WljWvNIp7aBHx8lwwWppeCp2YTGs6BmJQ4RYeeoPrFeuU4UbTCCgDm/7IyZtNwLRPCp3LcSDXN0WkPtIqunPWrKmUVfG2WxUO3zwVrmW2g5H8gO9xKsk0pYnxoFAdmwCJQxqdumdDpcFpVLIdMBHnnt2QhYNVovfkLHwvq10noyxniBsQXjeTfp2FiC2YAxvX+fZRLKOwGIvzUrrt8lBLK8BM+O0kYDgoXC3O6c4zP/gEqAwoKcYI8VG+Ebt7EIs6+0xxznKXJud9TYhqDm45GJNkSja+pG3IYPJrZpRP9SsDBFhxIpgDfAMtV6PYPrf34u1JkJjdEETDJ7QM0qlFKhIYTtV9uybnZjgYKgcQC7G3ePDHnLK/dijNaskMhJ9heC4aduxABTqtvwzFfozGhKuxjJ94FADjyXptg5735rLC/118mfSN8Vp+uEhvi7cq9mEwFCHc8goMpEUlzaIVWfXVvdFGuUGvpNPC02idZe5yWgAcRoaRdKbYYy/my1buB7fbh0NacrliciRSqrQ7tpyxNBcI6AGZpDivlyvIJtnR0fxOiUok5BrqTLeSbQaJU8SgFs1xFi5z09EDRhdf3htxCdtDFAr0+hVc8gzWsuzvuC+2SSUUS8FaDQike32+QgdGbjvXWTrZaHnYxhXSSzXlIS4K1QyGzksBQWgXE/FBOACPAm3xcyiwHs4+oGo7Ma4j7k4P9kBLi/kmyIwIM5Vren5MyItOCc6kze9y+OV/7p1aAosLNXdopZGLo0JGzFEWKu3eylQPW9vWCa7k4dQO4SGQsZoazULW1F4eLRs56gaUBYrXjnIxbkicm+5eWTVmfKutiqGSuZIBouXQmPowEsmhwi1/M04KrssvJ/sk0UiT4OOtkfPjJ2654KiQ2PFcXm3ygU4JiTYYaVH9bchK0lwTmunqnsjd8CO/rHl7iqgTI5VD2gmV75omNMu8geUXp2JjsS1M1sD+1fItSn8xAUzPrQGE51PjdNE4Q5WiCd2LQyGPI0va7MH5cYGvdCLy5By7A8yOUrLvMqZXuTzGmiWutPlFPjbNouAwWmeZVqtzXGwldOKyELl7NQ7KD9Rju/ga7bvoEptt0jVYzq5fAa1IbOSOw1SHc1bZrz2NpV1uYbGTE6lyWTZExWVmo3CtfDn0wuWD7NhycuIOVwqBdtTkuZfHNnTFMAd7zdBEv5wf6Z2p4ATjBwRWzeEpDyLtGGnucl0NJje0SdtG9W22MBed1bXZxYm7zrkzUh4kBIjUgD6RsUqpSkMf8Za6GvcqWvQPA9VbasfK/ip32TeFOu0bArDeK9PnqDbrf6bRt5BKBtqUO3giALyZNADWR5Z+bFmGesfjTVk4D+4W1VCJ3Y9O0mttr5IU5gnKDTt7yGEI195kT8FWBjsT9d0vIRrgh7cFNlW5Zx33RvRBj+mBS+P8o6F/7J0qhWKO8q3c8L1DbJUS0vxMC7e4DEAw5BjU6IUuHdhAzSS5I7vkHqZK4OrE0WyM6WimHovkEZTaxz0NTkHnx0zA6kuj+ArHfG3m/yr1P73Q8h70wnFcTos8rK2d3pEzZ2e+rCpVPlQSrieVQKZlW2J1hUBqP6PdxVOovARYP+gdxGNcQzzJRgBm7sUsKvcG+fNOHqMEZeCbK3DXXp4LII1b7uK6kIrBvjDzge9KKiaWO1fy4POZKY3kyFFRUpcT4Wk/rHh2agEu5YlN/Xzt48MhLA7a7SNPSiH7gkLBkzgfQc1qmDTafksDGHnPVhWtvTROC6p+Bs/dD0UN23ZWIoiUnN5OXoSa3r3tXmVd8+hyOl8nJCvtBKK+qc6BPEXNL1D0zw6Wvi74pe1H7DlObAlGtUGUwL2rqwLW30GJTUHyaw1agnl5ahIgQKWLIzWfxBWd95mp/8JwJO4MSNlQ1eh4l2lwcKYTIN12OBoC3LcFLWRWK3nI1CFjIEaHKkeoCnx6qxLXqg++Gmr0fwC0oidKdqj0bRWLEWbjc7oVlComoif68fHzU4MryGlD1ucqpwYJBHqOgwWY9dnA+UjgUQqUetL2oSm3aqmSsRz0VLERpygXKBVN2s+aYUNzZ4NLshYE4mosL85+aoENQPKHIk3bYmf1V8STHdHbaqEYjGnndmrR6IoQF05r5RB96pSe2yLJ6sBzuikSuZWe0h26p3YzGWpWmF6vfVNEVu8HHRwL1qLnEh1Cqr2h/XyQXf4UUiddqAMKckcurXY1mpLp6OC7pQFz9IuA/q2uCfT/SBd0iFtR0rQPQwpwffHg2j+4umoNmZI8Z5VNQL8PtON+yE+cTSxPTywrhYREK95iVvFe7NT2ej4OShPDm1Rqlg3OGdc1VBVZFudezNVI3O+549SKXxEmbQh5NGinRqJmEqY8G4nLYZQJoBAgco/ghvGdikvpZ3bSypUb9iL1pZJWzpiJbhxKmtkVVkQMQsMd67W8OfgIaWpz04rO3trzFR1Lv+nW+Y6u+Pyc0zL5TEWJZ5Tl6TeD44znn6fuGqtGWXziUmYiCqxMg6ZW9jIAlnqhPCHmVzZg69TrRqnewQEdqlbKaTWUb5dDERRVymdNAin2aKDxKSPCB5I6qdLlLUIwKc4r9k77wOUKjchQy2Bxm6DilwNCAydXpLLbcgdorMMctj1Gl0EiOf8K8SsXHiZ9oQKukcs0c4kqqxC+Y8uNnfs8TtWP3Na75LTd1U7Ew7FQcw3U9eXKUa3K3SAUPQtcTNupmUopEtnbbc7cns0MBug8JDohSgjQADZxOXmecpCPFJO/pakUfDqWxGKpA/HhwQ3a0C7Xp/KiiKMDhlaO42XM4HDzB7EklykOmQmxP1owJXC1F4VWGUUeaN+hOiXchYIjddl2GRqURw6dA+Ni4SOZ4hC6Jo0e2RSP8bMLVgI4719TOXe6GqaLL+MQyqTSyPii1hZpPXyZQB6WGNc0X6ueqxyTONGMyrNE+1s8yu3eLxx8NnK2U82Zlgqbc5MkCWlz4kw7wz6X8yJeTD2iEdMBGUqc22Nu8izRtj5Yjq4HlF/s2aKb8tDIXHIlO8h6MRP8X82bOf9OdMYRbqiPhVbi5aJqC06Z2c0TFoYwvPaLealsppmgCjA3y1RiYdhnXh7Vs33imjifGERxsXfnK2LrmKlEwAsoQ8s2utU4wch9HpVX9ezNhCvT3B3ZCifPVx6gpuUnwrg4S37SCy8WvPU+6RUfEe7yjHl66wFJt1iKS06MOZFaMrF06FhZzwwxMRzyHHpSR6Wc5a2rT7CsfqIH5ydChrOZgSWsZC6m+IobsXahMiPv4VWMpZd699cXjTzK5mQD2mbe3kmE6uGB7PYsKbnrz0u4+G6I7lMnLdUkNioLXIYCfCsvvDxSL0YTXpuhB50XuS3aByZAXtJCD7Jch5b+V387bXKjaAf+VfYhtwp57yk3Aym0eG5kLDJ4W5PqdpwfGUPi6XYW5ZIgy+UmAbvlUFkisg7I8Vpwlv8C9ddCMkbeb1JqXq4ghawDRZSl+8iLoev1bLsXZZvtumse9KE8k/KJVcQMxtCAqHEn9JIDbSHr6erQ66E8opFbRba7G+9OHJDlmiahYWGfNasXnxhBpuyD9DFr868fuS9Lc6Ad4ih5Na2YO5y1mhOYcszMF4RXCLHEAfB1OjEYubWnDYWw2O95QRnFO69jMQbyF3uzcY4Wcks5CPHSGhB5fYAOwkGLu2n5wBkWAbuvbJpczd7VqrWJ9JONu18rNnrHcmwNobdDcpmmfhU9WRLBBHcJugAaI6sdGzwAOCnQaNm41lulaRpYZ19oKFSTPSxlwW9AIe3SvIMwP/YwcD0UWa+OU9JkHsmmqUdOiSuMgy4xreGpOIukvFo9FQ0Yaye2pyL41pndrrcQLYfYczGaX0HWZKavCFE1OVOYJB3vZ+XRcIojwSB2H8J+cT1i4zku7ZfRv4qOVQYkl9UpxgzpEQdyHeqxGiZCFwEkt1U6zqcmKz11Cuo1lAml7lxUzShDSrCijvNqpAzPSqu0vENvgs5PCSZa3CgHA2jCyLRefCKJ8DwzHiAhg7vtunaHUxUmeaIu+49kaZQdpHW93CCYRnB56hOlZRsCfTnw+8U+ahSYAesVzjZolsV1mnJbdITEEb5ffB/Sf4PlqHATyMLnLkGhzzkNNa0hwb4wHjZ5Gzqv+rRZSu69OSqpJF0IjRDh/DqC+zGDibdUzcjtT0SKxKzyN2nmnOpS51ODwJ4wZ+DNlH+EFkyJlFouQlNwuSupxesBSS3vTf406eLR0zb6q+FKE0Pu40GveDke53bEbSrgvKdJT08+2D78HDwtRsPLGy5dlJuw3XGjeWUOJNp+MecYYP6ql5M7RYWwowrUW/SDYPuFiSFe17tLVXiiSapVUFB66B21y+MBAwwpqtZQU06amJDBGE5xVm5vvGZAgJNwP3hM72jx27dBcaMGW8OduCcTXpLCYMR0IE57p32w8jEDwalu7D10cjkiBM2xKX0oqZK8VHNjEjXauwTO2dfiNA2hNE1hAhqJ8LrVJhj6F3lgGoT7fChL3+NmO0Qfp845O+vR0Rr1QltBQLcqD54tA4QqUEKTLyl7p1gRKA8OyjJn7hPC9WHS8VCsI5yUrnde6dft+dihsBgrHqloihx29vsgUhLDJh7IbnqGafWNk+xC8REd1mMETTAMAWPu8LjzgRSnEgfHGdY/kQVxLUvsKvoy9TTOerVg+7RpH6cc0LJ4LnkAdW3BmE73YzUxOe2jPmU0PTsr2iqZfVIF0Th4ohbnXZ2eBA963TSLdleSw92ja82kTircV8N5pdwOczloutsWdVuTB43f+RfiP/HEd01zUiLgNUaxk7B8etFfH5gy+E8xjVdmazO4RXGJ0QJNF4EWfACcjlZ6U3Ely5NpwRGWoBSBw1jLjcuBSO837kAFbBPUywKmKceLxREj1/h1r3YgaJvSJG1FkyloY4kla7cbgCukO5rDvT62wHDMRFWhAAWkdk0a+G9Fjb6igimj4fQ3GmmjdLrZbYOSxunUkjhmRwK8+0WD3Vpe8PYGKVMivIJQwtY6mFwoOi3FQNWqQF4NZTfAfO3IUtamcDUEha2qZMNZ5C9y/wy0h0bdU6H39OGbIQJOOW2TP9PS0suRIP/sekTIg8qAYQbiq/yC431/WZsggB+QgfZW4IexhlTlgE+oh4eD2jWfL4aTS0261VUSkht5a/Ee02gzR8eWQGCbT9hytB1uptIfrxcpwiCQgBhXniqw6WJUZD/iCG6Ww8kvzpXDd4ijyAXsqUBViptZnS5HE29cVrwyX4EcogOm04TaQqwrL6rt3t3rjVHctG0hdF4t0JuAy6KjwNLCHpJI4jk3b/z0zES2L3StZ6Mz5QhtTSce6mNZCspcs8Ln/UgWNi7X2H7jDS434Pjd3Monx4eJruvKoUIscyhKWjo3xZw0XGK9W3Km2+771ZzEScIPq91WQBiCaqpWJtqSe5BnJW2XhdKoKRH5tNboAG+RhJQkzWwnz884Lor5GKXlxfcp5clEQ40lwnsU96KU7ZCp2glcp27H1dQMC1VRPhwtZeWVx1IsmsZwslxAtUerwLlN0zZ1T4us9idGNdv+4APLelHjghs/XCVfYyQ0oj29QgkIlpAdcR02qtdzs1SfrL3CMv3X7e3jPz9++fHp8dP7p1/+1+PH79/e/uV/vv2P56d/fH0r//Lp+fNvn79++PL+l6dP/3r/98fn758/Psqv8KW3t8+Pvz4+P379+Pj+6cf3P358n34BwsDb229PP57l3358enr+JMN8f3z/7Y8PHx/f/qX+mzcylw/ffzw/vvny9PHDl7fzkL99+OP98+MfHz4/M6X/8/bj0/OzzI+Jjj/2+E/5EJvi7e0/Hj//9juzr73+/51L7YAmB6AnATx8uhVEkP47eaqcQelBCd69+fft7d8ev//+9Elm9/mrDP7t8f3jp98e3395/Prb99/f/yL/X/72r+/LX5J5jLl+5Ue/PMlM5S98ly/6poPIv36W3xtf8v7r03f5n3///PgP+fkv/3r/49vj89t/366/Lh2+bvqCRC5Edh3GCTnRt/nLdzhCsVHOExP9//t1efV14jQAFIbPnZ6Fw9fFuMtTkSGgx1e2/w8/T27J3z788/Pffvztfb8t35/ej0/+x9Pzl0/vP32Wsb9y9rf5lH9//MbvfP76/tvXx79++/7j0+ent3/5/vzj8fb2j6dvn79//vvjNFe5l99kHnJrvnz+34/ytXJyZdYfn/7gUv3nPz98/P6mXq1vP55//cAV+/rpzbe/Pn55/P709c3T1y//enjzP2Ti79qXvGl/5g2D396M0f/bm++/Pz/Kzx/lY8RCvGmLImP+9cvjG1maN/WGPrydDMkfH56/v//189ffHp//eP78tWxsMSl/eauvlvlF7uwvcf+021/9LyZ8+pi2xyw/NY/uF2P8p0d6knfzCe3KTEFTDOevj7/6X83bf//73//1fwEk55G4')))


ROLE_TARGETS = {
    "hips": "pelvis", "spine": "spine_low", "chest": "chest",
    "upperChest": "upper_chest", "neck": "neck", "head": "head", "jaw": "jaw",
}
for _side, _suffix in (("left", "L"), ("right", "R")):
    for _role, _name in (("Shoulder", "clavicle"), ("UpperArm", "upper_arm"),
                         ("LowerArm", "forearm"), ("Hand", "hand"),
                         ("UpperLeg", "thigh"), ("LowerLeg", "shin"),
                         ("Foot", "foot"), ("Toes", "toe")):
        ROLE_TARGETS[_side+_role] = _name+"."+_suffix
    for _role, _name in (("Thumb", "thumb"), ("Index", "index"),
                         ("Middle", "middle"), ("Ring", "ring"), ("Little", "pinky")):
        for _i, _joint in enumerate(("Proximal", "Intermediate", "Distal"), 1):
            ROLE_TARGETS[_side+_role+_joint] = f"{_name}.{_i:02d}.{_suffix}"

REQUIRED_ROLES = ("hips", "spine", "head", "leftUpperArm", "leftLowerArm", "leftHand",
                  "rightUpperArm", "rightLowerArm", "rightHand", "leftUpperLeg",
                  "leftLowerLeg", "leftFoot", "rightUpperLeg", "rightLowerLeg", "rightFoot")


def canonical_name(name):
    # Explicit alias matching, not substring guessing for numbered rigs.
    value = name.split(":")[-1]
    return "".join(c.lower() for c in value if c.isalnum())


def canonical_frame(up, forward, pivot):
    up = unit(up)
    forward = unit(tuple(forward[i]-up[i]*sum(a*b for a,b in zip(up,forward)) for i in range(3)))
    right = unit(cross(forward,up))
    rows = [list(axis)+[pivot[i]-sum(x*y for x,y in zip(axis,pivot))] for i,axis in enumerate((right,forward,up))]
    return rows+[[0,0,0,1]]


def resolve_named_roles(names, explicit=None):
    aliases = {"hips": ("Hips", "pelvis"), "spine": ("Spine", "spine_low"),
               "chest": ("Spine1", "chest"), "upperChest": ("Spine2", "upper_chest"),
               "neck": ("Neck",), "head": ("Head",), "jaw": ("Jaw",)}
    for side, suffix in (("Left", "L"), ("Right", "R")):
        prefix = side.lower()
        for role, mixamo, target in (("Shoulder", "Shoulder", "clavicle"),
                                     ("UpperArm", "Arm", "upper_arm"),
                                     ("LowerArm", "ForeArm", "forearm"),
                                     ("Hand", "Hand", "hand"), ("UpperLeg", "UpLeg", "thigh"),
                                     ("LowerLeg", "Leg", "shin"), ("Foot", "Foot", "foot"),
                                     ("Toes", "ToeBase", "toe")):
            aliases[prefix+role] = (side+mixamo, target+"."+suffix)
        for finger, target in (("Thumb", "thumb"), ("Index", "index"),
                               ("Middle", "middle"), ("Ring", "ring"), ("Little", "pinky")):
            for i,joint in enumerate(("Proximal", "Intermediate", "Distal"),1):
                aliases[prefix+finger+joint] = (side+"Hand"+("Pinky" if finger=="Little" else finger)+str(i),
                                                f"{target}.{i:02d}.{suffix}")
    by_key = {}
    for name in names:
        by_key.setdefault(canonical_name(name), []).append(name)
    result = {}
    for role, values in aliases.items():
        matches = {n for alias in (*values, role) for n in by_key.get(canonical_name(alias), [])}
        if len(matches) == 1:
            result[role] = matches.pop()
    for role, name in (explicit or {}).items():
        if role not in ROLE_TARGETS or name not in names:
            raise RuntimeError(f"Invalid humanoid role override: {role} -> {name}")
        result[role] = name
    if len(set(result.values())) != len(result):
        raise RuntimeError("One source bone is assigned to multiple humanoid roles.")
    return result


def build_named_profile(parents, roles, weighted):
    missing = [r for r in REQUIRED_ROLES if r not in roles]
    if missing:
        raise RuntimeError("Incomplete humanoid role map: " + ", ".join(missing))
    # Verify required limb chains; flat legacy group centers are not joints.
    def ancestor(a, b):
        seen = set()
        while b is not None and b not in seen:
            if b == a:
                return True
            seen.add(b)
            b = parents.get(b)
        return False
    for side in ("left", "right"):
        for a,b in (("UpperArm", "LowerArm"), ("LowerArm", "Hand"),
                    ("UpperLeg", "LowerLeg"), ("LowerLeg", "Foot")):
            if not ancestor(roles[side+a], roles[side+b]):
                raise RuntimeError(f"{side+b} is not a descendant of {side+a}. Use GUIDED reconstruction for flat rigs.")
    if not ancestor(roles['hips'], roles['spine']) or not ancestor(roles['spine'], roles['head']):
        raise RuntimeError("Hips/spine/head do not form a chain. Review roles or use GUIDED reconstruction.")
    role_for_source = {name: role for role,name in roles.items()}
    retained = set(roles.values()) | set(weighted)
    retained.update(name for name,parent in parents.items() if parent is None)
    targets = {}
    for name in sorted(retained):
        if name in role_for_source:
            targets[name] = ROLE_TARGETS[role_for_source[name]]
        elif parents[name] is None and name not in weighted:
            targets[name] = "root" if "root" not in targets.values() else "extra_"+name
        else:
            targets[name] = "extra_"+name
    if len(set(targets.values())) != len(targets):
        raise RuntimeError("Destination bone names collide; review the source names.")
    def nearest(name):
        seen = set()
        while name is not None and name not in retained:
            if name in seen or name not in parents:
                raise RuntimeError("Invalid source hierarchy.")
            seen.add(name)
            name = parents[name]
        return name
    specs = []
    for name in sorted(retained):
        role = role_for_source.get(name)
        label = "Fingers" if role and any(f in role for f in ("Thumb", "Index", "Middle", "Ring", "Little")) else "Body" if role else "Extras"
        if role == "jaw":
            label = "Face"
        parent = nearest(parents[name])
        specs.append({"source": name, "name": targets[name], "tail_landmark": None,
                      "parent": targets[parent] if parent else None, "collection": label,
                      "use_source_tail": True})
    mapping = {name: targets[nearest(name)] for name in parents}
    humanoid = {role: targets[name] for role,name in roles.items()}
    return specs, mapping, humanoid


def named_tail_landmarks(roles):
    result = {}
    torso = [r for r in ('hips','spine','chest','upperChest','neck','head') if r in roles]
    for a,b in zip(torso,torso[1:]): result[roles[a]] = roles[b]
    for side in ('left','right'):
        for chain in (('Shoulder','UpperArm','LowerArm','Hand'), ('UpperLeg','LowerLeg','Foot','Toes')):
            present = [side+r for r in chain if side+r in roles]
            for a,b in zip(present,present[1:]): result[roles[a]] = roles[b]
        for finger in ('Thumb','Index','Middle','Ring','Little'):
            chain = [side+finger+j for j in ('Proximal','Intermediate','Distal') if side+finger+j in roles]
            for a,b in zip(chain,chain[1:]): result[roles[a]] = roles[b]
        for finger in ('Middle','Index','Ring'):
            if side+'Hand' in roles and side+finger+'Proximal' in roles:
                result[roles[side+'Hand']] = roles[side+finger+'Proximal']
                break
    return result


def distance_to_segment(point, head, tail):
    direction = vsub(tail, head)
    length2 = sum(x*x for x in direction)
    if length2 < 1e-18:
        raise RuntimeError("Zero-length guided bone.")
    t = max(0.0, min(1.0, sum(x*y for x,y in zip(vsub(point, head), direction))/length2))
    return math.sqrt(sum((point[i]-head[i]-t*direction[i])**2 for i in range(3)))


def validate_source_region_targets(rules, parents, specs):
    targets = {s['name'] for s in specs if s['name'] != 'root'}
    if not isinstance(rules, dict):
        raise RuntimeError('GUIDED_SOURCE_REGION_TARGETS must be a dictionary.')
    for name,target in rules.items():
        if not isinstance(name,str) or not isinstance(target,str) or name not in parents or target not in targets:
            raise RuntimeError(f'Invalid guided source region: {name} -> {target}. Use an existing source bone and body target.')
    return dict(rules)


def source_region_weights(skin, rules):
    """A whole-region rule applies only if it covers all positive source skin."""
    if not skin or any(name not in rules for name in skin):
        return None
    values = {}
    for name,w in skin.items():
        if not math.isfinite(w) or w < 0:
            raise RuntimeError('Invalid source weight in guided region assignment.')
        values[rules[name]] = values.get(rules[name],0)+w
    total = sum(values.values())
    return {name:w/total for name,w in values.items() if w>0} if total>0 else None


def prepare_guided_weight_batches(meshes,specs,rules,object_targets,deform_names):
    """Shared inputs for final conversion and the pre-conversion weight preview."""
    batches=[];regions=[]
    counts={'region_override_vertices':0,'source_region_vertices':0,'partial_source_region_vertices':0}
    targets={s['name'] for s in specs if s['name']!='root'}
    for obj in meshes:
        names={g.index:g.name for g in obj.vertex_groups}
        source_regions=[];overrides=[];object_target=object_targets.get(obj.name)
        if object_target is not None and object_target not in targets:
            raise RuntimeError(f'{obj.name}: invalid GUIDED_OBJECT_TARGETS attachment {object_target}.')
        for v in obj.data.vertices:
            skin={names[g.group]:g.weight for g in v.groups if g.weight>0 and names[g.group] in deform_names}
            source_regions.append(skin)
            override={names[g.group][3:]:g.weight for g in v.groups if names[g.group].startswith('RR:') and g.weight>0}
            counts['region_override_vertices']+=bool(override)
            if not override and object_target is not None:override={object_target:1.0}
            if not override:
                override=source_region_weights(skin,rules)
                counts['source_region_vertices']+=bool(override)
                counts['partial_source_region_vertices']+=not override and any(n in rules for n in skin)
            overrides.append(override)
        points=[tuple(obj.matrix_world@v.co) for v in obj.data.vertices]
        batches.append((obj.name,points,[tuple(e.vertices) for e in obj.data.edges],overrides));regions.append(source_regions)
    return batches,regions,counts


def guided_seam_weight_conflicts(points, rows):
    """Exact coincident vertices may be seams or separate layers; report, never weld."""
    first = {}
    conflicts = set()
    for point,row in zip(points,rows):
        key = tuple(point)
        if key in first:
            other = first[key]
            if any(abs(row.get(n,0)-other.get(n,0))>1e-6 for n in set(row)|set(other)):
                conflicts.add(key)
        else:
            first[key] = row
    return len(conflicts)


def make_guided_profile(name, parents, heads, local_markers, rules, object_targets=None):
    required = set(marker_seed([(0,0,0),(1,1,1)],(0,0,1),(0,-1,0)))
    if not required.issubset(local_markers) or set(local_markers)-required-set(HEAD_REGION_MARKERS)-set(FIT_OPTIONAL_MARKERS):
        raise RuntimeError('A reusable profile requires the 25 body/direction landmarks and only supported optional head/collarbone markers.')
    profile = {'rune_rig_profile':1,'name':name,
               'source':{'parents':dict(parents),'heads':{n:list(p) for n,p in heads.items()}},
               'landmarks_armature_space':{n:list(p) for n,p in local_markers.items()},
               'source_region_targets':dict(rules)}
    if object_targets: profile['object_targets'] = dict(object_targets)
    # Reject non-finite data rather than writing unusable JSON.
    json.dumps(profile,allow_nan=False)
    return profile


def guided_profile_matches(profile, parents, heads):
    if not isinstance(profile,dict) or profile.get('rune_rig_profile') != 1:
        return False
    source = profile.get('source',{})
    if not isinstance(source,dict) or source.get('parents') != parents:
        return False
    saved = source.get('heads',{})
    if not isinstance(saved,dict) or set(saved) != set(heads):
        return False
    try:
        return all(len(saved[n])==3 and all(math.isfinite(float(a)) and abs(float(a)-float(b))<=.01
                   for a,b in zip(saved[n],p)) for n,p in heads.items())
    except (TypeError,ValueError):
        return False


def profile_landmarks(profile):
    points = profile.get('landmarks_armature_space')
    required = set(marker_seed([(0,0,0),(1,1,1)],(0,0,1),(0,-1,0)))
    if not isinstance(points,dict) or not required.issubset(points) or set(points)-required-set(HEAD_REGION_MARKERS)-set(FIT_OPTIONAL_MARKERS):
        raise RuntimeError('Saved guided profile is missing body/direction landmarks. Refit with CONVERSION_MODE="GUIDED".')
    if not isinstance(profile.get('source_region_targets'),dict):
        raise RuntimeError('Saved guided profile has invalid source region rules.')
    attachments = profile.get('object_targets',{})
    if not isinstance(attachments,dict) or any(not isinstance(n,str) or not isinstance(t,str) for n,t in attachments.items()):
        raise RuntimeError('Saved guided profile has invalid object attachment rules.')
    try:
        if not all(len(p)==3 and all(math.isfinite(float(v)) for v in p) for p in points.values()):
            raise ValueError()
        return {n:tuple(float(v) for v in p) for n,p in points.items()}
    except (TypeError,ValueError):
        raise RuntimeError('Saved guided profile contains invalid landmark coordinates.') from None


def choose_guided_profile(explicit_json, texts, parents, heads):
    if explicit_json.strip():
        try:
            profile = json.loads(explicit_json)
        except ValueError:
            raise RuntimeError('GUIDED_PROFILE_JSON is invalid JSON.') from None
        if not guided_profile_matches(profile,parents,heads):
            raise RuntimeError('The supplied guided profile belongs to a different skeleton/rest layout. Refit with GUIDED or clear GUIDED_PROFILE_JSON.')
        profile_landmarks(profile)
        return profile
    candidates = []
    for name,body in texts:
        if not body.lstrip().startswith('{') or '"rune_rig_profile"' not in body:
            continue
        try:
            profile = json.loads(body)
        except ValueError:
            continue
        if guided_profile_matches(profile,parents,heads):
            profile_landmarks(profile)
            candidates.append(profile)
    # Two names with identical fitted data are harmless; conflicting fits require a choice.
    unique = {json.dumps({**{k:p[k] for k in ('source','landmarks_armature_space','source_region_targets')},
                         'object_targets':p.get('object_targets',{})},sort_keys=True):p for p in candidates}
    if len(unique)>1:
        raise RuntimeError('Multiple different guided profiles match this skeleton. Paste the desired profile into GUIDED_PROFILE_JSON, or use GUIDED to refit.')
    return next(iter(unique.values()),None)


def save_guided_profile_text(bpy, source, profile):
    text = next((t for t in bpy.data.texts if t.get('rune_rig_profile_source')==source.name),None)
    if text is None:
        text = bpy.data.texts.new('RuneRigProfile_'+source.name+'.json')
        text['rune_rig_profile_source'] = source.name
    else:
        text.clear()
    text.use_fake_user = True
    text.write(json.dumps(profile,indent=2,allow_nan=False))
    print('Reusable fitted profile saved in Blender Text:',text.name)
    return text.name


def guided_vertex_weights(point, specs, scale, override=None):
    """Geometry-only draft, with explicit per-vertex region weights taking priority."""
    names = {s['name'] for s in specs if s['name'] != 'root'}
    if override:
        if any(name not in names or not math.isfinite(w) or w < 0 for name,w in override.items()):
            raise RuntimeError("Invalid RR: region override.")
        total = sum(override.values())
        if total > 0:
            return {name:w/total for name,w in override.items() if w > 0}
    candidates = [s for s in specs if s['name'] != 'root']
    distances = {s['name']:distance_to_segment(point,s['head'],s['tail']) for s in candidates}
    closest = min(candidates, key=lambda s:(distances[s['name']],s['name']))
    # Blend only adjacent bones, so proximity cannot blend a hand with a hip.
    neighbors = [s for s in candidates if s['name']==closest['parent'] or s['parent']==closest['name']]
    selected = [closest]
    if neighbors:
        selected.append(min(neighbors,key=lambda s:(distances[s['name']],s['name'])))
    radius = max(scale*.025, 1e-8)
    values = {s['name']:1/(distances[s['name']]+radius)**4 for s in selected}
    total = sum(values.values())
    return {name:w/total for name,w in values.items()}


def guided_specs(markers):
    central = [("pelvis", "pelvis", "spine_low", "root", "hips"),
               ("spine_low", "spine_low", "chest", "pelvis", "spine"),
               ("chest", "chest", "neck", "spine_low", "chest"),
               ("neck", "neck", "head", "chest", "neck"),
               ("head", "head", "head_tip", "neck", "head")]
    result = []
    humanoid = {}
    for name, head, tail, parent, role in central:
        result.append({'name':name,'head':markers[head],'tail':markers[tail],'parent':parent,'collection':'Body'})
        humanoid[role] = name
    for prefix,side in (("left","L"),("right","R")):
        for name, head, tail, parent, role in (
                ('clavicle','clavicle','shoulder','chest','Shoulder'),
                ('upper_arm','shoulder','elbow','clavicle.'+side,'UpperArm'),
                ('forearm','elbow','wrist','upper_arm.'+side,'LowerArm'),
                ('hand','wrist','hand_tip','forearm.'+side,'Hand'),
                ('thigh','hip','knee','pelvis','UpperLeg'),
                ('shin','knee','ankle','thigh.'+side,'LowerLeg'),
                ('foot','ankle','toe','shin.'+side,'Foot'),
                ('toe','toe','toe_tip','foot.'+side,'Toes')):
            head_point = (markers[head+'.'+side] if head != 'clavicle' else
                          markers.get('clavicle.'+side,tuple(markers['chest'][i]*.8+markers['shoulder.'+side][i]*.2 for i in range(3))))
            result.append({'name':name+'.'+side,'head':head_point,'tail':markers[tail+'.'+side],
                           'parent':parent,'collection':'Body'})
            humanoid[prefix+role] = name+'.'+side
    up = unit(vsub(markers['head'], markers['pelvis']))
    height = math.dist(markers['head_tip'], tuple((markers['ankle.L'][i]+markers['ankle.R'][i])/2 for i in range(3)))
    result.insert(0, {'name':'root','head':markers['pelvis'],
                      'tail':tuple(markers['pelvis'][i]+up[i]*height*.05 for i in range(3)),
                      'parent':None,'collection':'Body'})
    for spec in result:
        if math.dist(spec['head'],spec['tail']) < height*1e-5:
            raise RuntimeError(f"Landmarks for {spec['name']} coincide; position them before converting.")
        spec['source'] = 'guide:'+spec['name']
        spec['tail_landmark'] = 'guide_tail:'+spec['name']
    return result, humanoid, height


def marker_seed(points, up, forward):
    up, forward = unit(up), unit(forward)
    forward = unit(tuple(forward[i]-up[i]*sum(a*b for a,b in zip(up,forward)) for i in range(3)))
    left = unit(cross(up, forward))
    def dot(p,a): return sum(x*y for x,y in zip(p,a))
    bounds = [(min(dot(p,a) for p in points), max(dot(p,a) for p in points)) for a in (left,forward,up)]
    height = bounds[2][1]-bounds[2][0]
    if height < 1e-8:
        raise RuntimeError("Mesh has no height along GUIDED_UP.")
    center = [(lo+hi)/2 for lo,hi in bounds]
    half_width = (bounds[0][1]-bounds[0][0])/2
    def location(x,y,z):
        coord = (center[0]+x*half_width, center[1]+y*height, bounds[2][0]+z*height)
        return tuple(sum(coord[j]*axis[i] for j,axis in enumerate((left,forward,up))) for i in range(3))
    markers = {name:location(0,0,z) for name,z in (('pelvis',.51),('spine_low',.62),('chest',.77),
                                                 ('neck',.85),('head',.90),('head_tip',.99))}
    markers['forward'] = location(0,.25,.77)
    for side,sign in (('L',1),('R',-1)):
        for name,x,y,z in (('shoulder',.44,0,.81),('elbow',.68,-.015,.68),('wrist',.82,0,.51),
                           ('hand_tip',.84,.005,.44),('hip',.29,0,.49),('knee',.29,.015,.29),
                           ('ankle',.29,0,.06),('toe',.29,.10,.025),('toe_tip',.29,.15,.025)):
            markers[name+'.'+side] = location(sign*x,y,z)
    return markers


def guide_objects(collection):
    """Walk owned guide subcollections; preserve older flat layouts."""
    result = list(collection.objects)
    for child in collection.children:
        result.extend(guide_objects(child))
    return result


def guide_section(name):
    if name in HEAD_REGION_MARKERS: return 'Head Region'
    if name == 'forward': return 'Direction'
    if '.' not in name: return 'Body'
    part, side = name.rsplit('.', 1)
    limb = 'Arm' if part in ('clavicle','shoulder','elbow','wrist','hand_tip') else 'Leg'
    return ('Left ' if side == 'L' else 'Right ') + limb


def find_or_create_guides(bpy, source, points):
    collection = next((c for c in bpy.data.collections if c.get('rune_rig_guide_source') == source.name), None)
    if collection is None:
        collection = bpy.data.collections.new(source.name+'_RuneRig_Landmarks')
        collection['rune_rig_guide_source'] = source.name
        bpy.context.scene.collection.children.link(collection)
    owned = {o.get('rune_rig_landmark'):o for o in guide_objects(collection) if o.get('rune_rig_landmark')}
    sections = {}
    for label in ('Body','Left Arm','Right Arm','Left Leg','Right Leg','Direction','Head Region'):
        child = next((c for c in collection.children if c.get('rune_rig_guide_section') == label), None)
        if child is None:
            child = bpy.data.collections.new(source.name+'_RR_'+label.replace(' ','_'))
            child['rune_rig_guide_section'] = label
            collection.children.link(child)
        child.hide_viewport = False
        child.hide_render = True
        sections[label] = child
    seeds = marker_seed(points, GUIDED_UP, GUIDED_FORWARD)
    if GUIDED_HEAD_POLICY=='FITTED_HEAD':
        # Existing fitted joints are the basis for new region markers, rather
        # than the bounding-box template. Do not discard earlier fitting.
        fitted={n:tuple(owned[n].location) if getattr(owned[n],'parent',None) is None
                else tuple(owned[n].matrix_world.translation) for n in seeds if n in owned}
        seeds.update(head_region_seeds({**seeds,**fitted}))
    created = []
    for name, point in seeds.items():
        if name not in owned:
            obj = bpy.data.objects.new('RR_'+name, None)
            obj['rune_rig_landmark'] = name
            obj.empty_display_type = 'SPHERE'
            obj.empty_display_size = max(math.dist(seeds['head_tip'],seeds['ankle.L'])*.012, .001)
            obj.show_name = True
            obj.show_in_front = True
            obj.location = point
            owned[name] = obj
            created.append(name)
        obj = owned[name]
        obj['rune_rig_fit_source'] = source.name
        fit_style_marker(obj,name,math.dist(seeds['head_tip'],seeds['ankle.L']),getattr(bpy.context.scene,'rune_rig_fit_handle_size',1))
        destination = sections[guide_section(name)]
        if obj not in list(destination.objects): destination.objects.link(obj)
        # Relink only within our own hierarchy. User collections are untouched.
        for old in [collection]+list(collection.children):
            if old != destination and obj in list(old.objects): old.objects.unlink(obj)
    collection.hide_viewport = False
    collection.hide_render = True
    # Old optional collarbone markers are preserved and styled too.
    for name,obj in owned.items():
        if name in FIT_OPTIONAL_MARKERS:
            obj['rune_rig_fit_source']=source.name
            fit_style_marker(obj,name,math.dist(seeds['head_tip'],seeds['ankle.L']))
    try:
        ui=register_rune_rig_fitting(bpy)
        if hasattr(bpy,'app') and 'rune_rig_fitting_backend' in bpy.app.driver_namespace:
            bpy.app.driver_namespace['rune_rig_fitting_backend']['source']=source.name
    except Exception as error:
        print('Fitting sidebar unavailable; legacy point fitting remains available:',error)
    if created or not GUIDED_LANDMARKS_READY:
        if hasattr(bpy,'types') and hasattr(bpy.types,'RUNERIG_PT_fitting') and hasattr(source,'hide_set'):
            source.hide_set(True)  # Draw clutter only; bound meshes stay visible.
        message = ('Created landmark seeds. ' if created else 'Kept existing landmark positions. ')
        message += ('Open 3D View > N > RuneRig for named point selection, placement help, front/side views and an editable skeleton. '
                    'Fit the points or build/edit/apply the skeleton, inspect the weight preview, then click Convert fitted model. '
                    'Legacy fallback: set GUIDED_LANDMARKS_READY=True in this script and run again. '
                    'Guided output has rigid hands and approximate body weights; test bends before export.')
        print(message)
        text = bpy.data.texts.new(source.name+'_RuneRig_LandmarkInstructions.txt')
        text.write(message+'\n\n'+landmark_instructions())
        def popup(self, context):
            self.layout.label(text='Open 3D View > N > RuneRig to fit and convert without editing script settings.')
            self.layout.label(text='Head Region: head_base below chin; head_side.L/R at outer ear tips.')
            self.layout.label(text='Existing marker positions are preserved. Original rig is untouched.')
            self.layout.label(text='Guided weights are a draft; rigid hands, no automatic facial morphs.')
        bpy.context.window_manager.popup_menu(popup,title='Rune Rig: landmark fitting',icon='INFO')
        return None
    update=getattr(getattr(bpy.context,'view_layer',None),'update',None)
    if update:update()
    return {name:tuple(obj.matrix_world.translation) for name,obj in owned.items()}


def universal_main():
    # Sidebar buttons reuse this namespace. Route-specific function/config
    # substitutions must not leak into the next model (especially Moia's jaw).
    names=('EXPECTED_SOURCE','PRESET_VERSION','build_profile','palm_normal','vrm0_humanoid_mapping','CREATE_JAW_OPEN_SHAPE')
    previous={n:globals()[n] for n in names}
    try:return _universal_main_impl()
    finally:globals().update(previous)


def _universal_main_impl():
    import bpy
    from mathutils import Vector
    global GENERIC_PLAN, EXPECTED_SOURCE, PRESET_VERSION, CREATE_JAW_OPEN_SHAPE
    global build_profile, palm_normal, vrm0_humanoid_mapping
    GENERIC_PLAN=None
    if CONVERSION_MODE not in ('AUTO','GUIDED'):
        raise RuntimeError('CONVERSION_MODE must be AUTO or GUIDED.')
    if bpy.context.mode != 'OBJECT':
        raise RuntimeError('Switch to Object Mode and select the original armature or its bound mesh.')
    source = source_armature(bpy)
    meshes = conversion_meshes(bpy,source)
    if not meshes:
        raise RuntimeError('No included mesh is bound to the selected armature. Under RUNEAPPS_NAMES, body pieces must be named Mesh_<number>; renamed pieces are accessories. Rename a body piece or set rune_rig_include=True.')
    parents = {b.name:b.parent.name if b.parent else None for b in source.data.bones}
    moia_layout = (parents == EXPECTED_SOURCE['parents'] and all(
        max(abs(float(a)-b) for a,b in zip(bone.head_local,EXPECTED_SOURCE['heads'][bone.name])) <= .01
        for bone in source.data.bones))
    if CONVERSION_MODE == 'AUTO' and moia_layout:
        # Keeps Moia's reviewed anatomy and the 1.2 cleanup-tolerant validation.
        PRESET_VERSION = 'moia-1.2'
        return finish_conversion(bpy,source,meshes,run_conversion_with_exclusions(bpy,source))
    roles = resolve_named_roles(set(parents), HUMANOID_ROLE_BONES)
    # Prefer populated VRM0 or VRM1 roles over aliases, with explicit overrides last.
    ext = getattr(source.data,'vrm_addon_extension',None)
    vrm_roles = {}
    if ext is not None:
        try:
            if ext.spec_version == '0.0':
                vrm_roles = {e.bone:e.node.bone_name for e in ext.vrm0.humanoid.human_bones if e.node.bone_name in parents}
            else:
                values = ext.vrm1.humanoid.human_bones.human_bone_name_to_human_bone()
                vrm_roles = {str(getattr(role,'value',role)):e.node.bone_name for role,e in values.items() if e.node.bone_name in parents}
                for side in ('left','right'):
                    for before,after in (('ThumbProximal','ThumbIntermediate'),('ThumbMetacarpal','ThumbProximal')):
                        if side+before in vrm_roles:
                            vrm_roles[side+after] = vrm_roles.pop(side+before)
        except (AttributeError, TypeError):
            vrm_roles = {}
    roles.update({r:n for r,n in vrm_roles.items() if r in ROLE_TARGETS})
    roles.update(HUMANOID_ROLE_BONES)
    if len(set(roles.values())) != len(roles):
        raise RuntimeError('Duplicate source bones in humanoid map; review HUMANOID_ROLE_BONES.')
    world_heads = {b.name:source.matrix_world@b.head_local for b in source.data.bones}
    world_tails = {b.name:source.matrix_world@b.tail_local for b in source.data.bones}
    missing = [r for r in REQUIRED_ROLES if r not in roles]
    fitted_profile = None
    profile_to_save = None
    if CONVERSION_MODE=='AUTO' and not missing:
        weighted = {g.name for obj in meshes for v in obj.data.vertices for entry in v.groups if entry.weight>0
                    for g in [obj.vertex_groups[entry.group]] if g.name in parents and source.data.bones[g.name].use_deform}
        specs,mapping,humanoid = build_named_profile(parents,roles,weighted)
        up = (world_heads[roles['head']]-world_heads[roles['hips']]).normalized()
        if up.length < .5:
            raise RuntimeError('Head/hips positions do not establish an up direction.')
        left = world_heads[roles['leftUpperArm']]-world_heads[roles['rightUpperArm']]
        left = (left-up*left.dot(up)).normalized()
        if left.length < .5:
            raise RuntimeError('Arm roles do not establish separate left/right sides.')
        forward = left.cross(up).normalized()
        toe_vectors = [world_heads[roles[s+'Toes']]-world_heads[roles[s+'Foot']] for s in ('left','right') if s+'Toes' in roles]
        if toe_vectors:
            foot_direction = sum(toe_vectors,Vector((0,0,0)))
            foot_direction -= up*foot_direction.dot(up)
            if foot_direction.length>1e-6 and foot_direction.normalized().dot(forward)<.2:
                raise RuntimeError('Foot direction conflicts with named left/right roles. Review roles or use GUIDED fitting.')
        tail_landmarks = named_tail_landmarks(roles)
        for spec in specs:
            spec['head'] = tuple(world_heads[spec['source']])
            spec['tail'] = tuple(world_heads[tail_landmarks[spec['source']]] if spec['source'] in tail_landmarks else world_tails[spec['source']])
            spec['tail_landmark'] = 'generic_tail:'+spec['name']
        palms = {}
        for prefix,side in (('left','L'),('right','R')):
            finger_specs = [s for s in specs if s['collection']=='Fingers' and s['name'].endswith('.'+side) and not s['name'].startswith('thumb.')]
            if finger_specs:
                needed = [prefix+r for r in ('Hand','IndexProximal','LittleProximal')]
                if not all(r in roles for r in needed):
                    raise RuntimeError('Finger roles are incomplete for palm orientation; review the role map.')
                wrist,index,pinky = [world_heads[roles[r]] for r in needed]
                normal = (index-wrist).cross(pinky-wrist)
                if side=='L': normal.negate()
                if normal.length<1e-8:
                    raise RuntimeError('Degenerate hand landmarks; review finger roles.')
                palms[side] = tuple(normal.normalized())
        GENERIC_PLAN = {'route':'named_humanoid','profile':'NamedHumanoid','specs':specs,'mapping':mapping,
                        'humanoid':humanoid,'up':tuple(up),'forward':tuple(forward),'palms':palms,
                        'jaw_source':roles.get('jaw'),'explicit_weights':None,
                        'limits':'Weighted extra bones retained in hidden Extras. Aliases/roles and facing need inspection; no clip retargeting.'}
        CREATE_JAW_OPEN_SHAPE = CREATE_JAW_OPEN_SHAPE and 'jaw' in roles
    else:
        body_meshes = [o for o in meshes if not separate_accessory(o.name)] or meshes
        points = [tuple(obj.matrix_world@v.co) for obj in body_meshes for v in obj.data.vertices]
        reviewed_profile = None
        if CONVERSION_MODE=='AUTO' and USE_REVIEWED_CORRECTIONS and not GUIDED_PROFILE_JSON.strip():
            reviewed_profile=choose_reviewed_correction(source,meshes,parents,
                {b.name:tuple(b.head_local) for b in source.data.bones})
            fitted_profile=reviewed_profile
        if CONVERSION_MODE=='AUTO' and REUSE_GUIDED_PROFILES and fitted_profile is None:
            fitted_profile = choose_guided_profile(GUIDED_PROFILE_JSON,
                [(t.name,t.as_string()) for t in bpy.data.texts], parents,
                {b.name:tuple(b.head_local) for b in source.data.bones})
        if USE_REVIEWED_CORRECTIONS and fitted_profile and fitted_profile.get('corrected_skin') and reviewed_profile is None:
            if correction_surface_fingerprint(correction_mesh_batches(source,meshes))!=fitted_profile['corrected_skin']['source_surface_fingerprint']:
                if GUIDED_PROFILE_JSON.strip():
                    raise RuntimeError('Saved reviewed correction belongs to a different surface. Use GUIDED to refit or clear GUIDED_PROFILE_JSON.')
                print('Stored corrections belong to a different surface; creating ordinary fitting guides.')
                fitted_profile=None
            else:
                reviewed_profile=fitted_profile
        markers = ({n:tuple(source.matrix_world@Vector(p)) for n,p in profile_landmarks(fitted_profile).items()}
                   if fitted_profile else find_or_create_guides(bpy,source,points))
        if markers is None:
            return
        if GUIDED_HEAD_POLICY=='FITTED_HEAD':
            markers={**head_region_seeds(markers),**markers}
        markers,sides_repaired = repair_guided_sides(markers,AUTO_REPAIR_GUIDED_SIDES)
        if sides_repaired and not fitted_profile:
            for collection in bpy.data.collections:
                if collection.get('rune_rig_guide_source')==source.name:
                    for obj in guide_objects(collection):
                        name=obj.get('rune_rig_landmark')
                        if name in markers:obj.matrix_world.translation=Vector(markers[name])
        specs,humanoid,scale = guided_specs(markers)
        rules = dict(fitted_profile['source_region_targets']) if fitted_profile else {}
        rules.update(GUIDED_SOURCE_REGION_TARGETS)
        rules = validate_source_region_targets(rules,parents,specs)
        object_targets = dict(fitted_profile.get('object_targets',{})) if fitted_profile else {}
        object_targets.update(GUIDED_OBJECT_TARGETS)
        up = unit(vsub(markers['head'],markers['pelvis']))
        direction = vsub(markers['forward'],markers['chest'])
        forward = unit(tuple(direction[i]-up[i]*sum(a*b for a,b in zip(up,direction)) for i in range(3)))
        left = cross(up,forward)
        for joint in ('shoulder','hip','wrist','ankle'):
            if sum(a*b for a,b in zip(vsub(markers[joint+'.L'],markers[joint+'.R']),left)) <= scale*.01:
                raise RuntimeError(f'{joint} left/right markers conflict with RR_forward. Fix their anatomical sides.')
        explicit_weights = []
        override_vertices = 0
        source_region_vertices = 0
        partial_source_region_vertices = 0
        seam_conflicts = []
        weight_reports = []
        deform_names = {b.name for b in source.data.bones if b.use_deform}
        weight_batches,source_region_batches,counts=prepare_guided_weight_batches(meshes,specs,rules,object_targets,deform_names)
        override_vertices=counts['region_override_vertices']
        source_region_vertices=counts['source_region_vertices']
        partial_source_region_vertices=counts['partial_source_region_vertices']
        batch_results = (apply_reviewed_corrections(reviewed_profile,source,meshes,specs,weight_batches)
                         if reviewed_profile else guided_batch_weights(weight_batches,specs,scale,markers,source_region_batches))
        for obj,(rows,weight_info) in zip(meshes,batch_results):
            weight_info['mesh'] = obj.name
            weight_reports.append(weight_info)
            explicit_weights.append(rows)
            conflicts = guided_seam_weight_conflicts([tuple(v.co) for v in obj.data.vertices],rows)
            seam_conflicts.append({'mesh':obj.name,'coincident_position_weight_conflicts':conflicts})
            if conflicts:
                print(f'{obj.name}: {conflicts} coincident positions receive different guided weights. Inspect seams/overrides; separate overlapping layers can also be intentional.')
        # Source groups will be removed, but guided rows independently target all body bones.
        mapping = {name:'root' for name in parents}
        GENERIC_PLAN = {'route':'guided_reconstruction_draft','profile':'GuidedBody22','specs':specs,'mapping':mapping,
                        'humanoid':humanoid,'up':up,'forward':forward,'palms':{},'jaw_source':None,
                        'explicit_weights':explicit_weights,'region_override_vertices':override_vertices,
                        'source_region_vertices':source_region_vertices,'partial_source_region_vertices':partial_source_region_vertices,
                        'source_region_targets':rules,'guided_profile_reused':bool(fitted_profile),
                        'object_targets':object_targets,
                        'reviewed_correction_profile':reviewed_profile['name'] if reviewed_profile else None,
                        'guided_seam_checks':seam_conflicts,
                        'guided_weight_reports':weight_reports,'guided_sides_repaired':sides_repaired,
                        'guided_profile_name':fitted_profile.get('name') if fitted_profile else None,
                        'limits':'Source-aware constrained body skinning; anatomical ownership remains inferred. Rigid hands; no facial shapes. Inspect the automatic bend test before export.'}
        inverse = source.matrix_world.inverted()
        profile_to_save = make_guided_profile(source.name,parents,
            {b.name:tuple(b.head_local) for b in source.data.bones},
            {n:tuple(inverse@Vector(p)) for n,p in markers.items()},rules,object_targets)
        profile_to_save['source_matrix_world_at_fit']=[list(row) for row in source.matrix_world]
        profile_to_save['fitted_landmarks_world']={n:list(p) for n,p in markers.items()}
        if reviewed_profile:
            profile_to_save['corrected_skin']=reviewed_profile['corrected_skin']
            GENERIC_PLAN['limits']='Reviewed weights for this matched source surface and skeleton; recorded ankle gap repairs are inferred. Rigid hands; no facial shapes.'
        CREATE_JAW_OPEN_SHAPE = False
    EXPECTED_SOURCE = {'parents':parents,'heads':{b.name:tuple(b.head_local) for b in source.data.bones},
                       'mesh_counts':[len(meshes[0].data.vertices),len(meshes[0].data.edges),len(meshes[0].data.polygons)],
                       'mesh_signature':None}
    PRESET_VERSION = UNIVERSAL_VERSION
    build_profile = lambda parents,keep_fingers: (GENERIC_PLAN['specs'],GENERIC_PLAN['mapping'])
    palm_normal = lambda heads,side: GENERIC_PLAN['palms'][side]
    vrm0_humanoid_mapping = lambda keep_fingers: GENERIC_PLAN['humanoid']
    result = run_conversion_with_exclusions(bpy,source)
    if GENERIC_PLAN['route']=='guided_reconstruction_draft':
        if isinstance(result,dict) and 'rig' in result:
            result['rig']['fitted_landmarks_world_json']=json.dumps(markers,allow_nan=False)
        try:
            save_guided_profile_text(bpy,source,profile_to_save)
        except Exception as error:
            # Conversion already succeeded; a profile storage problem does not invalidate it.
            print('Rig conversion succeeded, but reusable profile storage failed:',error)
        for collection in bpy.data.collections:
            if collection.get('rune_rig_guide_source')==source.name:
                collection.hide_viewport = True
    return finish_conversion(bpy,source,meshes,result)


if __name__ == "__main__":
    universal_main()
