Temporary developer-world permission diagnostic.
No HTTP requests, collection writes or account reads are performed.
Extract CLEPermissionProbe directly under your dev_plugins directory.
Run prf, pon CLEPermissionProbe, then ppe CLEPermissionProbe httpAccess.
Copy lines beginning CLE_PERMISSION_PROBE from the client console.
Run poff CLEPermissionProbe after testing.
This diagnostic is local and is not part of the public repository or plugin package.
