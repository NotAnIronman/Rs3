print("CLE_PERMISSION_STARTUP v2 entered")
local ok, result = pcall(function()
    return Plugin.HasPermission(PluginPermissions.httpAccess)
end)
if ok then
    print("CLE_PERMISSION_STARTUP v2 httpAccess=" .. tostring(result)
        .. " resultType=" .. type(result))
else
    print("CLE_PERMISSION_STARTUP v2 check-error=" .. tostring(result))
end
print("CLE_PERMISSION_STARTUP v2 finished")
