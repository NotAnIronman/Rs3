local config = {["id"]="15",["label"]="optional; prices domain",["mode"]="optional",["url"]="https://prices.runescape.wiki",["folder"]="CLH15",["commandPermission"]="httpAccess",["path"]="/api/v2/rs/latest?id=995"}
local key = "cle-http-lab-" .. config.id
local started, sent, active, request = nil, false, false, nil
local history, telemetry = {}, {stage="entered"}
local function say(message)
    local text=tostring(message):gsub("[\r\n]", " "):sub(1,600)
    history[#history+1]=text
    print("CLE_HTTP_LAB " .. config.id .. " " .. text)
end
say("ENTER " .. config.label)
local function command(value)
    local ok, err = pcall(function() ExecuteConsoleCommand(value) end)
    if not ok then say("COMMAND_ERROR " .. tostring(err)) end
end
local function grantSelf()
    command("ppr " .. config.folder)
    command("ppe " .. config.folder .. " " .. config.commandPermission)
end
if config.selfGrant == "startup" then grantSelf() end
local function describe(reason)
    local ok, value = pcall(function() return Plugin.HasPermission(PluginPermissions.httpAccess) end)
    local colonOK, colonValue = pcall(function() return Plugin:HasPermission(PluginPermissions.httpAccess) end)
    local urlOK, urlType = pcall(function() return type(Plugin.urls.wiki) end)
    telemetry.dot=ok and tostring(value) or "error"
    telemetry.colon=colonOK and tostring(colonValue) or "error"
    telemetry.url=urlOK and urlType or "error"
    say("CHECK " .. reason .. " dot=" .. (ok and tostring(value) or "error:" .. tostring(value))
        .. " colon=" .. (colonOK and tostring(colonValue) or "error")
        .. " url=" .. (urlOK and urlType or "error"))
end
local function unsubscribe()
    pcall(function() Event.Logic.Unsubscribe(key) end)
end
local function tryRequest()
    if config.mode == "none" then
        telemetry.stage="baseline"
        say("RESULT baseline; no request attempted")
        return
    end
    -- User-authorized diagnostic: native HTTPRequest validates access.
    -- No permission function or native restriction is overridden.
    local ok, value = pcall(function() return HTTPRequest.new(Plugin.urls.wiki, config.path) end)
    if not ok then telemetry.stage="constructor-error";telemetry.error=tostring(value);say("RESULT constructor-error " .. tostring(value)); return end
    request = value
    local headerOK, headerError = pcall(function()
        request:AddHeader("User-Agent", "CollectionLogExpanded-HttpDiagnostic/0.0.3 (public API test)")
    end)
    if not headerOK then say("HEADER_ERROR " .. tostring(headerError)) end
    active = true
    telemetry.stage="waiting"
    local getOK, getError = pcall(function()
        request:Get(function(response)
            active = false
            local readOK, readError = pcall(function()
                telemetry.stage="response"
                telemetry.code=tonumber(response.responseCode) or 0
                telemetry.successful=response.successful==true
                telemetry.failed=response.failed==true
                telemetry.errorCode=tostring(response.errorCode)
                telemetry.bytes=type(response.data)=="string" and #response.data or 0
                say("RESULT response successful=" .. tostring(response.successful)
                    .. " code=" .. tostring(response.responseCode)
                    .. " failed=" .. tostring(response.failed)
                    .. " error=" .. tostring(response.errorCode)
                    .. " timeout=" .. tostring(response.timedOut)
                    .. " bytes=" .. tostring(type(response.data)=="string" and #response.data or 0))
            end)
            if not readOK then say("RESULT response-read-error " .. tostring(readError)) end
        end)
    end)
    if not getOK then active=false;telemetry.stage="get-error";telemetry.error=tostring(getError);say("RESULT get-error " .. tostring(getError))
    else say("REQUEST dispatched; awaiting native callback") end
end
describe("startup")
local subscribed, subscribeError = pcall(function()
    Event.Logic.Subscribe(key,function(event)
        local ok, err = pcall(function()
            if not started then
                started=event.logicTick
                if config.selfGrant == "logic" then grantSelf() end
            end
            if not sent and event.logicTick-started>=100 then
                sent=true
                describe("after-grant")
                tryRequest()
            end
            if sent and not active then unsubscribe()
            elseif sent and event.logicTick-started>=650 then
                active=false
                pcall(function() request:Cancel() end)
                telemetry.stage="timeout"
                say("RESULT callback-timeout; request cancelled")
                unsubscribe()
            end
        end)
        if not ok then say("RESULT event-error " .. tostring(err)); unsubscribe() end
    end)
end)
if not subscribed then say("RESULT subscribe-error " .. tostring(subscribeError)) end
function PluginShutdown()
    unsubscribe()
    if active and request then pcall(function() request:Cancel() end) end
    active=false
end

return { GetReport=function()
    local out={id=config.id,label=config.label,stage=telemetry.stage,lines={}}
    for key,value in pairs(telemetry) do out[key]=value end
    for i,line in ipairs(history) do out.lines[i]=line end
    return out
end }
