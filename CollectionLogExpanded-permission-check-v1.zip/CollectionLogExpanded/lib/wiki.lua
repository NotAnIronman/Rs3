local util = require("lib/util")
local json = require("lib/json")
local catalog = require("lib/catalog")
local M = {}

-- transport(path, callback(data, error)) is implemented by the client adapter.
function M.new(transport, clock)
    local self = {}
    local function bucket(query, callback, lowPriority)
        transport("/api.php?action=bucket&format=json&query=" .. util.url(query), function(data, err)
            if err then callback(nil, err); return end
            if type(data) ~= "table" or type(data.bucket) ~= "table" then
                callback(nil, type(data) == "table" and tostring(data.error or "Wiki returned no bucket rows") or "Invalid Wiki response")
                return
            end
            callback(data.bucket)
        end, lowPriority)
    end

    function self:load(npc, callback)
        if not util.integer(npc.id) or type(npc.name) ~= "string" or #npc.name > 200 then
            callback(nil, "Invalid NPC identity"); return
        end
        -- The name narrows candidates; numeric membership establishes identity.
        -- A same-name creature never silently becomes the selected NPC.
        local query = 'bucket("infobox_monster").select("page_name","id","name","dropversion").where("name",'
            .. json.quote(npc.name) .. ').run()'
        local function loadDrops(identity, rendered)
            local dropsQuery = 'bucket("dropsline").select("page_name","item_name","drop_json").where("page_name",'
                .. json.quote(identity.title) .. ').run()'
            bucket(dropsQuery, function(dropRows, dropError)
                if dropError then callback(nil, dropError); return end
                local function build(parsed, renderError)
                    if renderError then callback(nil, "Could not read Wiki table sections: " .. renderError); return end
                    if type(parsed) ~= "table" or type(parsed.parse) ~= "table" or type(parsed.parse.text) ~= "string" then
                        callback(nil, "Invalid rendered Wiki page"); return
                    end
                    local ok, result = pcall(catalog.build, identity, dropRows, parsed.parse.text, clock())
                    if not ok then callback(nil, "Could not interpret Wiki drops: " .. tostring(result)); return end
                    result.revision = parsed.parse.revid
                    callback(result)
                end
                if rendered then build(rendered)
                else
                    transport("/api.php?action=parse&prop=text%7Crevid&format=json&formatversion=2&page=" .. util.url(identity.title), build)
                end
            end)
        end
        bucket(query, function(rows, err)
            if err then callback(nil, err); return end
            local identity, identityError, choices = catalog.resolveIdentity(rows, npc.id, npc.pageTitle)
            if identity then loadDrops(identity); return end
            if choices then callback(nil, identityError, choices); return end
            local candidates, seen = {}, {}
            for _, row in ipairs(rows) do
                if type(row)=="table" and type(row.page_name)=="string"
                    and (not npc.pageTitle or row.page_name==npc.pageTitle) then
                    local hasID=false
                    if type(row.id)=="table" then
                        for _, value in ipairs(row.id) do
                            if util.integer(tonumber(value),0) then hasID=true;break end
                        end
                    end
                    if not hasID and not seen[row.page_name] then
                        candidates[#candidates+1]=row.page_name;seen[row.page_name]=true
                    end
                end
            end
            if #candidates==0 then callback(nil,identityError);return end
            if #candidates>8 then callback(nil,"Too many Wiki pages lack NPC IDs to verify this creature.");return end
            local confirmed, pages, index = {}, {}, 0
            local function nextPage()
                index=index+1
                local title=candidates[index]
                if not title then
                    local resolved, resolveError, pageChoices=catalog.resolveIdentity(confirmed,npc.id,npc.pageTitle)
                    if not resolved then callback(nil,resolveError,pageChoices);return end
                    loadDrops(resolved,pages[resolved.title]);return
                end
                local path="/api.php?action=parse&prop=text%7Cwikitext%7Crevid&format=json&formatversion=2&page=" .. util.url(title)
                transport(path,function(parsed,parseError)
                    if parseError then callback(nil,"Could not verify Wiki location IDs: " .. parseError);return end
                    if type(parsed)~="table" or type(parsed.parse)~="table" or parsed.parse.title~=title
                        or type(parsed.parse.wikitext)~="string" or type(parsed.parse.text)~="string" then
                        callback(nil,"Invalid Wiki page for location ID verification");return
                    end
                    pages[title]=parsed
                    confirmed[#confirmed+1]={page_name=title,id=catalog.locationIDs(parsed.parse.wikitext,npc.name)}
                    nextPage()
                end)
            end
            nextPage()
        end)
    end

    function self:item(title, callback)
        local query = 'bucket("infobox_item").select("page_name","item_id","item_name").where("page_name",'
            .. json.quote(title) .. ').run()'
        bucket(query, function(rows, err)
            if err then callback(nil, err); return end
            local ids, seen = {}, {}
            for _, row in ipairs(rows) do
                if row.page_name == title and type(row.item_id) == "table" then
                    for _, id in ipairs(row.item_id) do
                        id = tonumber(id)
                        if util.integer(id) and not seen[id] then ids[#ids + 1] = id; seen[id] = true end
                    end
                end
            end
            callback(ids)
        end, true)
    end
    return self
end

return M
