Controlled developer-world test of required HTTP permission.
The permission declaration uses Jagex's documented requiredPermissions example.
No HTTP requests, collection writes or account reads are performed.
Extract CLERequiredPermissionProbe directly under dev_plugins.
Run prf, then pon CLERequiredPermissionProbe. Approve any client permission request.
Examine any NPC to print the permission state again, even if it stayed unchanged.
Copy CLE_REQUIRED_PERMISSION_PROBE lines and any client enable/permission errors.
Run poff CLERequiredPermissionProbe after testing.
The production plugin remains unchanged until this experiment is confirmed.
