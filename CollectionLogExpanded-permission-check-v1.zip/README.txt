Collection Log Expanded: permission check v1 (manifest 0.1.91)
Private diagnostic build. Not a public release.

In the game console: poff CollectionLogExpanded
Back up the existing main.lua, plugin.json and lib folder to a folder OUTSIDE
dev_plugins. Extract this ZIP into the current dev_plugins folder, merging into
the existing CollectionLogExpanded folder. Do not rename the plugin folder.
Your progress keys are unchanged; this build does not reset or seed progress.

In the game console:
prf
pon CollectionLogExpanded

The marker CLE_MAIN_PERMISSION v1 START establishes this build loaded.
Report AFTER_SELF_GRANT, MODULE and REGISTERED (true/false values only).
If access becomes allowed, examine a Ram and wait for the drop table.

The only diagnostic additions request/enable this plugin's optional httpAccess
at startup and on the first logic callback, using the documented plugin
management commands. They print root/helper permission status and unsubscribe
on disable. The usual PrettyUI dependency and manifest name are retained.
No other plugin's permissions are changed. No player data is uploaded.
Ram's location-ID lookup fix is included. Native permission success for this
plugin is still being tested. Keep this diagnostic out of public uploads.
