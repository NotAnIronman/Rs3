-- Bounded JSON data decoder. Responses are never evaluated as Lua code.
local M = { null = {} }

function M.decode(text)
    assert(type(text) == "string" and #text <= 2097152, "JSON response exceeds 2 MiB")
    local pos, length, nodes = 1, #text, 0
    local parse
    local function space()
        local _, last = text:find("^[ \t\r\n]*", pos)
        pos = (last or pos - 1) + 1
    end
    local function fail(message) error(message .. " at JSON byte " .. pos, 0) end
    local function hex()
        local value = text:sub(pos, pos + 3)
        if not value:match("^%x%x%x%x$") then fail("Invalid Unicode escape") end
        pos = pos + 4
        return tonumber(value, 16)
    end
    local function str()
        pos = pos + 1
        local out = {}
        while pos <= length do
            local char = text:sub(pos, pos)
            pos = pos + 1
            if char == '"' then return table.concat(out) end
            if char == "\\" then
                local escaped = text:sub(pos, pos)
                pos = pos + 1
                local simple = { ['"']='"', ['\\']='\\', ['/']='/', b='\b', f='\f', n='\n', r='\r', t='\t' }
                if escaped == "u" then
                    local code = hex()
                    if code >= 0xD800 and code <= 0xDBFF then
                        if text:sub(pos, pos + 1) ~= "\\u" then fail("Missing low surrogate") end
                        pos = pos + 2
                        local low = hex()
                        if low < 0xDC00 or low > 0xDFFF then fail("Invalid low surrogate") end
                        code = 0x10000 + (code - 0xD800) * 1024 + low - 0xDC00
                    elseif code >= 0xDC00 and code <= 0xDFFF then
                        fail("Unexpected low surrogate")
                    end
                    out[#out + 1] = utf8.char(code)
                elseif simple[escaped] then out[#out + 1] = simple[escaped]
                else fail("Invalid string escape") end
            elseif string.byte(char) < 32 then fail("Control character in string")
            else out[#out + 1] = char end
        end
        fail("Unterminated string")
    end
    function parse(depth)
        nodes = nodes + 1
        if depth > 48 or nodes > 100000 then fail("JSON nesting or node limit exceeded") end
        space()
        local char = text:sub(pos, pos)
        if char == '"' then return str() end
        if char == "{" or char == "[" then
            local object, result = char == "{", {}
            local close = object and "}" or "]"
            pos = pos + 1
            space()
            if text:sub(pos, pos) == close then pos = pos + 1; return result end
            while true do
                space()
                local key
                if object then
                    if text:sub(pos, pos) ~= '"' then fail("Expected object key") end
                    key = str()
                    space()
                    if text:sub(pos, pos) ~= ":" then fail("Expected colon") end
                    pos = pos + 1
                    if result[key] ~= nil then fail("Duplicate object key") end
                else key = #result + 1 end
                result[key] = parse(depth + 1)
                space()
                local separator = text:sub(pos, pos)
                pos = pos + 1
                if separator == close then return result end
                if separator ~= "," then fail("Expected comma or closing bracket") end
            end
        end
        for literal, value in pairs({ ["true"]=true, ["false"]=false, ["null"]=M.null }) do
            if text:sub(pos, pos + #literal - 1) == literal then pos = pos + #literal; return value end
        end
        local token = text:sub(pos):match("^%-?%d+%.?%d*[eE]?[+%-]?%d*")
        if not token then fail("Expected JSON value") end
        local mantissa, exponent = token:match("^(.-)[eE]([+%-]?%d+)$")
        mantissa = mantissa or token
        if (token:find("[eE]") and not exponent)
            or not (mantissa:match("^%-?%d+$") or mantissa:match("^%-?%d+%.%d+$"))
            or mantissa:match("^%-?0%d") then fail("Invalid number") end
        local number = tonumber(token)
        if not number or number == math.huge or number == -math.huge then fail("Number out of range") end
        pos = pos + #token
        return number
    end
    local result = parse(0)
    space()
    if pos <= length then fail("Trailing JSON content") end
    return result
end

function M.quote(value)
    assert(type(value) == "string", "Expected string")
    local escapes = { ['"']='\\"', ['\\']='\\\\', ['\n']='\\n', ['\r']='\\r', ['\t']='\\t' }
    return '"' .. value:gsub('[%z\1-\31\\"]', function(char)
        return escapes[char] or string.format("\\u%04x", string.byte(char))
    end) .. '"'
end

return M
